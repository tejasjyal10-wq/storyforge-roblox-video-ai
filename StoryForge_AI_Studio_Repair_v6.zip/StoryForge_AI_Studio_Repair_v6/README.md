# StoryForge Website Audit Package

This is a consolidated snapshot of StoryForge's website and associated backend files for the upcoming functional audit and repair work.

## Included
- `index.html` — latest available StoryForge AI Studio page, packaged as the website entry page.
- `server.js` — video-generation API backend and related routes.
- `storyforge-learning.js` — adaptive learning API router used by `server.js`.
- `package.json` — minimal Node/Express startup metadata.
- `.env.example` — provider configuration template (no secrets).

## Bundled story endpoint
- `POST /api/storyforge` supports `health`, `analyze`, and `chat` actions.
- `analyze` produces deterministic scene cards from the supplied text. This is a local heuristic planner, not a live AI model.
- The frontend defaults to this bundled endpoint when served by the backend. Custom AI endpoints can be configured separately.

## Run locally
1. Install Node.js (18+ recommended).
2. Copy `.env.example` to `.env` and set `AGNES_API_KEY` only if you have a valid provider key.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Note: This package is a snapshot of files available in the library, not a verified complete export of the current GitHub repository. The website and backend have not yet been fully audited or proven to be integrated end-to-end. This ZIP is intended for inspection and functionalization, not a production release.

## Test local planner
Run `npm test` to execute the dependency-free planner tests.

### Video Review workspace (v4)
Open the **Video Review** tab to preview the active project's canvas scene, run a 10-point verification, save scene/project feedback, and record scene- or project-level revision requests. Revision notes can be exported as JSON; they do not regenerate video unless a real video-generation provider is connected. Browser video exports are monitored with a maximum of 15 status observations.

## Provider video generation (added in repair pass)
- The Studio now includes a separate **AI video generation** panel.
- **Build prompt from scenes** assembles story summary, scene cards, camera/mood/dialogue fields, and character-library appearance notes into a user-editable prompt.
- **Generate AI video** sends the prompt to the existing backend `POST /api/generate` endpoint and polls `GET /api/jobs/:jobId` for up to 15 status checks, 5 seconds apart.
- A completed provider job produces an **Open generated video** link. The app does not claim that provider generation is available when the backend/key is missing.
- This provider workflow is distinct from the existing local canvas WebM exporter, which renders a 2D preview video.

## Configuration and safety
- Set `STORYFORGE_ALLOWED_ORIGINS` to a comma-separated list of exact origins for cross-origin deployments. Defaults permit local development origins only; same-origin requests need no CORS.
- The backend includes basic browser security headers.
- Video provider requests have a 90-second network timeout, and prompts are limited to 12,000 characters.
- Do not deploy this API publicly without authentication, stronger rate limiting, durable job storage, monitoring, and a deployment-specific security review.

- Provider job IDs/status are saved with the active project, and the **Resume monitoring saved job** button can reattach the UI monitor after reopening a saved project (as long as the backend process is still running).
