'use strict';

/**
 * StoryForge Adaptive Learning API (Express router)
 *
 * Mount from server.js:
 *   const { createLearningRouter } = require('./storyforge-learning');
 *   app.use('/api/learning', createLearningRouter());
 *
 * Before submitting a video-generation prompt, retrieve:
 *   GET /api/learning/context
 * and append the returned `context` to the generation prompt (only when enabled).
 *
 * Storage: JSON file at STORYFORGE_LEARNING_FILE or ./data/storyforge-learning.json.
 * On Render, configure a persistent disk and set STORYFORGE_LEARNING_FILE to a path
 * on that disk if memories must survive deploys/restarts. This module does not analyze
 * video pixels/audio; feedback is user-provided and preference extraction is heuristic.
 */

const express = require('express');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');


const DEFAULT_DATA = { enabled: true, memories: [], feedback: [] };
const CATEGORIES = [
  ['camera', /camera|shot|angle|pan|zoom|tracking|close.?up|wide shot/i],
  ['animation', /movement|motion|animate|animation|walk|run|smooth|stiff/i],
  ['characters', /character|clothes|outfit|face|appearance|consistent/i],
  ['story', /story|plot|dialogue|narration|pacing|longer|shorter/i],
  ['visuals', /lighting|visual|color|background|environment|detail/i],
  ['audio', /audio|sound|music|voice|dialogue|effect/i],
];

function normalizeStore(data) {
  if (!data || typeof data !== 'object') return structuredClone(DEFAULT_DATA);
  return {
    enabled: data.enabled !== false,
    memories: Array.isArray(data.memories) ? data.memories : [],
    feedback: Array.isArray(data.feedback) ? data.feedback : [],
  };
}


function createLearningRouter(options = {}) {
  const router = express.Router();
  const filePath = options.filePath || process.env.STORYFORGE_LEARNING_FILE || path.join(process.cwd(), 'data', 'storyforge-learning.json');
  let store = load();

  function load() {
    try { return normalizeStore(JSON.parse(fs.readFileSync(filePath, 'utf8'))); }
    catch { return structuredClone(DEFAULT_DATA); }
  }
  function save() {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmp = `${filePath}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(store, null, 2), 'utf8');
    fs.renameSync(tmp, filePath);
  }
  function safeMemory(m) {
    return { id: m.id, category: m.category, preference: m.preference, confidence: m.confidence,
      evidenceCount: m.evidenceCount, createdAt: m.createdAt, lastUsedAt: m.lastUsedAt };
  }
  function extractPreference(text) {
    const t = String(text || '').trim();
    if (!t || t.length > 1600) return null;
    const cat = CATEGORIES.find(([, rx]) => rx.test(t));
    if (!cat) return null;
    // Keep the user's wording as the lesson; avoid inferring beyond their statement.
    return { category: cat[0], preference: t };
  }
  function learn(text, explicit = false) {
    if (!store.enabled) return null;
    const extracted = extractPreference(text);
    if (!extracted) return null;
    const existing = store.memories.find(m => m.category === extracted.category && m.preference.toLowerCase() === extracted.preference.toLowerCase());
    const now = new Date().toISOString();
    if (existing) {
      existing.evidenceCount = (existing.evidenceCount || 1) + 1;
      existing.confidence = Math.min(0.98, Math.max(existing.confidence || 0.45, explicit ? 0.8 : 0.55) + 0.05);
      existing.lastUsedAt = now;
      return existing;
    }
    const memory = { id: crypto.randomUUID(), category: extracted.category, preference: extracted.preference,
      confidence: explicit ? 0.8 : 0.45, evidenceCount: 1, createdAt: now, lastUsedAt: now };
    store.memories.push(memory);
    return memory;
  }

  router.get('/status', (_req, res) => res.json({ ok: true, enabled: store.enabled, memoryCount: store.memories.length, feedbackCount: store.feedback.length }));
  router.get('/memories', (_req, res) => res.json({ enabled: store.enabled, memories: store.memories.map(safeMemory) }));
  router.post('/toggle', (req, res) => {
    if (typeof req.body?.enabled !== 'boolean') return res.status(400).json({ error: 'enabled must be a boolean' });
    store.enabled = req.body.enabled; save(); res.json({ ok: true, enabled: store.enabled });
  });
  router.post('/learn', (req, res) => {
    const text = String(req.body?.text || '').trim();
    if (!text) return res.status(400).json({ error: 'text is required' });
    if (text.length > 1600) return res.status(413).json({ error: 'text must be 1600 characters or less' });
    if (!store.enabled) return res.json({ ok: true, learned: false, reason: 'learning_disabled' });
    const memory = learn(text, req.body?.explicit === true);
    if (!memory) return res.json({ ok: true, learned: false, reason: 'no_preference_detected' });
    save(); res.json({ ok: true, learned: true, memory: safeMemory(memory) });
  });
  router.post('/feedback', (req, res) => {
    const rating = String(req.body?.rating || '').toLowerCase();
    if (!['excellent', 'good', 'needs_improvement'].includes(rating)) return res.status(400).json({ error: 'rating must be excellent, good, or needs_improvement' });
    const notes = String(req.body?.notes || '').trim().slice(0, 1600);
    const item = { id: crypto.randomUUID(), rating, notes, createdAt: new Date().toISOString() };
    store.feedback.unshift(item);
    store.feedback = store.feedback.slice(0, 100);
    if (store.enabled && notes) learn(notes, false);
    save(); res.json({ ok: true, feedback: item });
  });
  router.get('/context', (_req, res) => {
    const relevant = store.enabled ? store.memories.slice().sort((a, b) => (b.confidence || 0) - (a.confidence || 0)).slice(0, 30) : [];
    const context = relevant.length ? 'StoryForge user creative preferences (apply only when they do not conflict with the current request):\n' + relevant.map(m => `- [${m.category}] ${m.preference}`).join('\n') : '';
    // Update last-used timestamp only for preferences returned to generation.
    if (relevant.length) { const now = new Date().toISOString(); relevant.forEach(m => { m.lastUsedAt = now; }); save(); }
    res.json({ enabled: store.enabled, memories: relevant.map(safeMemory), context });
  });
  router.delete('/memories/:id', (req, res) => {
    const before = store.memories.length;
    store.memories = store.memories.filter(m => m.id !== req.params.id);
    if (before === store.memories.length) return res.status(404).json({ error: 'memory not found' });
    save(); res.json({ ok: true, deleted: true });
  });
  router.delete('/memories', (_req, res) => { store.memories = []; save(); res.json({ ok: true, cleared: true }); });
  router.delete('/history', (_req, res) => { store.feedback = []; save(); res.json({ ok: true, cleared: true }); });

  return router;
}


module.exports = { createLearningRouter };
