# StoryForge Audio Integration (standalone backend module)


## What is implemented
- Audio scene/layer/dialogue data models.
- Rule-based Audio Director adds mood music and environment ambience layers, and sets basic dialogue delivery rate by emotion.
- Persistent character voice profiles (`VoiceRegistry`) stored in JSON.
- Piper TTS adapter that performs actual local synthesis when Piper and a compatible model file are installed.
- Tagged, user-provided/licensed ambience/SFX/music asset catalog.
- FFmpeg timeline mixer with start offsets, volume, trim, fades, resampling, limiter and AAC output.
- Audio pipeline that plans scenes, synthesizes dialogue/narration, resolves tagged assets, and mixes.
- Unit tests for planning, profile persistence, asset resolution, and TTS input validation.


## Current limits / honest status
This package is **not connected to your deployed StoryForge website or repository** because the repository and Worker backend are not available for inspection/editing from this session. The Piper adapter requires a Piper executable and a compatible model; music/SFX generation is not included as a generative model integration yet. Music/ambience/SFX are selected from a tagged catalog. Lip-sync timing is not implemented in this package yet. Tests use temporary files and mocks/contract checks; they do not prove Piper, FFmpeg, cloud deployment, or final video output work in your environment.


## Requirements
- Python 3.10+
- Optional runtime tools: Piper TTS, FFmpeg
- No Python dependencies required for the core modules/tests


## Test
```bash
python -m unittest discover -s tests -v
```


## Quick use
```python
from storyforge_audio import *

voices = VoiceRegistry("data/character_voices.json")
# Assign each recurring character a stable profile (model path must exist for Piper):
# voices.set(VoiceProfile("hero", "piper-en", "models/en_US-voice.onnx", speaker=0))

catalog = CatalogResolver(SoundCatalog("assets/audio"))
pipeline = AudioPipeline(voices, PiperTTS(), catalog)
job = AudioJob(
    scenes=[AudioScene("scene01", 15, mood="suspense", environment="forest", dialogue=[
        DialogueLine("hero", "Did you hear that?", start=4, emotion="urgent")
    ])],
    output_file="renders/scene01_audio.m4a"
)
# pipeline.render(job)  # Executes real synthesis and mixing; requires model/assets/FFmpeg
```


## Catalog format
Create `assets/audio/catalog.json` and place licensed audio files below the catalog root:
```json
[
  {"kind":"ambience","file":"forest_wind.wav","tags":["forest","wind","nature"]},
  {"kind":"music","file":"suspense_bed.wav","tags":["suspense","tension"]},
  {"kind":"sfx","file":"branch_snap.wav","tags":["branch","snap","forest"]}
]
```
Kinds supported: `ambience`, `music`, `sfx`. Audio layer `file` can also be explicitly supplied.
