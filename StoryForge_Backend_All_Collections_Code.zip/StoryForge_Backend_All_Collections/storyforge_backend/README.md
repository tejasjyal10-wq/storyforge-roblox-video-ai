# StoryForge Backend — All Collections (Code-First Build)

This package consolidates a modular backend foundation across the StoryForge collections. It is portable Python and intentionally does not pretend external services are live.

## Included modules
- Core: config, atomic JSON storage, validation, logging, bounded retries, orchestration
- Collection 1: story director, project memory, continuity, dialogue contracts
- Collection 2: stage pipeline, asset registry, recovery plan
- Collection 3: creative planning, character library, story structure
- Collection 4: Blender process adapter, FFprobe media probe, manifest, transitions
- Collection 5: Roblox export bootstrap, scene specs for obstacles/checkpoints/triggers
- Audio: mood layer planner, character voice registry, TTS provider contract
- API: optional FastAPI routes for health, plan, pipeline and Roblox export

## Limitations / external verification
Heuristic modules are not a replacement for a configured generative model. Blender, FFmpeg, FFprobe, Roblox Studio, AI services, and the deployed frontend/Worker are not run or connected by this code package. Roblox export is a bootstrap/spec generator, not a full automated Studio asset/animation builder. Audio plans describe layers; no music or SFX generator is included here.

## Optional API dependencies
`pip install fastapi uvicorn` then use `create_app()` and run with uvicorn.

## Environment configuration
- `STORYFORGE_DATA_DIR`
- `STORYFORGE_AI_BASE_URL`, `STORYFORGE_AI_MODEL`, `STORYFORGE_AI_API_KEY` (reserved provider settings)
- `STORYFORGE_RENDER_TIMEOUT`
- `STORYFORGE_MAX_RETRIES`
- `STORYFORGE_ROBLOX_OUTPUT`

## Status
Code generation pass only. Tests and runtime integration verification are intentionally deferred per the user's instruction to finish writing code before testing.
