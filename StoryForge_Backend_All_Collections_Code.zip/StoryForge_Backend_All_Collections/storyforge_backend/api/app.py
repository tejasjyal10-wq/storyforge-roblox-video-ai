"""Optional FastAPI surface. Install fastapi/uvicorn to run; no hard dependency."""
def create_app(orchestrator=None):
    try: from fastapi import FastAPI, HTTPException
    except ImportError as e: raise RuntimeError('Install FastAPI to use HTTP API: pip install fastapi uvicorn') from e
    from ..core.orchestrator import BackendOrchestrator
    engine=orchestrator or BackendOrchestrator(); app=FastAPI(title='StoryForge Backend API',version='0.1.0')
    @app.get('/health')
    def health(): return {'status':'ok','service':'storyforge-backend'}
    @app.post('/plan')
    def plan(payload:dict):
        if not isinstance(payload,dict): raise HTTPException(400,'JSON object required')
        return engine.create_plan(payload)
    @app.post('/pipeline')
    def pipeline(payload:dict):
        plan=payload.get('plan')
        if not isinstance(plan,dict): raise HTTPException(400,'plan object required')
        return engine.run_pipeline(plan,payload.get('stages'))
    @app.post('/export/roblox')
    def roblox(payload:dict):
        plan=payload.get('plan'); path=payload.get('output_path')
        if not isinstance(plan,dict) or not path: raise HTTPException(400,'plan and output_path required')
        return engine.export_roblox(plan,path)
    return app
