from collections import Counter
from ..core.storage import JSONStore

class StoryDirector:
    """Rule-first story analyst; provider integration can be added via adapter."""
    THEMES=('friendship','family','courage','identity','responsibility','technology','nature','justice','hope','belonging')
    def __init__(self, store=None): self.store=store
    def analyze(self, project):
        text=' '.join([project.get('synopsis','')]+[s.get('purpose','')+' '+' '.join(s.get('beats',[])) for s in project.get('scenes',[])])
        low=text.lower(); themes=[t for t in self.THEMES if t in low]
        scene_count=len(project.get('scenes',[]))
        return {'premise':project.get('synopsis',''),'themes':themes,'genre':project.get('genre',''),
                'scene_count':scene_count,'characters':project.get('cast',[]),
                'conflict_signals':[w for w in ('conflict','danger','must','mystery','problem','goal') if w in low],
                'limitations':['This analysis is heuristic unless an AI model provider is configured.']}
    def evaluate(self, plan):
        scenes=plan.get('scenes',[]); checks={'has_scenes':bool(scenes),
          'scene_ids_unique':len([s.get('id') for s in scenes])==len(set(s.get('id') for s in scenes)),
          'scene_purpose_present':all(bool(s.get('purpose')) for s in scenes),
          'scene_beats_present':all(bool(s.get('beats')) for s in scenes),
          'cast_declared':bool(plan.get('cast',[]))}
        return {'score':round(100*sum(checks.values())/len(checks)),'checks':checks,'issues':[k for k,v in checks.items() if not v],'type':'heuristic'}
