"""Optional model-provider interface. No provider is active until configured."""
import os, json, urllib.request

class ModelNotConfigured(RuntimeError): pass

class OpenAICompatibleProvider:
    def __init__(self, base_url=None, model=None, api_key=None, timeout=45):
        self.base_url=(base_url or os.getenv("STORYFORGE_AI_BASE_URL","")).rstrip("/")
        self.model=model or os.getenv("STORYFORGE_AI_MODEL","")
        self.api_key=api_key or os.getenv("STORYFORGE_AI_API_KEY","")
        self.timeout=timeout

    @property
    def configured(self):
        return bool(self.base_url and self.model and self.api_key)

    def generate_json(self, system_prompt, user_prompt):
        if not self.configured:
            raise ModelNotConfigured("Set STORYFORGE_AI_BASE_URL, STORYFORGE_AI_MODEL, and STORYFORGE_AI_API_KEY.")
        payload={"model":self.model,"messages":[
            {"role":"system","content":system_prompt},
            {"role":"user","content":user_prompt}],"temperature":0.6}
        req=urllib.request.Request(self.base_url+"/chat/completions",
          data=json.dumps(payload).encode(),headers={"Content-Type":"application/json",
          "Authorization":"Bearer "+self.api_key},method="POST")
        with urllib.request.urlopen(req,timeout=self.timeout) as resp:
            data=json.loads(resp.read().decode())
        content=data["choices"][0]["message"]["content"]
        # tolerate fenced JSON, reject invalid responses
        content=content.strip()
        if content.startswith("```"):
            content=content.split("\n",1)[1].rsplit("```",1)[0].strip()
        return json.loads(content)

class ModelNotConfigured(RuntimeError):
    pass
