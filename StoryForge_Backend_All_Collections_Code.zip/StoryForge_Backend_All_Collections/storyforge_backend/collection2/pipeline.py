from dataclasses import dataclass,field
from time import time

@dataclass
class Stage:
    name:str
    handler:object
    retries:int=1

class ProductionPipeline:
    DEFAULT_STAGES=('validate','creative_plan','audio_plan','asset_plan','export_plan')
    def __init__(self, handlers=None): self.handlers=handlers or {}; self.history=[]
    def register(self,name,handler): self.handlers[name]=handler
    def run(self, plan, stages=None):
        names=stages or self.DEFAULT_STAGES; current=dict(plan); results=[]; overall='completed'
        for name in names:
            handler=self.handlers.get(name)
            if not handler:
                results.append({'stage':name,'status':'skipped','reason':'No handler registered; planning output preserved'})
                continue
            start=time(); attempts=0; error=None
            while attempts<3:
                attempts+=1
                try:
                    out=handler(current); current.update(out or {}); error=None; break
                except Exception as e: error=str(e)
            rec={'stage':name,'status':'completed' if error is None else 'failed','attempts':attempts,'duration_seconds':round(time()-start,3),'error':error}
            results.append(rec); self.history.append(rec)
            if error: overall='failed'; break
        return {'status':overall,'results':results,'plan':current}
