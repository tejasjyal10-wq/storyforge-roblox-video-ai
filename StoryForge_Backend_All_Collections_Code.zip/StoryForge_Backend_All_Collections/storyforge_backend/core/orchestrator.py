from pathlib import Path
from .config import BackendConfig
from .storage import JSONStore
from ..collection1.director import StoryDirector
from ..collection2.pipeline import ProductionPipeline
from ..collection3.creative import CreativePlanner
from ..collection4.rendering import RenderManager
from ..collection5.roblox import RobloxExporter
from ..audio.director import AudioDirector

class BackendOrchestrator:
    """Coordinates modules. External executables/services remain optional adapters."""
    def __init__(self, config=None):
        self.config=config or BackendConfig()
        Path(self.config.data_dir).mkdir(parents=True,exist_ok=True)
        self.store=JSONStore(Path(self.config.data_dir)/'projects')
        self.director=StoryDirector(self.store)
        self.creative=CreativePlanner()
        self.pipeline=ProductionPipeline()
        self.render=RenderManager(self.config)
        self.roblox=RobloxExporter()
        self.audio=AudioDirector()
    def create_plan(self, project):
        project=self.creative.normalize_project(project)
        analysis=self.director.analyze(project)
        plan=self.creative.plan(project,analysis)
        plan['audio_plan']=self.audio.plan_project(plan)
        plan['quality']=self.director.evaluate(plan)
        return plan
    def run_pipeline(self, plan, stages=None):
        return self.pipeline.run(plan, stages=stages)
    def export_roblox(self, plan, output_path):
        return self.roblox.export(plan, output_path)
