# StoryForge Backend — Collection 1: AI Intelligence & Story Director

Starter implementation for the first backend collection. Runs as a Cloudflare Worker and exposes a story-to-production-plan endpoint.


## Endpoints
- `GET /api/health` — health/version and whether the AI binding exists.
- `POST /api/director/plan` — accepts `{ "story": "...", "length": "short|medium|long", "style": "...", "language": "..." }`.

## Important status
The AI binding is configured in `wrangler.toml`, but it is **not connected or live until you deploy this Worker with Workers AI enabled in your Cloudflare account**. The selected model may need to be adjusted to one available in your account. If model calls fail, the endpoint uses deterministic fallback planning; the response marks `mode: fallback` so it is not mistaken for AI-generated output.

This collection does not yet execute Blender renders or connect to the existing StoryForge front-end, character database, animation system, or Roblox exporter. Those are later integration milestones.

## Local tests
Requires Node.js 18+:
```bash
npm test
```

## Deploy
1. Sign in to Cloudflare and open Workers & Pages.
2. Create a Worker named `storyforge-ai-director-c1`.
3. Add the files from this folder to a local project (or repository) and deploy with Wrangler.
4. Ensure Workers AI is available in the account and the `AI` binding is enabled for this Worker.
5. Test `GET /api/health`, then POST `/api/director/plan` with JSON:
```json
{
  "story": "A young explorer discovers a hidden city and must protect its people.",
  "length": "medium",
  "style": "cinematic animation",
  "language": "English"
}
```

Deployment/testing is not claimed complete until the live endpoints are verified.
