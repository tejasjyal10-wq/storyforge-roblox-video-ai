const keywordGroups = {
  fantasy: ['magic','dragon','wizard','kingdom','spell','enchanted','ancient'],
  adventure: ['journey','quest','explore','adventure','treasure','discover'],
  mystery: ['mystery','secret','clue','unknown','disappear','hidden'],
  action: ['fight','battle','chase','attack','escape','danger'],
  comedy: ['funny','joke','laugh','comedy','silly'],
  drama: ['family','loss','hope','promise','friend','village']
};
export function analyzeStory(story) {
  const lower = story.toLowerCase();
  const themes = Object.entries(keywordGroups).filter(([,words]) => words.some(w => lower.includes(w))).map(([theme]) => theme);
  const sentences = story.match(/[^.!?]+[.!?]?/g)?.map(s => s.trim()).filter(Boolean) || [story.trim()];
  return {
    premise: sentences[0]?.slice(0, 500) || story.slice(0, 500),
    themes: themes.length ? themes : ['general narrative'],
    conflict: sentences.find(s => /but|however|danger|must|need|cannot|can't|against|threat/i.test(s)) || 'Conflict needs further interpretation by the AI model.',
    tone: inferTone(lower),
  };
}
function inferTone(text) {
  const options = [['tense',['danger','threat','chase','fear','dark']],['hopeful',['hope','save','together','believe']],['mysterious',['secret','unknown','mystery','hidden']],['playful',['funny','laugh','joke','silly']],['dramatic',['battle','loss','must','destiny']]];
  const found = options.filter(([,words]) => words.some(w => text.includes(w))).map(([tone]) => tone);
  return found.length ? found : ['adventurous'];
}
