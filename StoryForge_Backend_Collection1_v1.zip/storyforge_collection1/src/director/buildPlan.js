import { analyzeStory } from './analyzer.js';
import { extractCharacters } from './characters.js';
import { extractDialogue } from './dialogue.js';
import { planScenes } from './scenes.js';
import { applyCinematicDefaults } from './cinematic.js';
import { validateDirectorPlan } from './schema.js';
import { requestModelPlan } from './model.js';
export async function buildDirectorPlan(input, ai) {
  const modelPlan = await requestModelPlan(ai, input);
  if (modelPlan) {
    modelPlan.project ||= { id: 'storyforge_project', title: 'Untitled Story', language: input.language };
    modelPlan.production ||= { style: input.style, language: input.language, notes: [] };
    const check = validateDirectorPlan(modelPlan);
    if (check.valid) return { plan: modelPlan, mode: 'ai' };
  }
  const analysis = analyzeStory(input.story);
  const characters = extractCharacters(input.story);
  const dialogue = extractDialogue(input.story);
  const scenes = planScenes(input.story, input.length).map((s, i) => applyCinematicDefaults({ ...s, characters: characters.map(c => c.id), dialogue: i === 0 ? dialogue : [] }));
  const plan = { project: { id: 'storyforge_project', title: 'Untitled Story', language: input.language }, analysis, characters, scenes, production: { style: input.style, language: input.language, notes: ['Deterministic fallback plan. Connect/enable AI model for deeper story interpretation.'] } };
  const validation = validateDirectorPlan(plan);
  if (!validation.valid) throw new Error(`Plan validation failed: ${validation.errors.join(' ')}`);
  return { plan, mode: 'fallback' };
}
