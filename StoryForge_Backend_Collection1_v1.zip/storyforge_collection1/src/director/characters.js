export function extractCharacters(story) {
  // Lightweight deterministic fallback. Model-based extraction supersedes this when AI is available.
  const names = new Set();
  for (const match of story.matchAll(/\b([A-Z][a-z]{1,20})\b/g)) {
    const name = match[1];
    if (!['The','A','An','In','On','Once','One','Then','But','When','After','Before'].includes(name)) names.add(name);
  }
  return [...names].slice(0, 12).map((name, i) => ({
    id: `char_${slug(name)}_${i+1}`, name, role: 'unclassified', description: 'Description to be refined by AI or user.', traits: [], relationships: []
  }));
}
function slug(name) { return name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, ''); }
