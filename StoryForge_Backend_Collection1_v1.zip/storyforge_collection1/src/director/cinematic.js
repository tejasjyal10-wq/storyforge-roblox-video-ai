export function applyCinematicDefaults(scene) {
  const emotion = scene.emotion?.[0] || 'neutral';
  const cameraByEmotion = { fear: { shot: 'wide', movement: 'slow push-in' }, hope: { shot: 'wide', movement: 'gentle dolly' }, joy: { shot: 'medium-wide', movement: 'smooth tracking' }, anger: { shot: 'close-up', movement: 'controlled handheld' }, sadness: { shot: 'close-up', movement: 'slow push-in' }, surprise: { shot: 'medium', movement: 'quick reveal' } };
  return { ...scene, camera: cameraByEmotion[emotion] || scene.camera, lighting: { mood: emotion, preset: 'auto' }, transition: scene.transition || 'cut' };
}
