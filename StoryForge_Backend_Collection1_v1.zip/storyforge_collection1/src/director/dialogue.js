export function extractDialogue(story) {
  const lines = story.split(/\n+/).map(s => s.trim()).filter(Boolean);
  return lines.filter(line => /^([A-Z][\w -]{0,30}):\s*.+$/.test(line) || /^['"“].+['"”]$/.test(line)).map((line, i) => ({ id: `dialogue_${i+1}`, text: line, speaker: line.includes(':') ? line.split(':')[0].trim() : null }));
}
