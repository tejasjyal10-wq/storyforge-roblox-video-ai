const cues = {
  fear: ['afraid','fear','terrified','danger','threat'], sadness: ['sad','cry','grief','lost'],
  joy: ['happy','joy','laugh','celebrate'], anger: ['angry','furious','rage'], hope: ['hope','believe','save','together'], surprise: ['suddenly','unexpected','shock','surprise']
};
export function inferEmotion(text) {
  const t = text.toLowerCase();
  const detected = Object.entries(cues).filter(([,words]) => words.some(w => t.includes(w))).map(([emotion]) => emotion);
  return detected.length ? detected : ['neutral'];
}
