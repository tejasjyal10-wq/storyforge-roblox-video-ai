export function validateStoryInput(body) {
  const errors = [];
  if (!body || typeof body !== 'object' || Array.isArray(body)) errors.push('Request body must be a JSON object.');
  const story = typeof body?.story === 'string' ? body.story.trim() : '';
  if (story.length < 20) errors.push('story must contain at least 20 characters.');
  if (story.length > 12000) errors.push('story must not exceed 12000 characters.');
  const allowed = ['short', 'medium', 'long'];
  if (body?.length && !allowed.includes(body.length)) errors.push('length must be short, medium, or long.');
  if (body?.style && (typeof body.style !== 'string' || body.style.length > 80)) errors.push('style must be a string up to 80 characters.');
  if (errors.length) return { ok: false, errors };
  return { ok: true, value: { story, length: body.length || 'medium', style: body.style || 'cinematic animation', language: body.language || 'English' } };
}
