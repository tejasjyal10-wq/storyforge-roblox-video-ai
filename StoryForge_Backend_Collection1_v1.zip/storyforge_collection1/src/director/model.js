const SYSTEM_PROMPT = `You are StoryForge AI Director. Convert user stories into a practical, structured animation/video production plan. Return JSON only, matching: {analysis:{premise, themes:string[], conflict, tone:string[]},characters:[{id,name,role,description,traits:string[],relationships:string[]}],scenes:[{id,order,summary,location,characters:string[],actions:[{type,description}],dialogue:[{speaker,text}],emotion:string[],camera:{shot,movement,focus},lighting:{mood,preset},transition,sound:{ambience,cues:string[]},assets:string[]}],production:{style,language,notes:string[]}}. Be grounded in the supplied story. Do not invent named characters or major plot events. Make scenes actionable and cinematic.`;
export async function requestModelPlan(ai, input) {
  if (!ai?.run) return null;
  try {
    const result = await ai.run('@cf/meta/llama-3.1-8b-instruct', { messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: JSON.stringify(input) }
    ] });
    const raw = typeof result?.response === 'string' ? result.response : JSON.stringify(result);
    const json = raw.match(/\{[\s\S]*\}/)?.[0];
    if (!json) return null;
    return JSON.parse(json);
  } catch { return null; }
}
