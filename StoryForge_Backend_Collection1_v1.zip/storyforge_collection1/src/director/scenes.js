import { inferEmotion } from './emotion.js';
export function planScenes(story, targetLength = 'medium') {
  const chunks = story.split(/\n\s*\n|(?<=[.!?])\s+(?=[A-Z])/).map(s => s.trim()).filter(Boolean);
  const cap = targetLength === 'short' ? 3 : targetLength === 'long' ? 12 : 7;
  const selected = chunks.slice(0, cap);
  return selected.map((text, i) => ({
    id: `scene_${String(i+1).padStart(3,'0')}`, order: i+1, summary: text.slice(0, 1000),
    location: 'unspecified', characters: [], actions: [{ type: 'narrative', description: text }],
    dialogue: [], emotion: inferEmotion(text), camera: { shot: 'medium', movement: 'static', focus: 'primary action' },
    lighting: { mood: 'story-appropriate', preset: 'auto' }, transition: i === 0 ? 'opening' : 'cut', sound: { ambience: 'scene-appropriate', cues: [] }, assets: []
  }));
}
