export function validateDirectorPlan(plan) {
  const errors = [];
  if (!plan || typeof plan !== 'object') return { valid: false, errors: ['Plan must be an object.'] };
  if (!plan.project || typeof plan.project.id !== 'string') errors.push('project.id is required.');
  if (!Array.isArray(plan.scenes) || plan.scenes.length < 1) errors.push('scenes must contain at least one scene.');
  if (!Array.isArray(plan.characters)) errors.push('characters must be an array.');
  plan.scenes?.forEach((scene, i) => {
    if (!scene.id) errors.push(`scenes[${i}].id is required.`);
    if (!scene.summary) errors.push(`scenes[${i}].summary is required.`);
    if (!Array.isArray(scene.actions)) errors.push(`scenes[${i}].actions must be an array.`);
  });
  return { valid: errors.length === 0, errors };
}
