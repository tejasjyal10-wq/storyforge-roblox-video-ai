import { validateStoryInput } from './director/input.js';
import { buildDirectorPlan } from './director/buildPlan.js';
const cors = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'content-type', 'content-type': 'application/json; charset=utf-8' };
function json(data, status=200) { return new Response(JSON.stringify(data, null, 2), { status, headers: cors }); }
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (url.pathname === '/api/health' && request.method === 'GET') return json({ ok: true, service: 'storyforge-ai-director-c1', version: '1.0.0', modelBinding: Boolean(env.AI), timestamp: new Date().toISOString() });
    if (url.pathname === '/api/director/plan' && request.method === 'POST') {
      let body;
      try { body = await request.json(); } catch { return json({ ok: false, error: 'Request body must be valid JSON.' }, 400); }
      const checked = validateStoryInput(body);
      if (!checked.ok) return json({ ok: false, errors: checked.errors }, 400);
      try {
        const result = await buildDirectorPlan(checked.value, env.AI);
        return json({ ok: true, mode: result.mode, plan: result.plan });
      } catch (err) { return json({ ok: false, error: 'Director plan could not be created.', detail: String(err?.message || err) }, 500); }
    }
    return json({ ok: false, error: 'Not found', available: ['GET /api/health', 'POST /api/director/plan'] }, 404);
  }
};
