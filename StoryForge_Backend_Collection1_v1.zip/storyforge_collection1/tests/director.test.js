import test from 'node:test';
import assert from 'node:assert/strict';
import { validateStoryInput } from '../src/director/input.js';
import { analyzeStory } from '../src/director/analyzer.js';
import { extractCharacters } from '../src/director/characters.js';
import { planScenes } from '../src/director/scenes.js';
import { validateDirectorPlan } from '../src/director/schema.js';
import { buildDirectorPlan } from '../src/director/buildPlan.js';

test('input rejects too-short story', () => { assert.equal(validateStoryInput({story:'tiny'}).ok, false); });
test('input accepts valid story', () => { assert.equal(validateStoryInput({story:'A boy discovers a hidden kingdom and must save his village.'}).ok, true); });
test('analyzer identifies themes and premise', () => { const a = analyzeStory('A boy discovers a hidden kingdom. He must save the village.'); assert.ok(a.themes.includes('fantasy')); assert.ok(a.premise.length > 0); });
test('fallback character extractor returns stable IDs for same input', () => { const story='Mira finds a map. Mira meets Arjun.'; assert.deepEqual(extractCharacters(story), extractCharacters(story)); });
test('scene planner returns scenes', () => { assert.ok(planScenes('First event happens.\n\nSecond event happens.', 'medium').length >= 1); });
test('fallback director returns valid structured plan', async () => { const out = await buildDirectorPlan({story:'A boy discovers an ancient kingdom and must save his village.',length:'medium',style:'cinematic',language:'English'}, null); assert.equal(out.mode, 'fallback'); assert.equal(validateDirectorPlan(out.plan).valid, true); });
