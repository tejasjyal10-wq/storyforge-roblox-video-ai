# API smoke requests

## Health
GET /api/health

## Director plan
POST /api/director/plan
Content-Type: application/json

{
  "story": "A young explorer discovers a hidden city and must protect its people.",
  "length": "medium",
  "style": "cinematic animation",
  "language": "English"
}
