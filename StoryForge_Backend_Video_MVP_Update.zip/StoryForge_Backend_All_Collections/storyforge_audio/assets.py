"""Tagged sound asset catalog. Assets remain user-supplied/licensed."""
import json
from pathlib import Path
from .models import AudioLayer

class SoundCatalog:
    def __init__(self, root: str):
        self.root = Path(root)
        self.index_path = self.root / "catalog.json"
        self.entries = json.loads(self.index_path.read_text(encoding="utf-8")) if self.index_path.exists() else []

    def search(self, kind: str, tags: list[str]) -> list[str]:
        requested = {t.lower() for t in tags}
        matches = []
        for entry in self.entries:
            if entry.get("kind") != kind:
                continue
            entry_tags = {t.lower() for t in entry.get("tags", [])}
            if requested and requested.intersection(entry_tags):
                file = self.root / entry["file"]
                if file.exists(): matches.append(str(file))
        return matches


class CatalogResolver:
    def __init__(self, catalog: SoundCatalog):
        self.catalog = catalog

    def resolve(self, layers: list[AudioLayer]) -> list[AudioLayer]:
        resolved = []
        for layer in layers:
            if layer.file:
                resolved.append(layer); continue
            candidates = self.catalog.search(layer.kind, layer.tags)
            if candidates:
                layer.file = candidates[0]
                resolved.append(layer)
        return resolved
