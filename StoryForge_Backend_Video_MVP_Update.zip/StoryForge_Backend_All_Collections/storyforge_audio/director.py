"""Rule-based audio direction scaffold that can be replaced/augmented by an AI director."""
from .models import AudioScene, AudioLayer


MOOD_MUSIC = {
    "suspense": ["suspense", "tension", "dark", "pulse"],
    "sad": ["sad", "emotional", "piano", "reflective"],
    "happy": ["happy", "bright", "uplifting", "playful"],
    "action": ["action", "epic", "fast", "intense"],
    "peaceful": ["peaceful", "calm", "soft", "ambient"],
    "mystery": ["mystery", "mysterious", "curious", "dark"],
}

class AudioDirector:
    def plan(self, scene: AudioScene) -> list[AudioLayer]:
        layers = list(scene.layers)
        env = scene.environment.lower()
        mood = scene.mood.lower()
        if env and not any(x.kind == "ambience" for x in layers):
            layers.append(AudioLayer("ambience", "", start=0, volume=0.28, duration=scene.duration, tags=[env]))
        if mood and mood not in {"neutral", "none"} and not any(x.kind == "music" for x in layers):
            layers.append(AudioLayer("music", "", start=0, volume=0.18, duration=scene.duration, tags=MOOD_MUSIC.get(mood, [mood])))
        for line in scene.dialogue:
            if line.emotion and line.emotion != "neutral":
                line.rate = {"excited": 1.08, "urgent": 1.12, "sad": 0.88, "calm": 0.92, "angry": 1.05, "whisper": 0.9}.get(line.emotion, 1.0)
        return layers
