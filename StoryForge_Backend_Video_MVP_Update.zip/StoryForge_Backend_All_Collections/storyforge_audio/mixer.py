"""FFmpeg-based timeline mixer; fails clearly if FFmpeg is missing or inputs are invalid."""
import shutil, subprocess
from pathlib import Path
from .models import AudioLayer
class FFmpegMixer:
    def __init__(self, executable: str = "ffmpeg"):
        self.executable = executable
    def available(self) -> bool:
        return shutil.which(self.executable) is not None
    def mix(self, layers: list[AudioLayer], output_file: str, duration: float | None = None, peak: float = 0.95) -> str:
        if not layers: raise ValueError("No audio layers to mix")
        if not self.available(): raise RuntimeError("FFmpeg not found. Install FFmpeg and ensure it is on PATH.")
        for layer in layers:
            if not layer.file or not Path(layer.file).is_file():
                raise FileNotFoundError(f"Audio layer file missing: {layer.file}")
        Path(output_file).parent.mkdir(parents=True, exist_ok=True)
        inputs=[]; filters=[]
        for i, layer in enumerate(layers):
            inputs += ["-i", layer.file]
            chain=f"[{i}:a]volume={max(0.0, layer.volume)},adelay={int(max(0,layer.start)*1000)}|{int(max(0,layer.start)*1000)}"
            if layer.duration is not None: chain += f",atrim=duration={max(0.01, layer.duration)}"
            if layer.fade_in > 0: chain += f",afade=t=in:st=0:d={layer.fade_in}"
            if layer.fade_out > 0 and layer.duration is not None: chain += f",afade=t=out:st={max(0,layer.duration-layer.fade_out)}:d={layer.fade_out}"
            chain += f",aresample=44100[{i}a]"
            filters.append(chain)
        mix_inputs="".join(f"[{i}a]" for i in range(len(layers)))
        filter_complex=";".join(filters)+f";{mix_inputs}amix=inputs={len(layers)}:duration={'longest' if duration is None else 'first'}:dropout_transition=0,alimiter=limit={peak}[mix]"
        cmd=[self.executable,"-y",*inputs,"-filter_complex",filter_complex,"-map","[mix]"]
        if duration is not None: cmd += ["-t",str(duration)]
        cmd += ["-c:a","aac","-b:a","192k",output_file]
        proc=subprocess.run(cmd,capture_output=True,text=True)
        if proc.returncode: raise RuntimeError(f"FFmpeg mix failed: {proc.stderr[-2000:]}")
        if not Path(output_file).exists() or Path(output_file).stat().st_size == 0: raise RuntimeError("Mixer produced no output")
        return output_file
