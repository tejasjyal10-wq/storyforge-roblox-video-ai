from dataclasses import dataclass, field
from typing import Optional

@dataclass
class DialogueLine:
    character_id: str
    text: str
    start: float = 0.0
    emotion: str = "neutral"
    rate: float = 1.0
    output_file: Optional[str] = None

@dataclass
class AudioLayer:
    kind: str  # voice, music, sfx, ambience
    file: str
    start: float = 0.0
    volume: float = 1.0
    duration: Optional[float] = None
    fade_in: float = 0.0
    fade_out: float = 0.0
    tags: list[str] = field(default_factory=list)

@dataclass
class AudioScene:
    scene_id: str
    duration: float
    mood: str = "neutral"
    environment: str = ""
    action_tags: list[str] = field(default_factory=list)
    dialogue: list[DialogueLine] = field(default_factory=list)
    layers: list[AudioLayer] = field(default_factory=list)

@dataclass
class AudioJob:
    scenes: list[AudioScene]
    output_file: str
    narration: Optional[str] = None
    narration_voice_id: str = "narrator"
    sample_rate: int = 22050
    mix_peak: float = 0.95
