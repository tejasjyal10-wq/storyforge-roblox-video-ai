"""Audio production pipeline: plan -> synthesize dialogue -> resolve catalog -> mix."""
from pathlib import Path
from .director import AudioDirector
from .voices import VoiceRegistry
from .tts import TTSProvider
from .assets import CatalogResolver
from .mixer import FFmpegMixer
from .models import AudioJob, AudioLayer
class AudioPipeline:
    def __init__(self, voices: VoiceRegistry, tts: TTSProvider, catalog: CatalogResolver, mixer: FFmpegMixer | None = None, director: AudioDirector | None = None):
        self.voices=voices; self.tts=tts; self.catalog=catalog; self.mixer=mixer or FFmpegMixer(); self.director=director or AudioDirector()
    def render(self, job: AudioJob) -> str:
        Path(job.output_file).parent.mkdir(parents=True, exist_ok=True)
        layers=[]
        scene_offset = 0.0
        for scene in job.scenes:
            planned = self.director.plan(scene)
            for layer in planned:
                layer.start += scene_offset
                layers.append(layer)
            for index,line in enumerate(scene.dialogue):
                profile=self.voices.get(line.character_id)
                voice_file=line.output_file or str(Path(job.output_file).with_name(f"{scene.scene_id}_{index}_{line.character_id}.wav"))
                self.tts.synthesize(line.text, profile, voice_file, line.rate)
                layers.append(AudioLayer("voice", voice_file, start=scene_offset + line.start, volume=1.0, tags=[line.character_id,line.emotion]))
            scene_offset += scene.duration
        if job.narration:
            profile=self.voices.get(job.narration_voice_id)
            narration_file=str(Path(job.output_file).with_name("narration.wav"))
            self.tts.synthesize(job.narration, profile, narration_file)
            layers.append(AudioLayer("voice", narration_file, start=0, volume=1.0, tags=["narration"]))
        layers=self.catalog.resolve(layers)
        if not layers: raise RuntimeError("Audio Director produced no resolvable audio layers")
        return self.mixer.mix(layers, job.output_file, duration=sum(s.duration for s in job.scenes), peak=job.mix_peak)
