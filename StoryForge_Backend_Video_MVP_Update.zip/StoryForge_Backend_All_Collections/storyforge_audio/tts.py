"""TTS adapter. Piper is a local, optional executable/model backend."""
import subprocess
from pathlib import Path
from .voices import VoiceProfile


class TTSProvider:
    def synthesize(self, text: str, profile: VoiceProfile, output_path: str, rate: float = 1.0) -> str:
        raise NotImplementedError


class PiperTTS(TTSProvider):
    def __init__(self, executable: str = "piper"):
        self.executable = executable

    def synthesize(self, text: str, profile: VoiceProfile, output_path: str, rate: float = 1.0) -> str:
        if not text.strip():
            raise ValueError("TTS text cannot be empty")
        model = Path(profile.model_path)
        if not model.exists():
            raise FileNotFoundError(f"Piper voice model not found: {model}")
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        command = [self.executable, "--model", str(model), "--output_file", output_path]
        if profile.speaker >= 0:
            command.extend(["--speaker", str(profile.speaker)])
        # Piper CLI rate is provider/version dependent. Profile rate is applied to text audio later if supported.
        proc = subprocess.run(command, input=text, text=True, capture_output=True, check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"Piper synthesis failed ({proc.returncode}): {proc.stderr.strip()}")
        if not Path(output_path).exists() or Path(output_path).stat().st_size == 0:
            raise RuntimeError("TTS reported success but no audio file was produced")
        return output_path
