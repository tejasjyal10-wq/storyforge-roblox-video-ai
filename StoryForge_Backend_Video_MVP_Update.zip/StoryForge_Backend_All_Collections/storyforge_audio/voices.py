"""Persistent voice profiles; stable voice IDs map to explicit TTS settings."""
import json
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass
class VoiceProfile:
    character_id: str
    voice_id: str
    model_path: str
    speaker: int = 0
    rate: float = 1.0
    pitch: float = 0.0  # reserved for providers that support pitch control
    language: str = "en"
    notes: str = ""

class VoiceRegistry:
    def __init__(self, path: str):
        self.path = Path(path)
        self._profiles: dict[str, VoiceProfile] = {}
        if self.path.exists():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self._profiles = {k: VoiceProfile(**v) for k, v in data.items()}

    def get(self, character_id: str) -> VoiceProfile:
        if character_id not in self._profiles:
            raise KeyError(f"No voice profile assigned to character '{character_id}'")
        return self._profiles[character_id]


    def set(self, profile: VoiceProfile) -> None:
        if not profile.character_id or not profile.voice_id or not profile.model_path:
            raise ValueError("character_id, voice_id, and model_path are required")
        if profile.rate <= 0:
            raise ValueError("voice rate must be greater than zero")
        self._profiles[profile.character_id] = profile
        self.save()

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps({k: asdict(v) for k, v in self._profiles.items()}, indent=2), encoding="utf-8")

    def all(self) -> dict[str, VoiceProfile]:
        return dict(self._profiles)
