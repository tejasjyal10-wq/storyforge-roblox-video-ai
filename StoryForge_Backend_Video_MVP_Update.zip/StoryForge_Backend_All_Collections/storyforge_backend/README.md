# StoryForge Backend — All Collections


Portable Python backend foundations across Collections 1–5, audio, core orchestration,
and an optional API. External runtimes and services are adapters and are not presumed live.

## Included
- Core configuration, JSON persistence, validation, logging, bounded retries, orchestrator
- Collection 1: rule-first Story Director, memory, continuity, dialogue contracts; optional model-provider integration
- Collection 1 foundation upgrade: richer story models, project memory, analysis, scene planning, heuristic checks, optional OpenAI-compatible provider
- Collection 2: stage pipeline, asset registry, recovery planning
- Collection 3: creative planning, persistent-ready character library structures, story outline/beat sheet
- Collection 4: Blender script runner adapter, FFprobe probe, manifests and transition planning
- Collection 5: Roblox bootstrap/export specs for scene metadata, obstacles, checkpoints and triggers
- Audio: mood planning, voice registries, TTS adapter, tagged asset catalog, Piper adapter, FFmpeg mixer and pipeline
- Optional FastAPI endpoints: `/health`, `/plan`, `/pipeline`, `/export/roblox`

## Setup
Python 3.11+ recommended. Base modules use the Python standard library.

Install optional API dependencies: `pip install -r requirements-optional.txt`
Run API from this folder: `uvicorn storyforge_backend.api.app:create_app --factory --host 127.0.0.1 --port 8000`

Run tests: `python -m unittest discover -s tests -v` (or `pytest -q`)

## Model configuration (optional)
Set `STORYFORGE_AI_BASE_URL`, `STORYFORGE_AI_MODEL`, and `STORYFORGE_AI_API_KEY` for an
OpenAI-compatible `/chat/completions` endpoint. Provider calls have not been live-tested.


## Audio/3D external runtime setup
- FFmpeg and FFprobe are required for audio mixing/media probing. Both were available and tested in this verification environment.
- Piper executable and a compatible voice model are required for local TTS; neither was installed here.
- Blender must be installed for actual renders; not installed here.
- Roblox Studio/Luau is required to execute and validate exports; not available here.


## Verification boundaries
The included tests verify portable logic and selected real integrations, not production
video generation end-to-end. The pipeline has unregistered stage handlers and reports
`partial` when stages are skipped. Roblox export creates a bootstrap/spec, not a fully
realized Studio world. AI generation, Blender, TTS, Roblox execution, frontend and deployed
Worker integrations remain unverified.

## Video generation MVP (fallback renderer)

The `/generate-video` API endpoint now renders a playable H.264 MP4 using the bundled deterministic storyboard renderer. It creates stylized scene cards with titles, locations, descriptions, and beat text. This is a **fallback storyboard video**, not AI-generated footage, character animation, or synthesized audio. Requires FFmpeg installed and on PATH.


Example request:
```json
{
  "project": {
    "title": "A Small Adventure",
    "synopsis": "A traveler discovers a mystery.",
    "scenes": [
      {"title": "Arrival", "location": "Forest path", "purpose": "The traveler arrives.", "beats": ["Explore", "Notice a light"]}
    ]
  },
  "scene_seconds": 4
}
```
The response includes an output path and a download URL under `/videos/<project_id>.mp4`.
