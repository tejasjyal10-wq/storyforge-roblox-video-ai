"""Optional FastAPI surface. Install fastapi/uvicorn to run; no hard dependency."""
def create_app(orchestrator=None):
    try:
        from fastapi import FastAPI, HTTPException
    except ImportError as e:
        raise RuntimeError('Install FastAPI to use HTTP API: pip install fastapi uvicorn') from e
    from pathlib import Path
    from ..core.orchestrator import BackendOrchestrator
    engine = orchestrator or BackendOrchestrator()
    app = FastAPI(title='StoryForge Backend API', version='0.1.0')

    @app.get('/health')
    def health():
        return {'status': 'ok', 'service': 'storyforge-backend'}

    @app.post('/plan')
    def plan(payload: dict):
        if not isinstance(payload, dict):
            raise HTTPException(400, 'JSON object required')
        if payload.get('scenes') is not None and not isinstance(payload.get('scenes'), list):
            raise HTTPException(400, 'scenes must be a list')
        try:
            return engine.create_plan(payload)
        except (TypeError, ValueError, KeyError) as e:
            raise HTTPException(400, f'Invalid project payload: {e}')

    @app.post('/pipeline')
    def pipeline(payload: dict):
        plan_data = payload.get('plan')
        if not isinstance(plan_data, dict):
            raise HTTPException(400, 'plan object required')
        stages = payload.get('stages')
        if stages is not None and (not isinstance(stages, list) or not all(isinstance(x, str) for x in stages)):
            raise HTTPException(400, 'stages must be a list of strings')
        return engine.run_pipeline(plan_data, stages)

    @app.post('/generate-video')
    def generate_video(payload: dict):
        from pathlib import Path
        plan_data = payload.get('plan')
        project_data = payload.get('project')
        if plan_data is None and isinstance(project_data, dict):
            plan_data = engine.create_plan(project_data)
        if not isinstance(plan_data, dict):
            raise HTTPException(400, 'plan or project object required')
        seconds = payload.get('scene_seconds', 4)
        try:
            seconds = float(seconds)
            if not 1 <= seconds <= 30: raise ValueError('scene_seconds must be between 1 and 30')
        except (TypeError, ValueError) as e:
            raise HTTPException(400, str(e))
        output_root = Path(engine.config.data_dir).resolve() / 'videos'
        output_root.mkdir(parents=True, exist_ok=True)
        filename = str(plan_data.get('project_id', 'storyforge_video')).replace('/', '_').replace('\\', '_') + '.mp4'
        output_path = output_root / filename
        result = engine.generate_video(plan_data, output_path, scene_seconds=seconds)
        if result.get('status') != 'completed':
            raise HTTPException(500, result)
        result['download_url'] = f'/videos/{filename}'
        return result

    @app.post('/export/roblox')
    def roblox(payload: dict):
        plan_data = payload.get('plan')
        requested_path = payload.get('output_path')
        if not isinstance(plan_data, dict) or not isinstance(requested_path, str) or not requested_path.strip():
            raise HTTPException(400, 'plan and output_path required')
        root = Path(engine.config.roblox_output_dir).resolve()
        requested = Path(requested_path)
        target = (root / requested).resolve() if not requested.is_absolute() else requested.resolve()
        if target != root and root not in target.parents:
            raise HTTPException(400, 'output_path must remain inside the configured Roblox export directory')
        if target.suffix.lower() not in ('.lua', '.luau'):
            raise HTTPException(400, 'output_path must use .lua or .luau')
        return engine.export_roblox(plan_data, str(target))

    from fastapi.staticfiles import StaticFiles
    video_root = Path(engine.config.data_dir).resolve() / 'videos'
    video_root.mkdir(parents=True, exist_ok=True)
    app.mount('/videos', StaticFiles(directory=str(video_root)), name='videos')

    return app
