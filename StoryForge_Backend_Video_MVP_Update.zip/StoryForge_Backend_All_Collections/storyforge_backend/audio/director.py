class AudioDirector:
    MOOD_MAP={'suspense':['low tension bed','sparse ambience','silence before reveal'],'joy':['bright rhythm','warm ambience'],'sadness':['restrained music','soft room tone'],'action':['rhythmic score','action sync effects'],'neutral':['location ambience']}
    def plan_scene(self, scene):
        mood=(scene.get('emotion') or 'neutral').lower(); layers=self.MOOD_MAP.get(mood,self.MOOD_MAP['neutral'])
        return {'scene_id':scene.get('id'),'mood':mood,'layers':layers,'dialogue':scene.get('dialogue',[]),'sfx_events':[{'beat':b,'sound_search_tags':[str(b).lower()]} for b in scene.get('beats',[])],'duck_music_on_dialogue':True}
    def plan_project(self, project): return [self.plan_scene(s) for s in project.get('scenes',[])]
