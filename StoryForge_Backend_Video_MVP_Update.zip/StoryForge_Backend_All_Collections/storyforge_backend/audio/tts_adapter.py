class TTSAdapter:
    def __init__(self, provider=None): self.provider=provider
    def synthesize(self, text, voice_profile, output_path):
        if not text.strip(): return {'status':'failed','error':'Empty dialogue'}
        if not self.provider: return {'status':'unavailable','reason':'No TTS provider configured','text':text,'voice_profile':voice_profile}
        return self.provider.synthesize(text,voice_profile,output_path)
