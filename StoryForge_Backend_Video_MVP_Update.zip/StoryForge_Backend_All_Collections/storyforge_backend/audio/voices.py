class VoiceProfileRegistry:
    def __init__(self, profiles=None): self.profiles={p['character_id']:p for p in (profiles or [])}
    def assign(self, character_id, profile):
        p=dict(profile); p['character_id']=character_id; self.profiles[character_id]=p; return p
    def get(self, character_id): return self.profiles.get(character_id)
    def validate_cast(self, cast): return [c.get('id') for c in cast if c.get('id') not in self.profiles]
