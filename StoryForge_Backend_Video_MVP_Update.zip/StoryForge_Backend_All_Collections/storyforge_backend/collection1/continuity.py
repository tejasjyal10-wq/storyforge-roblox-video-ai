def check(project, memory=None):
    memory=memory or {}; issues=[]
    scenes=project.get('scenes',[]); ids=[s.get('id') for s in scenes]
    if len(ids)!=len(set(ids)): issues.append({'type':'duplicate_scene_id','severity':'error'})
    known=set(memory.get('facts',[]))
    for i,s in enumerate(scenes):
        if not s.get('purpose'): issues.append({'type':'scene_without_purpose','scene':s.get('id'),'severity':'warning'})
        for beat in s.get('beats',[]):
            if not isinstance(beat,str) or not beat.strip(): issues.append({'type':'empty_beat','scene':s.get('id'),'severity':'warning'})
    return issues
