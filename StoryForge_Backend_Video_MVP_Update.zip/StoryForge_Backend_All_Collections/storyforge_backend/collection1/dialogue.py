def dialogue_brief(character, scene_context, line_intent, emotion='neutral'):
    return {'character_id':character.get('id'),'character_name':character.get('name'),
      'traits':character.get('traits',[]),'scene_context':scene_context,'intent':line_intent,
      'emotion':emotion,'constraints':['Keep voice consistent with character profile','Avoid adding canon facts not present in context']}
def validate_dialogue(lines, cast_ids):
    errors=[]
    for i,line in enumerate(lines):
        if line.get('speaker_id') not in cast_ids: errors.append(f'Line {i}: speaker not in cast')
        if not line.get('text','').strip(): errors.append(f'Line {i}: empty text')
    return errors
