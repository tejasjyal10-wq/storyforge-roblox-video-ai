class StoryDirector:
    """Model-assisted analyst with transparent heuristic fallback."""
    THEMES=('friendship','family','courage','identity','responsibility','technology','nature','justice','hope','belonging')
    def __init__(self, store=None, provider=None):
        self.store=store
        self.provider=provider
    def analyze(self, project):
        if self.provider and getattr(self.provider, 'configured', False):
            import json
            prompt=json.dumps(project, ensure_ascii=False)
            try:
                result=self.provider.generate_json(
                    'Analyze the story project. Return valid JSON with premise, themes, conflict, stakes, genre, audience, characters, conflict_signals, strengths, risks. Ground every claim in the supplied project; do not invent canon.',
                    prompt)
                if not isinstance(result, dict):
                    raise TypeError('AI analysis must be a JSON object')
                result.setdefault('limitations', [])
                result['analysis_mode']='model'
                return result
            except Exception as e:
                fallback=self._heuristic(project)
                fallback['provider_error']=f'{type(e).__name__}: {e}'
                fallback['analysis_mode']='heuristic_fallback'
                return fallback
        result=self._heuristic(project)
        result['analysis_mode']='heuristic'
        return result
    def _heuristic(self, project):
        text=' '.join([project.get('synopsis','')]+[s.get('purpose','')+' '+' '.join(s.get('beats',[])) for s in project.get('scenes',[])])
        low=text.lower(); themes=[t for t in self.THEMES if t in low]
        return {'premise':project.get('synopsis',''),'themes':themes,'genre':project.get('genre',''),
                'scene_count':len(project.get('scenes',[])),'characters':project.get('cast',[]),
                'conflict_signals':[w for w in ('conflict','danger','must','mystery','problem','goal') if w in low],
                'limitations':['This analysis is heuristic unless an AI model provider is configured.']}
    def evaluate(self, plan):
        scenes=plan.get('scenes',[]); checks={'has_scenes':bool(scenes),
          'scene_ids_unique':len([s.get('id') for s in scenes])==len(set(s.get('id') for s in scenes)),
          'scene_purpose_present':all(bool(s.get('purpose')) for s in scenes),
          'scene_beats_present':all(bool(s.get('beats')) for s in scenes),
          'cast_declared':bool(plan.get('cast',[]))}
        return {'score':round(100*sum(checks.values())/len(checks)),'checks':checks,'issues':[k for k,v in checks.items() if not v],'type':'heuristic'}
