from ..core.storage import JSONStore
class ProjectMemory:
    def __init__(self, store): self.store=store
    def load(self, project_id): return self.store.read('memory_'+project_id, {'project_id':project_id,'facts':[],'timeline':[],'character_states':{},'scene_history':[],'open_threads':[],'decisions':[]})
    def save(self, project_id, memory): return self.store.write('memory_'+project_id,memory)
    def add_fact(self, memory, fact):
        if fact and fact not in memory['facts']: memory['facts'].append(fact)
        return memory
    def append_event(self, memory, event): memory['timeline'].append(event); return memory
