# StoryForge Collection 1 AI Backend Upgrade (foundation package)

This is a portable upgrade package for the AI Intelligence & Story Director. It adds project memory, structured character/story models, deterministic story analysis, scene planning, continuity heuristics, quality checklist scoring, and an optional OpenAI-compatible model adapter.

## Honest limitations
- Without configured model credentials, analysis and directing are heuristic/rule-based.
- Model adapter is optional and has not been tested against a live endpoint.
- Continuity checks are conservative heuristic checks, not semantic proof.
- This package is not connected to the deployed StoryForge Worker or frontend.
- No real video, Blender, Roblox, TTS, or external model calls are performed by the tests.

## Run tests
`python -m unittest discover -s tests -v`

## Optional model provider configuration
Set environment variables:
- `STORYFORGE_AI_BASE_URL`
- `STORYFORGE_AI_MODEL`
- `STORYFORGE_AI_API_KEY`

The adapter expects an OpenAI-compatible `/chat/completions` endpoint returning JSON content.
