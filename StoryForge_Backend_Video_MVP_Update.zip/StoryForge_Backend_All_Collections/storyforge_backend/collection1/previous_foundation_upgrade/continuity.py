import re
from dataclasses import asdict

def check_continuity(scene, memory):
    """Conservative checks only: flags suspicious references; does not rewrite canon."""
    findings=[]
    text = " ".join([scene.get("purpose",""), *scene.get("beats",[]), *scene.get("continuity_notes",[])])
    known_names = {c.name.lower() for c in memory.character_states.values()}
    referenced = {m.group(0).lower() for m in re.finditer(r"\b[A-Z][a-z]{2,}\b", text)}
    unknown = sorted(referenced-known_names)
    if unknown:
        findings.append({"severity":"info","type":"unregistered_name","message":"Names may be unregistered characters or ordinary words: "+", ".join(unknown)})
    known_locations={x.get("location","").lower() for x in memory.scene_summaries if x.get("location")}
    loc=scene.get("location","").lower()
    if known_locations and loc and loc not in known_locations:
        findings.append({"severity":"info","type":"new_location","message":f"Location '{scene.get('location')}' is new to recorded scenes."})
    for fact in memory.canon_facts:
        # only flag direct simple contradictions; broad natural language inference is intentionally avoided
        if "never " in fact.lower() and any(term in text.lower() for term in re.findall(r"\w+", fact.lower().replace("never ",""))[:2]):
            findings.append({"severity":"warning","type":"possible_canon_conflict","message":f"Scene may conflict with canon fact: {fact}"})
    return findings
