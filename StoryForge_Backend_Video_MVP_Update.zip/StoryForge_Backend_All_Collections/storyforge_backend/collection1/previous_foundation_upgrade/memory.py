import json, os, threading
from dataclasses import asdict
from .models import StoryMemory, CharacterState

class MemoryStore:
    """Project-scoped JSON memory. Uses atomic replace to avoid partial writes."""
    def __init__(self, directory="storyforge_memory"):
        self.directory = directory
        os.makedirs(directory, exist_ok=True)
        self._lock = threading.RLock()

    def _path(self, project_id):
        safe = "".join(c for c in str(project_id) if c.isalnum() or c in "-_") or "default"
        return os.path.join(self.directory, safe + ".json")

    def load(self, project_id):
        path = self._path(project_id)
        if not os.path.exists(path):
            return StoryMemory(project_id=project_id)
        with self._lock, open(path, encoding="utf-8") as f:
            raw = json.load(f)
        raw["character_states"] = {k: CharacterState(**v) for k, v in raw.get("character_states", {}).items()}
        return StoryMemory(**raw)

    def save(self, memory):
        path = self._path(memory.project_id)
        payload = asdict(memory)
        with self._lock:
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)
            os.replace(tmp, path)
        return path

    def add_fact(self, memory, fact):
        if fact and fact not in memory.canon_facts:
            memory.canon_facts.append(fact)
        return memory

    def record_decision(self, memory, category, decision, reason=""):
        memory.decisions.append({"category": category, "decision": decision, "reason": reason})
        return memory
