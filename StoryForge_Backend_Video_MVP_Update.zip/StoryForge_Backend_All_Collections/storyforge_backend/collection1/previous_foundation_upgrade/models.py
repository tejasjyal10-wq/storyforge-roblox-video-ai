from dataclasses import dataclass, field, asdict
from typing import Any

@dataclass
class CharacterState:
    id: str
    name: str
    traits: list[str] = field(default_factory=list)
    goals: list[str] = field(default_factory=list)
    relationships: dict[str, str] = field(default_factory=dict)
    knowledge: list[str] = field(default_factory=list)
    emotional_state: str = "neutral"
    arc_notes: list[str] = field(default_factory=list)

@dataclass
class ScenePlan:
    id: str
    title: str
    location: str
    characters: list[str] = field(default_factory=list)
    purpose: str = ""
    beats: list[str] = field(default_factory=list)
    emotion: str = "neutral"
    camera_suggestions: list[str] = field(default_factory=list)
    audio_suggestions: list[str] = field(default_factory=list)
    continuity_notes: list[str] = field(default_factory=list)

@dataclass
class StoryMemory:
    project_id: str
    summary: str = ""
    canon_facts: list[str] = field(default_factory=list)
    timeline: list[dict[str, Any]] = field(default_factory=list)
    character_states: dict[str, CharacterState] = field(default_factory=dict)
    scene_summaries: list[dict[str, Any]] = field(default_factory=list)
    unresolved_threads: list[str] = field(default_factory=list)
    decisions: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class StoryAnalysis:
    premise: str
    themes: list[str] = field(default_factory=list)
    conflict: str = ""
    stakes: str = ""
    genre: str = ""
    audience: str = ""
    strengths: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)

def to_dict(obj):
    if hasattr(obj, "__dataclass_fields__"):
        return asdict(obj)
    return obj
