from .reasoning import analyze_story, plan_scene
from .quality import evaluate_story, validate_scene
from .continuity import check_continuity
from .memory import MemoryStore

class StoryDirector:
    """Local deterministic workflow. Model integration is opt-in and not assumed live."""
    def __init__(self, memory_store=None, provider=None):
        self.memory_store=memory_store or MemoryStore()
        self.provider=provider

    def analyze(self, story, genre="", audience=""):
        if self.provider and self.provider.configured:
            result=self.provider.generate_json(
                "Analyze the story. Return JSON with premise, themes, conflict, stakes, genre, audience, strengths, risks.",
                story)
            return result
        return analyze_story(story, genre, audience).__dict__

    def plan(self, project_id, story, scenes):
        memory=self.memory_store.load(project_id)
        analysis=self.analyze(story)
        planned=[]
        for raw in scenes:
            s=plan_scene(raw.get("id",""),raw.get("title",""),raw.get("location",""),
                raw.get("characters",[]),raw.get("purpose",""),raw.get("beats",[]),raw.get("emotion","neutral"))
            s["continuity_findings"]=check_continuity(s,memory)
            errors=validate_scene(s)
            s["validation_errors"]=errors
            planned.append(s)
            memory.scene_summaries.append({"id":s["id"],"title":s["title"],"location":s["location"],"summary":s["purpose"]})
        report=evaluate_story(story,planned)
        memory.summary=analysis.get("premise","") if isinstance(analysis,dict) else str(analysis)
        self.memory_store.save(memory)
        return {"analysis":analysis,"scenes":planned,"quality_report":report,"project_id":project_id}
