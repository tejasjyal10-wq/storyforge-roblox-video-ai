def evaluate_story(story_text, scenes=None):
    """Transparent checklist-style score; not a substitute for semantic model evaluation."""
    text=(story_text or "").strip()
    scenes=scenes or []
    checks={
      "nonempty_story": bool(text),
      "has_multiple_story_beats": len([x for x in text.split(".") if x.strip()])>=3,
      "scenes_have_purpose": bool(scenes) and all(bool(s.get("purpose")) for s in scenes),
      "scenes_have_beats": bool(scenes) and all(bool(s.get("beats")) for s in scenes),
      "scene_ids_unique": len({s.get("id") for s in scenes})==len(scenes),
    }
    score=round(100*sum(checks.values())/len(checks))
    issues=[k for k,v in checks.items() if not v]
    return {"score":score,"checks":checks,"issues":issues,
            "label":"heuristic checklist score; no generative model judge used"}

def validate_scene(scene):
    errors=[]
    for key in ("id","title","location","purpose"):
        if not scene.get(key): errors.append(f"Missing required field: {key}")
    if not isinstance(scene.get("beats",[]),list): errors.append("beats must be a list")
    if not isinstance(scene.get("characters",[]),list): errors.append("characters must be a list")
    return errors
