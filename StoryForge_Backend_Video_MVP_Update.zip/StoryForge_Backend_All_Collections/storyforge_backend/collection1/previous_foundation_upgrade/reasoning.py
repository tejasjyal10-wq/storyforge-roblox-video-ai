from .models import StoryAnalysis

def analyze_story(story_text, genre="", audience=""):
    text=(story_text or "").strip()
    if not text:
        raise ValueError("story_text is required")
    sentences=[s.strip() for s in text.replace("\n"," ").split(".") if s.strip()]
    # Heuristic analysis is clearly labeled; real model provider may replace/enrich this.
    conflict_terms=("but","however","against","danger","problem","conflict","must","only","cannot","can't")
    theme_terms=("friendship","family","courage","identity","responsibility","technology","nature","justice","hope")
    lower=text.lower()
    themes=[t for t in theme_terms if t in lower]
    conflicts=[s for s in sentences if any(k in s.lower() for k in conflict_terms)]
    premise=sentences[0] if sentences else text[:240]
    risks=[]
    if len(sentences)<3: risks.append("Short input: story structure may be underspecified.")
    if not conflicts: risks.append("No explicit conflict detected; verify dramatic tension.")
    return StoryAnalysis(premise=premise, themes=themes,
        conflict=" ".join(conflicts) or "Conflict not clearly detected.",
        stakes="Needs author/model clarification; not inferred confidently from sparse text.",
        genre=genre, audience=audience,
        strengths=["Story input preserved","Analysis is traceable to provided text"],
        risks=risks)

def plan_scene(scene_id, title, location, characters, purpose, beats, emotion="neutral"):
    return {
      "id":scene_id,"title":title,"location":location,"characters":characters or [],
      "purpose":purpose,"beats":beats or [],"emotion":emotion,
      "camera_suggestions":_camera_for(emotion, beats or []),
      "audio_suggestions":_audio_for(emotion, beats or []),
      "continuity_notes":[]
    }

def _camera_for(emotion, beats):
    e=(emotion or "").lower()
    if e in ("fear","suspense","mystery"): return ["Use establishing shot to orient","Favor controlled close-ups during reveal","Hold reaction beat before cutting"]
    if e in ("joy","excitement","celebration"): return ["Use wider energetic coverage","Consider gentle tracking during movement"]
    if e in ("sadness","grief"): return ["Use longer holds","Favor restrained close-ups"]
    if e in ("action","anger"): return ["Use clear spatial wide shot","Cut to inserts for important actions"]
    return ["Establish geography","Use shot size changes to emphasize story beats"]

def _audio_for(emotion, beats):
    e=(emotion or "").lower()
    if e in ("fear","suspense","mystery"): return ["Low-intensity suspense bed","Sparse environmental detail","Pause or duck music at reveal"]
    if e in ("joy","excitement","celebration"): return ["Bright rhythmic bed","Layer environmental activity"]
    if e in ("sadness","grief"): return ["Restrained music or silence","Soft ambience"]
    if e in ("action","anger"): return ["Rhythmic impacts as justified by actions","Music with clear transient space"]
    return ["Scene ambience appropriate to location","Music only if it supports the scene"]
