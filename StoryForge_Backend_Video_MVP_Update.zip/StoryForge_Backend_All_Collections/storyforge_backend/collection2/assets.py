from pathlib import Path
class AssetRegistry:
    def __init__(self, root='assets'): self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True); self.index={}
    def register(self, asset_id, path, tags=None, kind='generic', metadata=None):
        p=Path(path); self.index[asset_id]={'path':str(p),'tags':list(tags or []),'kind':kind,'metadata':metadata or {},'exists':p.exists()}; return self.index[asset_id]
    def find(self, tags=None, kind=None):
        tags=set(tags or []); return [v for v in self.index.values() if (not kind or v['kind']==kind) and tags.issubset(set(v['tags']))]
    def missing(self): return [k for k,v in self.index.items() if not v['exists'] ]
