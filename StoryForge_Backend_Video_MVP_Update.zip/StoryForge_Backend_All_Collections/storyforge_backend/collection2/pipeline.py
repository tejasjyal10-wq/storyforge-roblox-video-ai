from dataclasses import dataclass
from time import time

@dataclass
class Stage:
    name: str
    handler: object
    retries: int = 1

class ProductionPipeline:
    DEFAULT_STAGES = ('validate', 'creative_plan', 'audio_plan', 'asset_plan', 'export_plan')

    def __init__(self, handlers=None, max_attempts=3):
        self.handlers = handlers or {}
        self.max_attempts = max(1, int(max_attempts))
        self.history = []

    def register(self, name, handler):
        if not callable(handler):
            raise TypeError('stage handler must be callable')
        self.handlers[name] = handler

    def run(self, plan, stages=None):
        names = self.DEFAULT_STAGES if stages is None else tuple(stages)
        current = dict(plan)
        results = []
        overall = 'completed'
        for name in names:
            handler = self.handlers.get(name)
            if not handler:
                results.append({'stage': name, 'status': 'skipped', 'reason': 'No handler registered; planning output preserved'})
                if overall == 'completed':
                    overall = 'partial'
                continue
            start = time()
            attempts = 0
            error = None
            while attempts < self.max_attempts:
                attempts += 1
                try:
                    out = handler(dict(current))
                    if out is not None and not isinstance(out, dict):
                        raise TypeError('stage handler must return a dict or None')
                    if out:
                        current.update(out)
                    error = None
                    break
                except Exception as e:
                    error = f'{type(e).__name__}: {e}'
            rec = {'stage': name, 'status': 'completed' if error is None else 'failed',
                   'attempts': attempts, 'duration_seconds': round(time()-start, 3), 'error': error}
            results.append(rec)
            self.history.append(rec)
            if error:
                overall = 'failed'
                break
        return {'status': overall, 'results': results, 'plan': current}
