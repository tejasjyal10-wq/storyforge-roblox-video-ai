def recovery_plan(stage, error, attempts=0):
    return {'failed_stage':stage,'error':str(error),'attempts':attempts,'actions':['capture diagnostics','retry with bounded attempts','reset only failed stage outputs','use declared fallback if available','preserve successful stage artifacts'],'requires_manual_attention':True}
