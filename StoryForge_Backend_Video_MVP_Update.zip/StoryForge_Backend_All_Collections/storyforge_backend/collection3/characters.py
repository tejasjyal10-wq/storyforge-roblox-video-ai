import uuid
class CharacterLibrary:
    def __init__(self, characters=None): self.characters={c.get('id'):dict(c) for c in (characters or []) if c.get('id')}
    def add(self, character):
        c=dict(character); c.setdefault('id',str(uuid.uuid4())); c.setdefault('traits',[]); c.setdefault('role',''); c.setdefault('appearance',{}); c.setdefault('voice',{}); c.setdefault('history',[]); self.characters[c['id']]=c; return c
    def get(self, character_id): return self.characters.get(character_id)
    def export(self): return list(self.characters.values())
    def check_duplicate_names(self):
        seen={}; duplicates=[]
        for c in self.characters.values():
            name=c.get('name','').strip().casefold()
            if name in seen: duplicates.append((seen[name],c['id'],name))
            else: seen[name]=c['id']
        return duplicates
