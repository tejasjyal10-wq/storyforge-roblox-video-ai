import re, uuid
class CreativePlanner:
    def normalize_project(self, project):
        p=dict(project); p.setdefault('project_id',str(uuid.uuid4())); p.setdefault('title','Untitled Story'); p.setdefault('synopsis',''); p.setdefault('cast',[]); p.setdefault('scenes',[])
        normalized=[]
        for i,s0 in enumerate(p['scenes']):
            s=dict(s0); s.setdefault('id',f'scene_{i+1}'); s.setdefault('title',f'Scene {i+1}'); s.setdefault('location','Unspecified'); s.setdefault('characters',[]); s.setdefault('purpose',''); s.setdefault('beats',[]); s.setdefault('emotion','neutral'); normalized.append(s)
        p['scenes']=normalized; return p
    def plan(self, project, analysis):
        planned=[]
        for i,s in enumerate(project.get('scenes',[])):
            planned.append({**s,'order':i+1,'transition_hint':self._transition(i,project['scenes']),
              'camera_plan':self._camera(s),'action_plan':self._actions(s),'visual_prompt':self._visual_prompt(project,s)})
        return {**project,'analysis':analysis,'scenes':planned,'production_ready':bool(planned) and all(s.get('purpose') and s.get('beats') for s in planned)}
    def _transition(self,i,scenes):
        return 'establishing transition' if i==0 else 'carry visual or audio motif from previous scene; preserve spatial continuity'
    def _camera(self,s):
        e=s.get('emotion','').lower(); shots=['establish geography','coverage of story beat','reaction shot']
        if e in ('suspense','fear','mystery'): shots=['establish location','controlled close-up','hold reveal reaction']
        if e in ('action','anger'): shots=['wide spatial coverage','action insert','reaction cut']
        return shots
    def _actions(self,s): return [{'beat':b,'visualized_action':b,'needs_motion_review':True} for b in s.get('beats',[])]
    def _visual_prompt(self,p,s):
        return {'project_title':p.get('title'),'scene':s.get('title'),'setting':s.get('location'),'purpose':s.get('purpose'),'beats':s.get('beats'),'mood':s.get('emotion'),'character_refs':s.get('characters'),'continuity':'Maintain established cast, wardrobe, props and setting facts.'}
