def outline_from_scenes(scenes):
    return {'acts':[{'act':1,'label':'Setup','scene_ids':[s.get('id') for s in scenes[:max(1,len(scenes)//3)]]},
                    {'act':2,'label':'Development','scene_ids':[s.get('id') for s in scenes[max(1,len(scenes)//3):max(2,2*len(scenes)//3)]]},
                    {'act':3,'label':'Resolution','scene_ids':[s.get('id') for s in scenes[max(2,2*len(scenes)//3):]]}],
            'note':'Mechanical outline only; validate dramatic structure with a model or human review.'}
def beat_sheet(scene):
    beats=scene.get('beats',[])
    return [{'index':i+1,'beat':b,'function':'user-provided beat'} for i,b in enumerate(beats)]
