from pathlib import Path
def build_manifest(paths):
    items=[]
    for path in paths:
        p=Path(path); items.append({'path':str(p),'exists':p.exists(),'size_bytes':p.stat().st_size if p.exists() else 0,'suffix':p.suffix.lower()})
    return {'assets':items,'count':len(items),'missing':[x['path'] for x in items if not x['exists']]}
