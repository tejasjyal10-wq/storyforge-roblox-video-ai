import subprocess, shutil, os
class RenderManager:
    def __init__(self, config=None): self.config=config
    def blender_available(self): return bool(shutil.which('blender'))
    def run_blender_script(self, script_path, output_dir, timeout=None):
        exe=shutil.which('blender')
        if not exe: return {'status':'unavailable','reason':'Blender executable not found'}
        os.makedirs(output_dir,exist_ok=True)
        cmd=[exe,'-b','--python',str(script_path)]
        try:
            proc=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout or getattr(self.config,'render_timeout_seconds',900))
            return {'status':'completed' if proc.returncode==0 else 'failed','returncode':proc.returncode,'stdout':proc.stdout[-4000:],'stderr':proc.stderr[-4000:]}
        except subprocess.TimeoutExpired as e: return {'status':'timeout','error':str(e)}
    def probe_media(self, path):
        exe=shutil.which('ffprobe')
        if not exe: return {'status':'unavailable','reason':'ffprobe not installed'}
        try:
            p=subprocess.run([exe,'-v','error','-show_format','-show_streams','-of','json',str(path)],capture_output=True,text=True,timeout=30)
            if p.returncode: return {'status':'failed','stderr':p.stderr}
            import json; return {'status':'completed','data':json.loads(p.stdout)}
        except subprocess.TimeoutExpired as e: return {'status':'timeout','error':str(e)}
    def ffmpeg_available(self): return bool(shutil.which('ffmpeg'))
