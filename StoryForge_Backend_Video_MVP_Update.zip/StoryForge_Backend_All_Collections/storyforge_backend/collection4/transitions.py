SUPPORTED=['cut','fade','dissolve','wipe','match_cut','audio_bridge']
def transition_plan(previous_scene, next_scene, style='cut'):
    if style not in SUPPORTED: style='cut'
    same_location=previous_scene.get('location')==next_scene.get('location')
    return {'type':style,'same_location':same_location,'visual_continuity_hint':'preserve geography and props' if same_location else 're-establish new location','audio_bridge':style=='audio_bridge'}
