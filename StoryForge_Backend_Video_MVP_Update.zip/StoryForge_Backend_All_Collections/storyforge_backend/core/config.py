import os
from dataclasses import dataclass

@dataclass
class BackendConfig:
    data_dir: str = os.getenv('STORYFORGE_DATA_DIR', 'storyforge_data')
    ai_base_url: str = os.getenv('STORYFORGE_AI_BASE_URL', '')
    ai_model: str = os.getenv('STORYFORGE_AI_MODEL', '')
    ai_api_key: str = os.getenv('STORYFORGE_AI_API_KEY', '')
    render_timeout_seconds: int = int(os.getenv('STORYFORGE_RENDER_TIMEOUT', '900'))
    max_retries: int = int(os.getenv('STORYFORGE_MAX_RETRIES', '3'))
    roblox_output_dir: str = os.getenv('STORYFORGE_ROBLOX_OUTPUT', 'exports/roblox')
