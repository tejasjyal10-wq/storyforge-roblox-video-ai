import logging, json
def get_logger(name='storyforge'):
    return logging.getLogger(name)
def log_event(logger, event, **fields):
    logger.info(json.dumps({'event':event,**fields},ensure_ascii=False,default=str))
