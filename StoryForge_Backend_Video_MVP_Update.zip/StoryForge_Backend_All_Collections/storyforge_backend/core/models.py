from dataclasses import dataclass, field, asdict
from typing import Any

@dataclass
class StoryProject:
    project_id: str
    title: str = "Untitled Story"
    synopsis: str = ""
    genre: str = ""
    audience: str = ""
    cast: list[dict[str, Any]] = field(default_factory=list)
    scenes: list[dict[str, Any]] = field(default_factory=list)
    settings: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class PipelineStageResult:
    stage: str
    status: str
    output: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

def serialize(obj):
    return asdict(obj) if hasattr(obj, '__dataclass_fields__') else obj
