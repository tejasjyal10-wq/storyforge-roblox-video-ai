import time
def retry_call(fn, attempts=3, backoff=0.25, retry_on=(Exception,)):
    last=None
    for i in range(max(1,attempts)):
        try: return fn()
        except retry_on as e:
            last=e
            if i+1<attempts: time.sleep(backoff*(2**i))
    raise last
