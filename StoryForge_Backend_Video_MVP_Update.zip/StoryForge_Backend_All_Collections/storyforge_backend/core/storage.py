import json, os, tempfile
from pathlib import Path

class JSONStore:
    """Small atomic JSON persistence utility; files are scoped to a data directory."""
    def __init__(self, directory):
        self.root=Path(directory); self.root.mkdir(parents=True, exist_ok=True)
    def _safe(self, key):
        name=''.join(c for c in str(key) if c.isalnum() or c in '-_.') or 'default'
        return self.root/(name+'.json')
    def read(self, key, default=None):
        p=self._safe(key)
        if not p.exists(): return default
        return json.loads(p.read_text(encoding='utf-8'))
    def write(self, key, value):
        p=self._safe(key); p.parent.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(dir=str(p.parent),prefix=p.name, suffix='.tmp')
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as f: json.dump(value,f,ensure_ascii=False,indent=2)
            os.replace(tmp,p)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)
        return str(p)
