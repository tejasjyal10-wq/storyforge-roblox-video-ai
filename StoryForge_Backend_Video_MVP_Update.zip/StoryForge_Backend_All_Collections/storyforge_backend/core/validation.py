REQUIRED_PROJECT=['project_id']
REQUIRED_SCENE=['id','title','location','purpose']
def validate_project(p):
    errors=[]
    for k in REQUIRED_PROJECT:
        if not p.get(k): errors.append('Project missing '+k)
    if not isinstance(p.get('scenes',[]),list): errors.append('scenes must be a list')
    ids=[s.get('id') for s in p.get('scenes',[]) if isinstance(s,dict)]
    if len(ids)!=len(set(ids)): errors.append('scene IDs must be unique')
    for i,s in enumerate(p.get('scenes',[])):
        errors.extend(f'Scene {i}: {e}' for e in validate_scene(s))
    return errors
def validate_scene(s):
    if not isinstance(s,dict): return ['scene must be an object']
    errors=[f'missing {k}' for k in REQUIRED_SCENE if not s.get(k)]
    if not isinstance(s.get('beats',[]),list): errors.append('beats must be a list')
    if not isinstance(s.get('characters',[]),list): errors.append('characters must be a list')
    return errors
