class TextModelProvider:
    """Provider contract. Implementations should return parsed structured outputs."""
    def generate(self, prompt, system=None, schema=None): raise NotImplementedError
class ImageVideoProvider:
    def generate(self, prompt, settings=None): raise NotImplementedError
class AudioProvider:
    def synthesize(self, text, voice_profile, output_path): raise NotImplementedError
