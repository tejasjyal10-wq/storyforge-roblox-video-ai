REQUIRED_ROBLOX_SCENE_FIELDS=('id','title','location','characters','beats')
def validate_scene_export(scene): return [f'missing {k}' for k in REQUIRED_ROBLOX_SCENE_FIELDS if k not in scene]
