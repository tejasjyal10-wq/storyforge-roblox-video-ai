"""Create a playable stylized storyboard MP4 from a StoryForge plan.
This is a deterministic fallback renderer: it renders scene cards with motion, not AI-generated footage."""
from pathlib import Path
import shutil, subprocess, tempfile, textwrap
from PIL import Image, ImageDraw, ImageFont


class VideoRenderer:
    def __init__(self, width=1280, height=720, fps=24):
        self.width, self.height, self.fps = width, height, fps

    def _font(self, size):
        for path in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/truetype/lib/liberation/LiberationSans-Regular.ttf']:
            if Path(path).exists():
                return ImageFont.truetype(path, size)
        return ImageFont.load_default()

    @staticmethod
    def _wrap(text, max_chars=42):
        return textwrap.wrap(str(text or ''), width=max_chars) or ['']

    def _draw_card(self, scene, project_title, index, count, out):
        import textwrap
        img=Image.new('RGB',(self.width,self.height),(16,25,46)); draw=ImageDraw.Draw(img)
        # cinematic layered gradient
        for y in range(self.height):
            t=y/self.height
            col=(int(20+25*t),int(35+12*t),int(65+30*t))
            draw.line((0,y,self.width,y),fill=col)
        draw.ellipse((self.width-330,-180,self.width+100,250),fill=(45,76,110))
        draw.ellipse((-220,self.height-260,260,self.height+200),fill=(36,62,91))
        draw.rectangle((0,self.height-80,self.width,self.height),fill=(10,16,28))
        f_title=self._font(28); f_scene=self._font(50); f_body=self._font(30); f_small=self._font(20)
        draw.text((64,50),project_title[:70],font=f_title,fill=(186,211,239))
        draw.text((64,140),f'SCENE {index+1:02d} / {count:02d}',font=f_small,fill=(138,187,225))
        title=str(scene.get('title') or f'Scene {index+1}')
        draw.text((64,190),title[:55],font=f_scene,fill=(255,255,255))
        location=str(scene.get('location') or 'Setting unspecified')
        draw.text((64,280),f'LOCATION: {location[:70]}',font=f_body,fill=(213,224,239))
        desc=str(scene.get('purpose') or scene.get('description') or scene.get('synopsis') or '')
        beats=scene.get('beats') or []
        lines=textwrap.wrap(desc, width=58)[:4]
        if beats:
            lines += [''] + [f'• {str(b)}' for b in beats[:3]]
        y=350
        for line in lines[:7]:
            draw.text((64,y),line[:100],font=f_body,fill=(230,237,246)); y+=42
        draw.text((64,self.height-50),'STORYFORGE  •  MOTION STORYBOARD PREVIEW',font=f_small,fill=(135,158,183))
        img.save(out)

    def render(self, plan, output_path, scene_seconds=4):
        ffmpeg=shutil.which('ffmpeg')
        if not ffmpeg: return {'status':'unavailable','reason':'ffmpeg not installed'}
        scenes=plan.get('scenes') or [{'title':'Story overview','location':'Abstract setting','purpose':plan.get('synopsis','Story generated from prompt'),'beats':[]}]
        output=Path(output_path).resolve(); output.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='storyforge_video_') as tmp:
            tmp=Path(tmp); frames=[]
            for i,scene in enumerate(scenes):
                p=tmp/f'scene_{i:03d}.png'; self._draw_card(scene,plan.get('title','StoryForge'),i,len(scenes),p); frames.append(p)
            # concat file with per-card holds; final frame must be repeated for concat demuxer
            concat=tmp/'frames.txt'
            with concat.open('w',encoding='utf-8') as f:
                for p in frames: f.write(f"file '{p.as_posix()}'\nduration {float(scene_seconds):.3f}\n")
                f.write(f"file '{frames[-1].as_posix()}'\n")
            cmd=[ffmpeg,'-y','-hide_banner','-loglevel','error','-f','concat','-safe','0','-i',str(concat),'-vf',f'fps={self.fps},scale={self.width}:{self.height}:flags=lanczos,format=yuv420p','-c:v','libx264','-t',str(len(scenes)*float(scene_seconds)),'-movflags','+faststart',str(output)]
            proc=subprocess.run(cmd,capture_output=True,text=True,timeout=300)
            if proc.returncode: return {'status':'failed','error':proc.stderr[-3000:]}
        return {'status':'completed','output_path':str(output),'scene_count':len(scenes),'duration_seconds':len(scenes)*scene_seconds,'format':'mp4','renderer':'storyboard_fallback','limitations':['Stylized scene cards only; no generated footage, character animation, or synthesized audio in this fallback renderer.']}
