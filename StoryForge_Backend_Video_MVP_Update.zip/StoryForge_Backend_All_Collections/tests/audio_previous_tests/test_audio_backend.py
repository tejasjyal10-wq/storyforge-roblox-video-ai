import json, tempfile, unittest
from pathlib import Path
from storyforge_audio import AudioScene, DialogueLine, AudioLayer, AudioDirector, VoiceProfile, VoiceRegistry, SoundCatalog, CatalogResolver

class AudioBackendTests(unittest.TestCase):
    def test_director_adds_environment_and_mood_layers(self):
        s=AudioScene("s1", 20, mood="suspense", environment="forest", dialogue=[DialogueLine("hero","What was that?",emotion="urgent")])
        layers=AudioDirector().plan(s)
        self.assertEqual({x.kind for x in layers},{"ambience","music"})
        self.assertEqual(s.dialogue[0].rate,1.12)
    def test_voice_registry_persists_stable_profile(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"voices.json"; reg=VoiceRegistry(str(p))
            profile=VoiceProfile("hero","voice-01",str(Path(d)/"model.onnx"))
            reg.set(profile); loaded=VoiceRegistry(str(p))
            self.assertEqual(loaded.get("hero").voice_id,"voice-01")
    def test_catalog_tag_match_only_existing_assets(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/"rain.wav").write_bytes(b"fake test asset")
            (root/"catalog.json").write_text(json.dumps([{"kind":"ambience","file":"rain.wav","tags":["rain","storm"]},{"kind":"sfx","file":"missing.wav","tags":["thunder"]}]))
            catalog=SoundCatalog(d)
            self.assertEqual(len(catalog.search("ambience",["rain"])),1)
            resolved=CatalogResolver(catalog).resolve([AudioLayer("ambience","",tags=["rain"]),AudioLayer("sfx","",tags=["thunder"])])
            self.assertEqual(len(resolved),1)
    def test_pipeline_offsets_audio_across_scenes(self):
        from storyforge_audio.pipeline import AudioPipeline
        from storyforge_audio.models import AudioJob
        class FakeVoices:
            def get(self, cid): return VoiceProfile(cid, "stable", "dummy")
        class FakeTTS:
            def synthesize(self, text, profile, out, rate=1.0):
                Path(out).write_bytes(b"fake audio")
                return out
        class FakeCatalog:
            def resolve(self, layers): return layers
        class FakeMixer:
            def mix(self, layers, output, duration=None, peak=0.95):
                self.layers=layers; self.duration=duration; return output
        mixer=FakeMixer()
        with tempfile.TemporaryDirectory() as d:
            job=AudioJob(scenes=[AudioScene("a",5,dialogue=[DialogueLine("hero","one",start=1)]), AudioScene("b",7,dialogue=[DialogueLine("hero","two",start=2)])], output_file=str(Path(d)/"mix.m4a"))
            pipeline=AudioPipeline(FakeVoices(),FakeTTS(),FakeCatalog(),mixer=mixer)
            pipeline.render(job)
            voice_layers=[x for x in mixer.layers if x.kind=="voice"]
            self.assertEqual([x.start for x in voice_layers],[1,7])
            self.assertEqual(mixer.duration,12)

    def test_empty_tts_text_rejected_by_provider_contract(self):
        # Validate pipeline-level input guard without invoking external TTS.
        from storyforge_audio.tts import PiperTTS
        profile=VoiceProfile("hero","v","unused")
        with self.assertRaises(ValueError): PiperTTS().synthesize("   ",profile,"out.wav")

if __name__ == "__main__": unittest.main()
