import json, tempfile, unittest
from pathlib import Path
from storyforge_backend.core.storage import JSONStore
from storyforge_backend.core.validation import validate_project
from storyforge_backend.core.orchestrator import BackendOrchestrator
from storyforge_backend.collection1.continuity import check
from storyforge_backend.collection1.dialogue import validate_dialogue
from storyforge_backend.collection2.pipeline import ProductionPipeline
from storyforge_backend.collection2.assets import AssetRegistry
from storyforge_backend.collection3.characters import CharacterLibrary
from storyforge_backend.collection3.story_structure import outline_from_scenes, beat_sheet
from storyforge_backend.collection4.transitions import transition_plan
from storyforge_backend.collection4.media_manifest import build_manifest
from storyforge_backend.collection5.roblox import RobloxExporter
from storyforge_backend.audio.director import AudioDirector

class BackendSmokeTests(unittest.TestCase):
    def test_storage_roundtrip_and_safe_key(self):
        with tempfile.TemporaryDirectory() as d:
            store=JSONStore(d); store.write('../unsafe', {'a':1})
            self.assertEqual(store.read('../unsafe'), {'a':1})
            self.assertTrue(Path(d).exists())
    def test_validation_detects_missing_and_duplicate_scene_ids(self):
        p={'project_id':'p','scenes':[{'id':'x','title':'t','location':'l','purpose':'p'}, {'id':'x','title':'t','location':'l','purpose':'p'}]}
        self.assertTrue(any('unique' in e for e in validate_project(p)))
    def test_continuity_flags_duplicate_ids_and_empty_beats(self):
        issues=check({'scenes':[{'id':'a','purpose':'','beats':['',None]},{'id':'a','purpose':'p','beats':[]}]})
        kinds={i['type'] for i in issues}; self.assertIn('duplicate_scene_id',kinds); self.assertIn('scene_without_purpose',kinds); self.assertIn('empty_beat',kinds)
    def test_dialogue_validation(self):
        self.assertEqual(len(validate_dialogue([{'speaker_id':'bad','text':''}], {'good'})),2)
    def test_pipeline_partial_if_handlers_missing(self):
        result=ProductionPipeline().run({'seed':1}, stages=['missing'])
        self.assertEqual(result['status'],'partial')
        self.assertEqual(result['results'][0]['status'],'skipped')
    def test_pipeline_runs_handler_and_merges_output(self):
        pipe=ProductionPipeline({'add':lambda p:{'added':p['seed']+1}})
        result=pipe.run({'seed':3},stages=['add'])
        self.assertEqual(result['status'],'completed'); self.assertEqual(result['plan']['added'],4)
    def test_pipeline_retries_then_fails(self):
        calls=[]
        def broken(p): calls.append(1); raise RuntimeError('bad')
        result=ProductionPipeline({'bad':broken},max_attempts=2).run({},stages=['bad'])
        self.assertEqual(result['status'],'failed'); self.assertEqual(len(calls),2)
    def test_character_library_duplicate_names(self):
        lib=CharacterLibrary(); lib.add({'name':'A'}); lib.add({'name':' a '})
        self.assertEqual(len(lib.check_duplicate_names()),1)
    def test_story_outline_and_beat_sheet(self):
        scenes=[{'id':'s1','beats':['intro']},{'id':'s2','beats':['turn']} ]
        self.assertEqual(len(outline_from_scenes(scenes)['acts']),3); self.assertEqual(beat_sheet(scenes[0])[0]['beat'],'intro')
    def test_transition_fallback(self):
        result=transition_plan({'location':'x'},{'location':'y'},style='nonsense')
        self.assertEqual(result['type'],'cut'); self.assertFalse(result['same_location'])
    def test_manifest_reports_missing(self):
        result=build_manifest(['/definitely/not/here'])
        self.assertEqual(result['missing'],['/definitely/not/here'])
    def test_audio_director_basic(self):
        result=AudioDirector().plan_scene({'id':'s','emotion':'suspense','beats':['turns']})
        self.assertTrue(result['duck_music_on_dialogue']); self.assertEqual(result['mood'],'suspense')
    def test_roblox_export_writes_bootstrap(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'main.lua'
            result=RobloxExporter().export({'title':'Test','scenes':[{'id':'s','title':'Forest','location':'woods','characters':[],'beats':['walk'],'obstacles':[1]}]},str(out))
            self.assertEqual(result['scene_count'],1); self.assertTrue(out.exists()); self.assertIn('Forest',out.read_text())
    def test_orchestrator_plan_smoke(self):
        with tempfile.TemporaryDirectory() as d:
            from storyforge_backend.core.config import BackendConfig
            engine=BackendOrchestrator(BackendConfig(data_dir=d))
            plan=engine.create_plan({'project_id':'p','title':'T','synopsis':'Hero finds courage','cast':[{'id':'c','name':'Hero'}], 'scenes':[{'title':'S','location':'Forest','purpose':'Introduce','beats':['walk'],'emotion':'suspense'}]})
            self.assertIn('audio_plan',plan); self.assertIn('quality',plan); self.assertEqual(len(plan['scenes']),1)

class APIIntegrationTests(unittest.TestCase):
    def test_api_health_and_plan_routes(self):
        try:
            from fastapi.testclient import TestClient
            from storyforge_backend.api.app import create_app
        except ImportError:
            self.skipTest('FastAPI not installed')
        with tempfile.TemporaryDirectory() as d:
            from storyforge_backend.core.config import BackendConfig
            engine=BackendOrchestrator(BackendConfig(data_dir=d, roblox_output_dir=str(Path(d)/'exports')))
            client=TestClient(create_app(engine))
            self.assertEqual(client.get('/health').status_code,200)
            resp=client.post('/plan',json={'title':'API','scenes':[{'title':'Scene','purpose':'Purpose','beats':['beat']}]})
            self.assertEqual(resp.status_code,200,resp.text)
            self.assertIn('audio_plan',resp.json())

    def test_api_rejects_roblox_path_escape(self):
        try:
            from fastapi.testclient import TestClient
            from storyforge_backend.api.app import create_app
        except ImportError:
            self.skipTest('FastAPI not installed')
        with tempfile.TemporaryDirectory() as d:
            from storyforge_backend.core.config import BackendConfig
            engine=BackendOrchestrator(BackendConfig(data_dir=d, roblox_output_dir=str(Path(d)/'exports')))
            client=TestClient(create_app(engine))
            resp=client.post('/export/roblox',json={'plan':{'scenes':[]},'output_path':'../escape.lua'})
            self.assertEqual(resp.status_code,400)

class RobloxDelimiterTests(unittest.TestCase):
    def test_export_handles_lua_long_string_delimiter_in_user_text(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'story.lua'
            RobloxExporter().export({'scenes':[{'id':'s','title':'dangerous ]] text','location':'x'}]},str(out))
            text=out.read_text()
            self.assertIn('[=[',text)
            self.assertIn(']=]',text)


class APIExportTests(unittest.TestCase):
    def test_api_export_inside_configured_root_succeeds(self):
        try:
            from fastapi.testclient import TestClient
            from storyforge_backend.api.app import create_app
        except ImportError:
            self.skipTest('FastAPI not installed')
        with tempfile.TemporaryDirectory() as d:
            from storyforge_backend.core.config import BackendConfig
            export_root=Path(d)/'exports'
            engine=BackendOrchestrator(BackendConfig(data_dir=d, roblox_output_dir=str(export_root)))
            client=TestClient(create_app(engine))
            resp=client.post('/export/roblox',json={'plan':{'title':'Test','scenes':[]},'output_path':'scene.lua'})
            self.assertEqual(resp.status_code,200,resp.text)
            self.assertTrue((export_root/'scene.lua').exists())

class FFmpegIntegrationTests(unittest.TestCase):
    def test_real_ffmpeg_mixes_delayed_layers_and_probes_duration(self):
        import shutil, wave, struct, math, subprocess
        from storyforge_backend.audio.legacy_audio_engine.mixer import FFmpegMixer
        from storyforge_backend.audio.legacy_audio_engine.models import AudioLayer
        if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
            self.skipTest('FFmpeg/FFprobe not installed')
        with tempfile.TemporaryDirectory() as d:
            sources=[]
            for j, freq in enumerate((440,660)):
                wav=Path(d)/f'source{j}.wav'
                with wave.open(str(wav),'wb') as f:
                    f.setnchannels(1); f.setsampwidth(2); f.setframerate(22050)
                    samples=[int(9000*math.sin(2*math.pi*freq*i/22050)) for i in range(22050)]
                    f.writeframes(b''.join(struct.pack('<h',x) for x in samples))
                sources.append(wav)
            out=Path(d)/'mixed.m4a'
            FFmpegMixer().mix([AudioLayer('music',str(sources[0]),volume=.3),AudioLayer('sfx',str(sources[1]),start=1,volume=.3)],str(out),duration=2)
            probe=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(out)],capture_output=True,text=True,check=True)
            self.assertTrue(out.exists() and out.stat().st_size>0)
            self.assertAlmostEqual(float(__import__('json').loads(probe.stdout)['format']['duration']),2.0,delta=.08)

class AudioPipelineIntegrationTests(unittest.TestCase):
    def test_audio_pipeline_mixes_supplied_scene_layer_end_to_end(self):
        import shutil, wave, struct, math, subprocess, json
        from storyforge_backend.audio.legacy_audio_engine.models import AudioLayer, AudioScene, AudioJob
        from storyforge_backend.audio.legacy_audio_engine.voices import VoiceRegistry
        from storyforge_backend.audio.legacy_audio_engine.assets import SoundCatalog, CatalogResolver
        from storyforge_backend.audio.legacy_audio_engine.pipeline import AudioPipeline
        from storyforge_backend.audio.legacy_audio_engine.mixer import FFmpegMixer
        if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
            self.skipTest('FFmpeg/FFprobe not installed')
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'ambience.wav'
            with wave.open(str(source),'wb') as f:
                f.setnchannels(1); f.setsampwidth(2); f.setframerate(22050)
                samples=[int(4000*math.sin(2*math.pi*220*i/22050)) for i in range(22050)]
                f.writeframes(b''.join(struct.pack('<h',x) for x in samples))
            voices=VoiceRegistry(str(Path(d)/'voices.json'))
            class NoTTS:
                def synthesize(self,*args,**kwargs): raise AssertionError('TTS not needed for this scene test')
            catalog=CatalogResolver(SoundCatalog(d))
            pipeline=AudioPipeline(voices,NoTTS(),catalog,mixer=FFmpegMixer())
            job=AudioJob(scenes=[AudioScene(scene_id='scene1',duration=1.0,environment='forest',layers=[AudioLayer('ambience',str(source),duration=1.0)])],output_file=str(Path(d)/'scene.m4a'))
            result=pipeline.render(job)
            probe=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',result],capture_output=True,text=True,check=True)
            self.assertTrue(Path(result).exists())
            self.assertAlmostEqual(float(json.loads(probe.stdout)['format']['duration']),1.0,delta=.08)

class AIProviderIntegrationContractTests(unittest.TestCase):
    def test_story_director_uses_configured_provider(self):
        from storyforge_backend.collection1.director import StoryDirector
        class FakeProvider:
            configured=True
            def generate_json(self, system, user):
                return {'premise':'model premise','themes':['friendship'],'conflict':'test'}
        result=StoryDirector(provider=FakeProvider()).analyze({'synopsis':'local premise','scenes':[]})
        self.assertEqual(result['analysis_mode'],'model')
        self.assertEqual(result['premise'],'model premise')
    def test_story_director_falls_back_when_provider_fails(self):
        from storyforge_backend.collection1.director import StoryDirector
        class BrokenProvider:
            configured=True
            def generate_json(self,*args): raise RuntimeError('provider offline')
        result=StoryDirector(provider=BrokenProvider()).analyze({'synopsis':'Hero finds courage','scenes':[]})
        self.assertEqual(result['analysis_mode'],'heuristic_fallback')
        self.assertIn('provider_error',result)

class Collection1FoundationTests(unittest.TestCase):
    def test_foundation_analyzer_and_scene_planner(self):
        from storyforge_backend.collection1.previous_foundation_upgrade import analyze_story, plan_scene
        analysis=analyze_story('A friendship story. They must solve a mystery.',genre='adventure')
        self.assertTrue(analysis.premise)
        plan=plan_scene('s1','Mystery','Forest',['c1'],'Reveal a clue',['find clue'],'suspense')
        self.assertIn('camera_suggestions',plan)
        self.assertIn('audio_suggestions',plan)
    def test_foundation_memory_persists(self):
        from storyforge_backend.collection1.previous_foundation_upgrade import MemoryStore
        with tempfile.TemporaryDirectory() as d:
            store=MemoryStore(d); memory=store.load('project-A')
            store.add_fact(memory,'Clue is blue'); store.record_decision(memory,'camera','close-up','clue reveal')
            store.save(memory); loaded=store.load('project-A')
            self.assertIn('Clue is blue',loaded.canon_facts)
            self.assertEqual(len(loaded.decisions),1)
    def test_foundation_provider_requires_config(self):
        from storyforge_backend.collection1.previous_foundation_upgrade import OpenAICompatibleProvider, ModelNotConfigured
        provider=OpenAICompatibleProvider(base_url='',model='',api_key='')
        self.assertFalse(provider.configured)
        with self.assertRaises(ModelNotConfigured): provider.generate_json('system','user')
    def test_foundation_scene_validator(self):
        from storyforge_backend.collection1.previous_foundation_upgrade import validate_scene
        self.assertEqual(validate_scene({'id':'s','title':'t','location':'l','purpose':'p','beats':[],'characters':[]}),[])
