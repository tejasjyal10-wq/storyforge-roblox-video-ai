import shutil
import subprocess
import unittest
from pathlib import Path
from storyforge_backend.video.renderer import VideoRenderer

@unittest.skipUnless(shutil.which('ffmpeg'), 'ffmpeg required')
class VideoRendererTests(unittest.TestCase):
    def test_renders_playable_mp4_with_expected_duration(self):
        plan={'title':'Renderer Test','scenes':[{'title':'Opening','location':'Forest','purpose':'A traveler enters.'},{'title':'Reveal','location':'Ruins','purpose':'A symbol glows.'}]}
        with tempfile_directory() as tmp:
            output=Path(tmp)/'test.mp4'
            result=VideoRenderer(width=320,height=180,fps=12).render(plan,output,scene_seconds=1)
            self.assertEqual(result['status'],'completed')
            self.assertTrue(output.exists())
            probe=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(output)],capture_output=True,text=True,check=True)
            self.assertAlmostEqual(float(probe.stdout.strip()),2.0,delta=0.2)

from contextlib import contextmanager
import tempfile
@contextmanager
def tempfile_directory():
    with tempfile.TemporaryDirectory() as d: yield d
