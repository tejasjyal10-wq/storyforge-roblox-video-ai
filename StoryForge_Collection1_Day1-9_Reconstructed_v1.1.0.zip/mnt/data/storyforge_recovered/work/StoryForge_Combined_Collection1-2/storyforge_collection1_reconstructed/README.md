# StoryForge Collection 1 — Reconstructed

This is a reconstruction of the available Collection 1 story foundation, not the historical Days 1–9 archive. The original source ZIPs were unavailable in this workspace. Included functionality: stable character records, scene definitions, branch choices with validated destinations, export/import, and scene interaction triggers. The detailed original Days 1–5 implementations cannot be confirmed.

Requires Node.js 18+; run `npm test`.

## Core runtime expansion
- `CharacterLibrary`: stable IDs, character model/outfit/appearance/voice/personality metadata, update/remove/list, schema export/import.
- `SceneRuntime`: deterministic scene navigation, data-driven conditions, branch selection, visited history and snapshots.
- Conditions use `{ path, equals }`, `{ path, notEquals }`, `{ path, exists }`, or `{ path, includes }`; no `eval` or arbitrary callbacks.

## Runtime expansion (v1.1.0)
Character library and deterministic scene runtime are exported from `index.js`. See `src/character-library.js` and `src/scene-runtime.js`. Condition data is safe (no executable condition strings); supported checks are equals, notEquals, exists, and includes.
