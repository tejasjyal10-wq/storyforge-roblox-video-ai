/** Persistent character library with stable IDs and explicit versioning. */
export class CharacterLibrary {
  constructor({ characters = [], version = 1 } = {}) {
    this.version = version;
    this.characters = new Map();
    for (const character of characters) this.add(character);
  }
  add(character) {
    if (!character || typeof character !== 'object') throw new Error('Character record required');
    const { id, name } = character;
    if (typeof id !== 'string' || !id.trim() || typeof name !== 'string' || !name.trim()) throw new Error('Character id and name required');
    if (this.characters.has(id)) throw new Error(`Character ID already exists: ${id}`);
    const record = { id, name, appearance: structuredClone(character.appearance ?? {}), voice: character.voice ?? null,
      personality: Array.isArray(character.personality) ? [...character.personality] : [], role: character.role ?? 'supporting',
      model: character.model ?? null, outfit: structuredClone(character.outfit ?? {}), metadata: structuredClone(character.metadata ?? {}) };
    this.characters.set(id, record); return structuredClone(record);
  }
  update(id, patch = {}) {
    const existing = this.characters.get(id); if (!existing) throw new Error(`Unknown character: ${id}`);
    if (patch.id !== undefined && patch.id !== id) throw new Error('Character ID is immutable');
    const next = { ...existing, ...structuredClone(patch), id };
    if (typeof next.name !== 'string' || !next.name.trim()) throw new Error('Character name required');
    if (!Array.isArray(next.personality)) throw new Error('Personality must be an array');
    this.characters.set(id, next); return structuredClone(next);
  }
  remove(id) { return this.characters.delete(id); }
  get(id) { const c = this.characters.get(id); return c ? structuredClone(c) : null; }
  list() { return [...this.characters.values()].map(c => structuredClone(c)); }
  export() { return { schema: 'storyforge.character-library', version: this.version, characters: this.list() }; }
  static import(data) {
    if (!data || data.schema !== 'storyforge.character-library' || !Array.isArray(data.characters)) throw new Error('Invalid character-library export');
    return new CharacterLibrary({ characters: data.characters, version: data.version ?? 1 });
  }
}
