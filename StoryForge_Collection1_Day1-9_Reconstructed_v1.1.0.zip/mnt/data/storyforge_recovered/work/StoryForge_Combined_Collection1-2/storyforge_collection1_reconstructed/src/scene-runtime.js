/** Deterministic story runtime. Conditions are data, never arbitrary code. */
const readPath = (obj, path) => String(path).split('.').reduce((v, key) => v == null ? undefined : v[key], obj);
function conditionMatches(condition, state) {
  if (!condition) return true;
  if (typeof condition !== 'object' || Array.isArray(condition)) throw new Error('Condition must be an object');
  if ('equals' in condition && readPath(state, condition.path) !== condition.equals) return false;
  if ('notEquals' in condition && readPath(state, condition.path) === condition.notEquals) return false;
  if ('exists' in condition && ((readPath(state, condition.path) !== undefined) !== Boolean(condition.exists))) return false;
  if ('includes' in condition) { const v = readPath(state, condition.path); if (!Array.isArray(v) || !v.includes(condition.includes)) return false; }
  return true;
}
export class SceneRuntime {
  constructor(project, { state = {}, startSceneId = null } = {}) {
    this.project = project; this.state = structuredClone(state); this.currentSceneId = null; this.visited = [];
    this.startSceneId = startSceneId ?? project.scenes.keys().next().value ?? null;
  }
  start() { if (!this.startSceneId || !this.project.scenes.has(this.startSceneId)) throw new Error('Start scene missing'); return this.enter(this.startSceneId); }
  enter(sceneId) { const scene = this.project.getScene(sceneId); if (!scene) throw new Error(`Unknown scene: ${sceneId}`); this.currentSceneId = sceneId; this.visited.push(sceneId); return scene; }
  current() { return this.currentSceneId ? this.project.getScene(this.currentSceneId) : null; }
  availableBranches() { if (!this.currentSceneId) throw new Error('Runtime has not started'); return this.project.getBranches(this.currentSceneId).filter(b => conditionMatches(b.condition, this.state)); }
  choose(branchId) {
    if (!this.currentSceneId) throw new Error('Runtime has not started');
    const matches = this.availableBranches().filter(b => b.id === branchId);
    if (matches.length !== 1) throw new Error(`Branch unavailable: ${branchId}`);
    return this.enter(matches[0].nextSceneId);
  }
  snapshot() { return { currentSceneId: this.currentSceneId, startSceneId: this.startSceneId, state: structuredClone(this.state), visited: [...this.visited] }; }
  restore(snapshot) { if (!snapshot || (snapshot.currentSceneId && !this.project.scenes.has(snapshot.currentSceneId))) throw new Error('Invalid runtime snapshot'); this.currentSceneId = snapshot.currentSceneId ?? null; this.startSceneId = snapshot.startSceneId ?? this.startSceneId; this.state = structuredClone(snapshot.state ?? {}); this.visited = [...(snapshot.visited ?? [])]; return this.snapshot(); }
}
