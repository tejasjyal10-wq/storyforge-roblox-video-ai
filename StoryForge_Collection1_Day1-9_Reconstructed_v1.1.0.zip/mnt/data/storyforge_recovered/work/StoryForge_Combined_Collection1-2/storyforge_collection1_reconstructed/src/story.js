/** Reconstructed Collection 1 bridge. Original historical sources were unavailable. */
export class StoryProject {
  constructor({ id, title, premise = '', genre = 'adventure', cast = [], scenes = [] } = {}) {
    if (!id || !title) throw new Error('Story project id and title required');
    this.id = id; this.title = title; this.premise = premise; this.genre = genre;
    this.cast = new Map(); this.scenes = new Map(); this.branches = new Map(); this.events = [];
    for (const character of cast) this.addCharacter(character);
    for (const scene of scenes) this.addScene(scene);
  }
  addCharacter({ id, name, appearance = {}, voice = null, personality = [], role = 'supporting' }) {
    if (!id || !name) throw new Error('Character id and name required');
    if (this.cast.has(id)) throw new Error(`Character already exists: ${id}`);
    const record = { id, name, appearance: structuredClone(appearance), voice, personality: [...personality], role };
    this.cast.set(id, record); this.events.push({ type: 'character-added', id }); return structuredClone(record);
  }
  addScene({ id, title, description = '', characters = [], choices = [] }) {
    if (!id || !title || this.scenes.has(id)) throw new Error('Scene id/title required and id must be unique');
    const unknown = characters.filter(c => !this.cast.has(c));
    if (unknown.length) throw new Error(`Unknown characters: ${unknown.join(', ')}`);
    const scene = { id, title, description, characters: [...characters], choices: structuredClone(choices) };
    this.scenes.set(id, scene); this.events.push({ type: 'scene-added', id }); return structuredClone(scene);
  }
  addBranch(sceneId, { id, label, nextSceneId, condition = null }) {
    if (!this.scenes.has(sceneId) || !id || !label || !this.scenes.has(nextSceneId)) throw new Error('Branch must reference existing scene IDs and have id/label');
    const branches = this.branches.get(sceneId) ?? [];
    if (branches.some(b => b.id === id)) throw new Error(`Branch already exists: ${id}`);
    const branch = { id, label, nextSceneId, condition }; branches.push(branch); this.branches.set(sceneId, branches);
    this.events.push({ type: 'branch-added', sceneId, id }); return structuredClone(branch);
  }
  getScene(id) { const scene = this.scenes.get(id); return scene ? structuredClone(scene) : null; }
  getCharacter(id) { const c = this.cast.get(id); return c ? structuredClone(c) : null; }
  getBranches(sceneId) { return structuredClone(this.branches.get(sceneId) ?? []); }
  validate() {
    const issues = [];
    for (const [sceneId, branches] of this.branches) for (const b of branches) if (!this.scenes.has(b.nextSceneId)) issues.push(`Branch ${sceneId}/${b.id} has missing destination`);
    if (!this.scenes.size) issues.push('Story has no scenes');
    return { ok: issues.length === 0, issues, scenes: this.scenes.size, characters: this.cast.size, branches: [...this.branches.values()].reduce((n, b) => n + b.length, 0) };
  }
  export() { return { id: this.id, title: this.title, premise: this.premise, genre: this.genre, cast: [...this.cast.values()].map(x => structuredClone(x)), scenes: [...this.scenes.values()].map(x => structuredClone(x)), branches: [...this.branches.entries()].map(([k,v]) => [k, structuredClone(v)]), events: structuredClone(this.events) }; }
  static import(data) { const project = new StoryProject({ id: data.id, title: data.title, premise: data.premise, genre: data.genre }); for (const c of data.cast ?? []) project.addCharacter(c); for (const s of data.scenes ?? []) project.addScene(s); for (const [sceneId, branches] of data.branches ?? []) for (const b of branches) project.addBranch(sceneId, b); return project; }
}

export class SceneInteractionSystem {
  constructor() { this.triggers = new Map(); this.history = []; }
  register({ id, sceneId, event, action, payload = {} }) {
    if (!id || !sceneId || !event || !action || this.triggers.has(id)) throw new Error('Interaction requires unique id, scene, event and action');
    const trigger = { id, sceneId, event, action, payload: structuredClone(payload), enabled: true };
    this.triggers.set(id, trigger); return structuredClone(trigger);
  }
  fire({ sceneId, event, context = {} }) {
    const matches = [...this.triggers.values()].filter(t => t.enabled && t.sceneId === sceneId && t.event === event);
    const results = matches.map(t => { const record = { triggerId: t.id, action: t.action, payload: structuredClone(t.payload), context: structuredClone(context), firedAt: new Date().toISOString() }; this.history.push(record); return structuredClone(record); });
    return results;
  }
  disable(id) { const t = this.triggers.get(id); if (!t) return false; t.enabled = false; return true; }
  snapshot() { return { triggers: [...this.triggers.values()].map(x => structuredClone(x)), history: structuredClone(this.history) }; }
}
