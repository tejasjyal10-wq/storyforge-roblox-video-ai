import test from 'node:test'; import assert from 'node:assert/strict';
import { CharacterLibrary, SceneRuntime, StoryProject } from '../index.js';
test('CharacterLibrary keeps stable IDs, deep copies records, and round-trips', () => {
 const lib = new CharacterLibrary(); const c = lib.add({id:'hero',name:'Hero',appearance:{hair:'dark'},personality:['brave'],voice:'v1',model:'m1'});
 c.appearance.hair='changed'; assert.equal(lib.get('hero').appearance.hair,'dark');
 assert.equal(lib.update('hero',{voice:'v2'}).voice,'v2'); assert.throws(()=>lib.update('hero',{id:'other'}),/immutable/);
 const restored = CharacterLibrary.import(lib.export()); assert.equal(restored.get('hero').voice,'v2'); assert.equal(restored.remove('hero'),true); assert.equal(restored.get('hero'),null);
});
test('SceneRuntime condition filtering, choice, history, and restore', () => {
 const p = new StoryProject({id:'p',title:'T',scenes:[{id:'a',title:'A'},{id:'b',title:'B'},{id:'c',title:'C'}]});
 p.addBranch('a',{id:'locked',label:'Locked',nextSceneId:'b',condition:{path:'key',equals:true}});
 p.addBranch('a',{id:'open',label:'Open',nextSceneId:'c'});
 const r = new SceneRuntime(p,{state:{key:false}}); assert.equal(r.start().id,'a'); assert.deepEqual(r.availableBranches().map(x=>x.id),['open']);
 assert.equal(r.choose('open').id,'c'); const snap=r.snapshot(); const r2=new SceneRuntime(p); r2.restore(snap); assert.deepEqual(r2.snapshot(),snap);
 assert.throws(()=>r.choose('locked'),/unavailable/);
});
test('SceneRuntime rejects malformed condition data', () => {
 const p = new StoryProject({id:'p',title:'T',scenes:[{id:'a',title:'A'},{id:'b',title:'B'}]});
 p.addBranch('a',{id:'bad',label:'Bad',nextSceneId:'b',condition:'not data'}); const r=new SceneRuntime(p); r.start(); assert.throws(()=>r.availableBranches(),/object/);
});
