# StoryForge Combined Collections — Reconstructed Package

This package combines the available Collection 2 code with a newly reconstructed Collection 1 story/scene foundation and bridge.

## Important source-history note
The original historical Collection 1 (Days 1–9) and Collection 2 day-specific ZIP source archives were not present in the workspace during this reconstruction. Therefore this is **not a byte-for-byte merge of those historical ZIPs**. Collection 1 capabilities here are reconstructed from the project history and specifically known features (scene branching, scene interactions/events, character and animation systems); the detailed original Days 1–5 contents cannot be confirmed. Collection 2 retains the available reconstructed code from the previous v2.0.0 archive.

## Collections
- Collection 1 (Days 1–9): reconstructed story project, cast library, branching, scene-interaction trigger foundation.
- Collection 2 (Days 10–19): production orchestration/pipeline, asset registry and compatibility, Blender job preparation, scene assembly, animation/behavior, world/cinematic planning, Roblox scene planning, recovery.
- Day 10 is shared foundation. It is represented by the Orchestrator module; it is not duplicated in the runtime.

## Run tests
Requires Node.js 18+; no external npm dependencies.
```sh
npm test
npm run demo
```

## Runtime limitations
Blender, Roblox Studio, external AI generation, voice providers, rendering, and video export are represented by adapters/plans or stubs where no external runtime is available. The automated tests validate in-package behavior, not execution inside those applications.
