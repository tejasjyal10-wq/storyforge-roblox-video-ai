import { createStoryForge, AssetRegistry, CompatibilityEngine, SceneBuilder, RobloxSceneAdapter, Pipeline } from './index.js';
const registry = new AssetRegistry();
const env = registry.register({ name: 'Forest Clearing', type: 'environment', status: 'registered', metadata: { platforms: ['blender','roblox'] } });
const model = registry.register({ name: 'Hero Model', type: 'model', status: 'registered', metadata: { rig: 'humanoid', platforms: ['blender','roblox'] } });
const character = registry.register({ name: 'Hero', type: 'character', status: 'registered', dependencies: [model.id], metadata: { model: model.id, platforms: ['blender','roblox'] } });
const compatibility = new CompatibilityEngine(registry);
const sceneBuilder = new SceneBuilder(registry, compatibility);
sceneBuilder.create({ id: 'scene-01', name: 'Forest Arrival', environmentId: env.id, characters: [character.id] });
const roblox = new RobloxSceneAdapter(sceneBuilder, compatibility);
const pipeline = new Pipeline();
const result = await pipeline.execute({ sceneId: 'scene-01' }, {
  'asset-check': v => ({ ...v, checked: compatibility.validateAsset(character.id).ok }),
  'scene-build': v => ({ ...v, scene: sceneBuilder.get(v.sceneId) }),
  'export': v => ({ ...v, robloxPlan: roblox.prepare(v.sceneId) })
});
console.log(JSON.stringify({ project: createStoryForge(), pipeline: result.status, roblox: result.value.robloxPlan.ok }, null, 2));
