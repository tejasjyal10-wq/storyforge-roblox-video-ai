const TYPE_DEPENDENCIES = { character: ['model'], animation: ['rig'], scene: ['environment'], environment: [], robloxScene: ['environment'] };
export class CompatibilityEngine {
  constructor(registry) { this.registry = registry; }
  validateAsset(assetOrId) {
    const asset = typeof assetOrId === 'string' ? this.registry.get(assetOrId) : assetOrId;
    if (!asset) return { ok: false, issues: ['Asset not found'] };
    const issues = [];
    if (asset.status === 'archived') issues.push('Asset is archived');
    for (const depId of asset.dependencies ?? []) { const dep = this.registry.get(depId); if (!dep) issues.push(`Missing dependency: ${depId}`); else if (dep.status === 'archived') issues.push(`Archived dependency: ${depId}`); }
    for (const type of TYPE_DEPENDENCIES[asset.type] ?? []) if (!(asset.metadata?.[type] || (asset.dependencies ?? []).some(id => this.registry.get(id)?.type === type))) issues.push(`Missing required ${type}`);
    return { ok: issues.length === 0, assetId: asset.id, issues };
  }
  validatePlatform(assetOrId, platform) {
    const asset = typeof assetOrId === 'string' ? this.registry.get(assetOrId) : assetOrId;
    if (!asset) return { ok: false, issues: ['Asset not found'] };
    const support = asset.metadata?.platforms ?? [];
    const issues = support.length && !support.includes(platform) ? [`Unsupported platform: ${platform}`] : [];
    return { ok: !issues.length, platform, issues };
  }
  validateAll() { return this.registry.list().map(a => this.validateAsset(a)); }
}
