import { createHash } from 'node:crypto';
const ALLOWED = new Set(['character','model','outfit','voice','animation','environment','building','prop','sound','music','material','texture','camera','lighting','scene']);
export class AssetRegistry {
  constructor() { this.assets = new Map(); this.versions = new Map(); }
  register(asset) {
    if (!asset?.name || !asset?.type || !ALLOWED.has(asset.type)) throw new Error('Asset requires a valid name and type');
    const id = asset.id ?? `${asset.type}_${createHash('sha1').update(`${asset.type}:${asset.name}`).digest('hex').slice(0,12)}`;
    if (this.assets.has(id)) throw new Error(`Asset already registered: ${id}`);
    const record = { id, name: asset.name, type: asset.type, metadata: structuredClone(asset.metadata ?? {}), tags: [...(asset.tags ?? [])], dependencies: [...(asset.dependencies ?? [])], status: asset.status ?? 'draft', createdAt: new Date().toISOString(), version: 1 };
    this.assets.set(id, record); this.versions.set(id, [structuredClone(record)]); return structuredClone(record);
  }
  get(id) { const a = this.assets.get(id); return a ? structuredClone(a) : null; }
  list({ type, status, tag } = {}) { return [...this.assets.values()].filter(a => (!type || a.type === type) && (!status || a.status === status) && (!tag || a.tags.includes(tag))).map(a => structuredClone(a)); }
  update(id, patch) { const a = this.assets.get(id); if (!a) throw new Error(`Unknown asset: ${id}`); const next = {...a, ...patch, id, version: a.version + 1, updatedAt: new Date().toISOString()}; this.assets.set(id, next); this.versions.get(id).push(structuredClone(next)); return structuredClone(next); }
  history(id) { return structuredClone(this.versions.get(id) ?? []); }
  archive(id) { return this.update(id, { status: 'archived' }); }
  restore(id) { return this.update(id, { status: 'registered' }); }
  remove(id) { if (!this.assets.has(id)) return false; this.assets.delete(id); this.versions.delete(id); return true; }
  exportJSON() { return JSON.stringify({ assets: [...this.assets.values()], versions: [...this.versions.entries()] }, null, 2); }
  importJSON(json) { const data = typeof json === 'string' ? JSON.parse(json) : json; for (const a of data.assets ?? []) this.assets.set(a.id, structuredClone(a)); for (const [id, v] of data.versions ?? []) this.versions.set(id, structuredClone(v)); return this.assets.size; }
}
