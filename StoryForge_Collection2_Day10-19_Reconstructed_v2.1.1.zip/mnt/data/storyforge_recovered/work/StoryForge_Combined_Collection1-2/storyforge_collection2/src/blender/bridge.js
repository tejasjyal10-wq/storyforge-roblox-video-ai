export class BlenderBridge {
  constructor({ executable = 'blender', mode = 'external' } = {}) { this.executable = executable; this.mode = mode; }
  createJob({ blendFile, output, scene, action = 'render' }) {
    if (!blendFile || !output) throw new Error('blendFile and output are required');
    return { executable: this.executable, mode: this.mode, args: ['--background', blendFile, '--python-expr', `# StoryForge job: ${action}; scene=${scene ?? 'default'}; output=${output}`], job: { action, blendFile, output, scene: scene ?? 'default' }, status: 'prepared', note: 'Prepared command only; Blender execution requires Blender installed and an execution adapter.' };
  }
  status() { return { available: false, mode: this.mode, message: 'No Blender runtime is connected in this package. Jobs can be prepared for an external runner.' }; }
}
