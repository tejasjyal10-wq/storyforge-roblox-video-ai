export class AnimationCatalog {
  constructor() { this.entries = new Map(); }
  add({ id, name, rig, duration = 1, category = 'action', keyframes = [] }) { if (!id || !name || !rig) throw new Error('Animation id, name and rig required'); if (this.entries.has(id)) throw new Error(`Animation exists: ${id}`); const a = { id, name, rig, duration, category, keyframes: structuredClone(keyframes) }; this.entries.set(id, a); return structuredClone(a); }
  get(id) { const a = this.entries.get(id); return a ? structuredClone(a) : null; }
  compatible(animationId, model) { const a = this.get(animationId); return !!a && !!model && (model.metadata?.rig === a.rig || model.metadata?.supportedRigs?.includes(a.rig)); }
  list(category) { return [...this.entries.values()].filter(a => !category || a.category === category).map(a => structuredClone(a)); }
}
export class CharacterBehavior {
  constructor(characterId) { if (!characterId) throw new Error('Character id required'); this.characterId = characterId; this.state = 'idle'; this.queue = []; this.history = []; }
  enqueue(action, payload = {}) { if (!action) throw new Error('Action name required'); this.queue.push({ action, payload: structuredClone(payload) }); return this.queue.length; }
  next() { const item = this.queue.shift(); if (!item) return null; this.state = item.action; this.history.push({ ...item, state: this.state }); return structuredClone(item); }
  setState(state) { this.state = state; this.history.push({ action: 'state-change', state }); }
  snapshot() { return { characterId: this.characterId, state: this.state, queue: structuredClone(this.queue), history: structuredClone(this.history) }; }
}
