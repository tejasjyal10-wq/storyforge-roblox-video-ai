export class Orchestrator {
  constructor({ maxRetries = 2 } = {}) { this.maxRetries = maxRetries; this.tasks = new Map(); this.events = []; }
  addTask(task) {
    if (!task?.id || this.tasks.has(task.id)) throw new Error(`Task id missing or duplicate: ${task?.id}`);
    this.tasks.set(task.id, { id: task.id, dependencies: [...(task.dependencies ?? [])], run: task.run ?? (() => true), status: 'pending', attempts: 0, result: null, error: null });
    this._event('task-added', task.id); return this;
  }
  _event(type, taskId, detail = {}) { this.events.push({ at: new Date().toISOString(), type, taskId, ...detail }); }
  _validateGraph() {
    for (const t of this.tasks.values()) for (const d of t.dependencies) if (!this.tasks.has(d)) throw new Error(`Unknown dependency ${d} for ${t.id}`);
    const visiting = new Set(), visited = new Set();
    const visit = id => { if (visiting.has(id)) throw new Error(`Dependency cycle at ${id}`); if (visited.has(id)) return; visiting.add(id); for (const d of this.tasks.get(id).dependencies) visit(d); visiting.delete(id); visited.add(id); };
    for (const id of this.tasks.keys()) visit(id);
  }
  async run() {
    this._validateGraph();
    while ([...this.tasks.values()].some(t => t.status === 'pending')) {
      const ready = [...this.tasks.values()].filter(t => t.status === 'pending' && t.dependencies.every(d => this.tasks.get(d).status === 'completed'));
      const blocked = [...this.tasks.values()].filter(t => t.status === 'pending' && t.dependencies.some(d => ['failed','blocked'].includes(this.tasks.get(d).status)));
      for (const t of blocked) { t.status = 'blocked'; this._event('task-blocked', t.id); }
      if (!ready.length) { if (blocked.length) continue; throw new Error('No runnable tasks; unresolved dependencies'); }
      await Promise.all(ready.map(async t => {
        t.status = 'running'; this._event('task-started', t.id);
        while (t.attempts <= this.maxRetries) {
          t.attempts++;
          try { t.result = await t.run(); t.status = 'completed'; this._event('task-completed', t.id); break; }
          catch (err) { t.error = String(err?.message ?? err); this._event('task-retry', t.id, { attempt: t.attempts, error: t.error }); if (t.attempts > this.maxRetries) { t.status = 'failed'; this._event('task-failed', t.id, { error: t.error }); } }
        }
      }));
    }
    return this.report();
  }
  report() { const tasks = [...this.tasks.values()].map(({run, ...t}) => ({...t})); return { total: tasks.length, completed: tasks.filter(t => t.status === 'completed').length, failed: tasks.filter(t => t.status === 'failed').length, blocked: tasks.filter(t => t.status === 'blocked').length, tasks, events: [...this.events] }; }
  snapshot() { return JSON.parse(JSON.stringify(this.report())); }
  restore(snapshot) { for (const saved of snapshot.tasks ?? []) { const t = this.tasks.get(saved.id); if (t) { t.status = saved.status; t.attempts = saved.attempts; t.result = saved.result; t.error = saved.error; } } this.events = [...(snapshot.events ?? [])]; }
}
