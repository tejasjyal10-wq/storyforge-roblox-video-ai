export const DEFAULT_STAGES = ['story','script','scene-plan','asset-check','scene-build','animation','audio','render','export'];
export class Pipeline {
  constructor({ stages = DEFAULT_STAGES, validators = {} } = {}) { this.stages = stages.map(name => ({ name, status: 'pending', artifact: null, error: null })); this.validators = validators; this.paused = false; this.history = []; }
  async execute(input, handlers = {}) {
    let value = input;
    for (const stage of this.stages) {
      if (this.paused) return { status: 'paused', current: stage.name, value };
      const fn = handlers[stage.name] ?? (v => v);
      try { value = await fn(value); const validator = this.validators[stage.name]; if (validator && !(await validator(value))) throw new Error(`Validation failed: ${stage.name}`); stage.status = 'completed'; stage.artifact = value; this.history.push({ stage: stage.name, status: 'completed' }); }
      catch (e) { stage.status = 'failed'; stage.error = String(e.message ?? e); this.history.push({ stage: stage.name, status: 'failed', error: stage.error }); return { status: 'failed', stage: stage.name, error: stage.error, value }; }
    }
    return { status: 'completed', value, stages: this.stages.map(s => ({...s})) };
  }
  pause() { this.paused = true; }
  resume() { this.paused = false; }
  reset() { for (const s of this.stages) { s.status = 'pending'; s.artifact = null; s.error = null; } this.history = []; this.paused = false; }
  report() { return { completed: this.stages.filter(s => s.status === 'completed').length, total: this.stages.length, stages: this.stages.map(s => ({...s})), history: [...this.history] }; }
}
