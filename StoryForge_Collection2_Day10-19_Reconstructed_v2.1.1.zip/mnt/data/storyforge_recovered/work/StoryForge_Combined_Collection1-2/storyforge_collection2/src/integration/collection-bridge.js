import { Pipeline } from '../core/pipeline.js';
import { StoryProject, SceneInteractionSystem } from '../collection1/story.js';
import { createStoryForge } from './recovery.js';

/** Shared bridge from reconstructed Collection 1 story systems into Collection 2 production. */
export class StoryForgeCombined {
  constructor({ project, pipeline = new Pipeline(), interactions = new SceneInteractionSystem() } = {}) {
    if (!(project instanceof StoryProject)) throw new Error('Combined project requires a StoryProject');
    this.project = project; this.pipeline = pipeline; this.interactions = interactions; this.core = createStoryForge();
  }
  validate() { return { collection1: this.project.validate(), collection2: this.pipeline.report(), ok: this.project.validate().ok }; }
  async produce({ handlers = {}, initial = {} } = {}) {
    const storyValidation = this.project.validate();
    if (!storyValidation.ok) return { status: 'failed', stage: 'story-validation', issues: storyValidation.issues };
    const integratedHandlers = { ...handlers,
      story: handlers.story ?? (v => ({ ...v, story: this.project.export() })),
      script: handlers.script ?? (v => ({ ...v, script: { scenes: [...this.project.scenes.values()].map(s => ({ ...s, branches: this.project.getBranches(s.id) })) } })),
      'scene-plan': handlers['scene-plan'] ?? (v => ({ ...v, scenePlan: [...this.project.scenes.values()].map(s => ({ id: s.id, characters: s.characters, branches: this.project.getBranches(s.id) })) }))
    };
    return this.pipeline.execute(initial, integratedHandlers);
  }
  snapshot() { return { project: this.project.export(), pipeline: this.pipeline.report(), interactions: this.interactions.snapshot() }; }
}
