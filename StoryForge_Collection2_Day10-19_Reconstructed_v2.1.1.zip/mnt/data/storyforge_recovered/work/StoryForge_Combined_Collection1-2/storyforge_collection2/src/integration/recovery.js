export class RecoveryStore {
  constructor() { this.snapshots = new Map(); }
  save(key, value) { if (!key) throw new Error('Snapshot key required'); this.snapshots.set(key, { savedAt: new Date().toISOString(), data: structuredClone(value) }); return key; }
  load(key) { const s = this.snapshots.get(key); return s ? structuredClone(s) : null; }
  delete(key) { return this.snapshots.delete(key); }
  exportJSON() { return JSON.stringify([...this.snapshots.entries()], null, 2); }
  importJSON(json) { for (const [k, v] of JSON.parse(json)) this.snapshots.set(k, v); return this.snapshots.size; }
}
export function createStoryForge() {
  return { createdAt: new Date().toISOString(), version: '2.0.0', modules: ['orchestrator','pipeline','asset-registry','compatibility','blender-bridge','scene-builder','animation','world-cinematic','roblox-adapter','recovery'] };
}
