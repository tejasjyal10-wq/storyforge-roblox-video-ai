export class RobloxSceneAdapter {
  constructor(sceneBuilder, compatibility) { this.sceneBuilder = sceneBuilder; this.compatibility = compatibility; }
  prepare(sceneId) {
    const scene = this.sceneBuilder.get(sceneId); if (!scene) return { ok: false, issues: ['Scene not found'] };
    const issues = [...this.sceneBuilder.validate(sceneId).issues];
    for (const id of [scene.environmentId, ...scene.characters, ...scene.props].filter(Boolean)) { const r = this.compatibility.validatePlatform(id, 'roblox'); issues.push(...r.issues.map(x => `${id}: ${x}`)); }
    return { ok: issues.length === 0, platform: 'roblox', sceneId, issues, exportPlan: { workspace: scene.environmentId, characterModels: scene.characters, props: scene.props, recommendedObjects: ['SpawnLocation', 'Camera', 'Lighting', 'CollectionService tags'], obstacleSupport: true, checkpointSupport: true, interactionTriggerSupport: true }, note: 'Export plan only; Roblox Studio execution/export requires a separate Studio adapter.' };
  }
}
