export class SceneBuilder {
  constructor(registry, compatibility) { this.registry = registry; this.compatibility = compatibility; this.scenes = new Map(); }
  create({ id, name, environmentId, characters = [], props = [], camera = {}, lighting = {} }) {
    if (!id || !name) throw new Error('Scene id and name required'); if (this.scenes.has(id)) throw new Error(`Scene exists: ${id}`);
    const assetIds = [environmentId, ...characters, ...props].filter(Boolean);
    const missing = assetIds.filter(a => !this.registry.get(a)); if (missing.length) throw new Error(`Missing assets: ${missing.join(', ')}`);
    const scene = { id, name, environmentId, characters: [...characters], props: [...props], camera: structuredClone(camera), lighting: structuredClone(lighting), createdAt: new Date().toISOString() };
    this.scenes.set(id, scene); return structuredClone(scene);
  }
  validate(id) { const s = this.scenes.get(id); if (!s) return { ok: false, issues: ['Scene not found'] }; const issues = []; for (const aid of [s.environmentId, ...s.characters, ...s.props].filter(Boolean)) { const a = this.registry.get(aid); if (!a) issues.push(`Missing asset ${aid}`); else if (a.status === 'archived') issues.push(`Archived asset ${aid}`); } return { ok: !issues.length, issues }; }
  get(id) { const s = this.scenes.get(id); return s ? structuredClone(s) : null; }
}
