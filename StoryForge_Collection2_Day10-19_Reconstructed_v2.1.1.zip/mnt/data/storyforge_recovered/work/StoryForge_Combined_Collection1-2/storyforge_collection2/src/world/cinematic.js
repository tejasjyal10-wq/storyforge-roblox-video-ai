export class WorldCatalog {
  constructor() { this.worlds = new Map(); }
  add({ id, name, locations = [], atmosphere = {}, rules = {} }) { if (!id || !name || this.worlds.has(id)) throw new Error('World requires unique id and name'); const w = { id, name, locations: structuredClone(locations), atmosphere: structuredClone(atmosphere), rules: structuredClone(rules) }; this.worlds.set(id, w); return structuredClone(w); }
  get(id) { const w = this.worlds.get(id); return w ? structuredClone(w) : null; }
}
export class CinematicTimeline {
  constructor() { this.events = []; }
  add({ at, type, payload = {} }) { if (!Number.isFinite(at) || at < 0 || !type) throw new Error('Cinematic event requires nonnegative time and type'); const e = { at, type, payload: structuredClone(payload) }; this.events.push(e); this.events.sort((a,b) => a.at-b.at); return structuredClone(e); }
  validate() { const issues = []; for (const e of this.events) if (e.type === 'camera' && !e.payload?.shot) issues.push(`Camera event at ${e.at} missing shot`); return { ok: !issues.length, issues, duration: this.events.at(-1)?.at ?? 0, count: this.events.length }; }
  export() { return structuredClone(this.events); }
}
