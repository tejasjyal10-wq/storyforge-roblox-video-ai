import test from 'node:test'; import assert from 'node:assert/strict';
import { CharacterLibrary, SceneRuntime, StoryProject } from '../index.js';
test('Collection 1 expanded character library and scene runtime are exported through Collection 2', () => {
 const library = new CharacterLibrary(); library.add({id:'c1',name:'Hero',appearance:{style:'stylized'},voice:'voice-a',personality:['curious']});
 assert.equal(library.get('c1').name,'Hero'); assert.equal(CharacterLibrary.import(library.export()).get('c1').voice,'voice-a');
 const story = new StoryProject({id:'integration',title:'Integration',scenes:[{id:'start',title:'Start'},{id:'end',title:'End'}]});
 story.addBranch('start',{id:'continue',label:'Continue',nextSceneId:'end',condition:{path:'ready',equals:true}});
 const runtime = new SceneRuntime(story,{state:{ready:true}}); assert.equal(runtime.start().id,'start'); assert.equal(runtime.choose('continue').id,'end');
});
