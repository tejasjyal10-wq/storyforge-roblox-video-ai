import test from 'node:test';
import assert from 'node:assert/strict';
import { StoryProject, SceneInteractionSystem, StoryForgeCombined, Pipeline, AssetRegistry, CompatibilityEngine, SceneBuilder, RobloxSceneAdapter } from '../index.js';

test('Collection 1 story branching validates and exports/imports', () => {
  const p = new StoryProject({ id:'p', title:'Test Story', cast:[{id:'c1',name:'Hero'}], scenes:[{id:'s1',title:'Start',characters:['c1']},{id:'s2',title:'End'}] });
  p.addBranch('s1',{id:'choice',label:'Go forward',nextSceneId:'s2'});
  assert.equal(p.validate().ok,true); assert.equal(StoryProject.import(p.export()).validate().ok,true);
});
test('Collection 1 interaction event triggers matching action', () => {
  const i = new SceneInteractionSystem(); i.register({id:'door',sceneId:'s1',event:'touch',action:'open-door'});
  assert.equal(i.fire({sceneId:'s1',event:'touch'}).length,1); assert.equal(i.fire({sceneId:'s2',event:'touch'}).length,0);
});
test('Collection 1 story data passes into Collection 2 pipeline', async () => {
  const p = new StoryProject({id:'p',title:'Pipeline story',scenes:[{id:'s1',title:'Opening'}]});
  const c = new StoryForgeCombined({project:p,pipeline:new Pipeline({stages:['story','script','scene-plan','asset-check','scene-build','animation','audio','render','export']})});
  const r = await c.produce({initial:{projectId:'p'}}); assert.equal(r.status,'completed'); assert.equal(r.value.story.scenes.length,1); assert.equal(r.value.scenePlan.length,1);
});
test('Combined pipeline rejects invalid story before production', async () => {
  const p = new StoryProject({id:'p',title:'Empty'}); const c = new StoryForgeCombined({project:p});
  assert.equal((await c.produce()).stage,'story-validation');
});
test('Collection 2 asset scene compatibility feeds Roblox planning', () => {
  const r = new AssetRegistry(); const env=r.register({id:'env',name:'Forest',type:'environment',metadata:{platforms:['roblox']},status:'registered'});
  const char=r.register({id:'char',name:'Hero',type:'character',metadata:{platforms:['roblox']},status:'registered'});
  const compat=new CompatibilityEngine(r); const scene=new SceneBuilder(r,compat); scene.create({id:'scene',name:'Forest scene',environmentId:env.id,characters:[char.id]});
  const plan=new RobloxSceneAdapter(scene,compat).prepare('scene'); assert.equal(plan.ok,true); assert.equal(plan.exportPlan.obstacleSupport,true);
});
