# StoryForge Collection 3 — Days 20–29

Cumulative package. Collection 3 builds provider-independent planning systems for story analysis, scene structure, character behavior, world continuity, cinematic shot plans, action/motion sequences, style/mood consistency, dialogue performance cues, and story-to-sequence integration.


## Days
- Day 20: Story Intelligence Engine — story diagnostics, beat outline, pacing. (Carryover foundation.)
- Day 21: Scene Intelligence — scene blueprints, completeness diagnostics, continuity/transition checks.
- Day 22: Character Behavior Intelligence — trait/value/fear/emotion-guided behavior suggestions.
- Day 23: World Intelligence — world/location validation and location graph.
- Day 24: Cinematic Director — shot plans, camera movement, timing, focus, transitions.
- Day 25: Action & Motion — validated action steps, targets, durations, animation needs.
- Day 26: Visual Style & Mood — shared style profile, mood lighting, scene overrides, comparison.
- Day 27: Dialogue & Performance — dialogue checks, emotion delivery cues, duration estimates.
- Day 28: Story-to-Sequence — integrated per-scene production plans.
- Day 29: Integration & Regression — full test suite and package validation.

## Run
Requires Node.js 18+; no dependencies.
```sh
npm test
npm run demo
```

## Honest scope
The implementation is deterministic and rule-based. It does not itself call an LLM, create 3D models, generate audio, render videos, or run Blender/Roblox Studio. The output is structured planning data intended for production adapters/integrations. These desktop runtimes cannot be verified in the tablet-only environment.

## Provider & Execution Layer (upgrade v1.0.1)
- `ProviderRegistry`: register interchangeable providers and dispatch generation requests.
- `OpenAICompatibleProvider`: chat-completions adapter with JSON response mode; pass API keys at runtime (never commit keys).
- `ProductionExecutionEngine`: executes named tasks, validates outputs, retries failures, and reports attempts.

Example (Node 18+):
```js
import {ProviderRegistry, OpenAICompatibleProvider, ProductionExecutionEngine} from './src/index.js';
const providers = new ProviderRegistry().register('ai', new OpenAICompatibleProvider({
  model: process.env.STORYFORGE_MODEL,
  apiKey: process.env.STORYFORGE_API_KEY,
  baseUrl: process.env.STORYFORGE_BASE_URL || 'https://api.openai.com/v1'
}));
const engine = new ProductionExecutionEngine({registry:providers, defaultProvider:'ai', retries:2});
const output = await engine.execute('scene-plan', {prompt:'Draft a scene plan for a fantasy adventure.', json:true});
console.log(output.result.parsed ?? output.result.content);
```
This adapter is provider-compatible, but this package has not made live network/API calls in tests. Use a trusted provider, review its privacy/usage terms, and keep credentials out of source files and ZIPs.

## Asset Production Layer (upgrade v1.0.2)
- `AssetCatalog`: stable IDs, type filtering, CRUD, and JSON save/load.
- `AssetProductionPipeline`: provider-backed asset requests, prompt metadata, validation, retries, and catalog registration.
- Asset provider contract: implement `generateAsset(providerName, request)` and return `{name, uri, metadata?}`. The pipeline deliberately does not fabricate generated assets; connect a real image/model/audio provider to this contract.
