const allowed=new Set(['walk','run','jump','turn','look','talk','idle','interact','climb','sit','stand','gesture','custom']);
export class ActionMotionIntelligence {
  sequence(actions=[]) {
    const steps=actions.map((a,i)=>{const type=a.type||'custom';return {step:i+1,type,description:a.description||type,actor:a.actor||null,target:a.target||null,durationSeconds:Math.max(0.1,Number(a.durationSeconds)||1),animation:a.animation||type,valid:allowed.has(type),requiresTarget:['interact','climb'].includes(type)&&!a.target};});
    return {valid:steps.every(s=>s.valid&&!s.requiresTarget),steps,errors:steps.flatMap(s=>[!s.valid?`Unsupported action type: ${s.type}`:null,s.requiresTarget?`Action ${s.step} requires a target.`:null].filter(Boolean)),totalDurationSeconds:steps.reduce((sum,s)=>sum+s.durationSeconds,0),requiresAnimationAssets:[...new Set(steps.map(s=>s.animation))]};
  }
  coordinate(characterActions={},sceneActions=[]) {const combined=[...(sceneActions||[]),...(characterActions.actions||[])];return this.sequence(combined);}
}
