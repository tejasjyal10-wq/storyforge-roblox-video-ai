import {randomUUID} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';

const ASSET_TYPES = new Set(['character','environment','prop','texture','audio','animation','video','image','model']);
function validateAsset(asset) {
  if (!asset || typeof asset !== 'object') throw new TypeError('Asset must be an object');
  if (!ASSET_TYPES.has(asset.type)) throw new TypeError(`Unsupported asset type: ${asset.type}`);
  if (typeof asset.name !== 'string' || !asset.name.trim()) throw new TypeError('Asset name is required');
  if (typeof asset.uri !== 'string' || !asset.uri.trim()) throw new TypeError('Asset URI is required');
  if (/^(https?:\/\/|file:\/\/)/i.test(asset.uri)) return asset;
  if (asset.uri.startsWith('/') || asset.uri.startsWith('./') || asset.uri.startsWith('../')) return asset;
  throw new TypeError('Asset URI must be a web URL or explicit local path');
}

/** Persistent, ID-stable catalog for produced or imported assets. */
export class AssetCatalog {
  #assets = new Map();
  register(asset) {
    validateAsset(asset);
    const record = {id: asset.id ?? randomUUID(), type:asset.type, name:asset.name.trim(), uri:asset.uri, metadata:asset.metadata ?? {}, createdAt:asset.createdAt ?? new Date().toISOString()};
    if (this.#assets.has(record.id)) throw new Error(`Asset ID already exists: ${record.id}`);
    this.#assets.set(record.id, record);
    return structuredClone(record);
  }
  get(id) { const value=this.#assets.get(id); return value ? structuredClone(value) : null; }
  list({type}={}) { return [...this.#assets.values()].filter(a=>!type||a.type===type).map(a=>structuredClone(a)); }
  remove(id) { return this.#assets.delete(id); }
  async save(path) { await writeFile(path, JSON.stringify({schemaVersion:1,assets:this.list()},null,2), 'utf8'); }
  async load(path) {
    const parsed=JSON.parse(await readFile(path,'utf8'));
    if (parsed?.schemaVersion!==1 || !Array.isArray(parsed.assets)) throw new Error('Invalid asset catalog file');
    const staged=new Map();
    for (const item of parsed.assets) { validateAsset(item); if (!item.id || staged.has(item.id) ) throw new Error('Asset catalog contains missing or duplicate IDs'); staged.set(item.id,structuredClone(item)); }
    this.#assets=staged; return this.list();
  }
}


/** Provider-backed asset pipeline with retry, validation, and catalog persistence. */
export class AssetProductionPipeline {
  constructor({providers, catalog=new AssetCatalog(), defaultProvider, retries=1}={}) {
    if (!providers || typeof providers.generateAsset!=='function') throw new TypeError('Asset provider must implement generateAsset()');
    this.providers=providers; this.catalog=catalog; this.defaultProvider=defaultProvider; this.retries=Math.max(0,Math.floor(retries));
  }
  async generate({type,name,prompt,metadata={}}, {provider=this.defaultProvider,retries=this.retries}={}) {
    if (!provider) throw new Error('No asset provider selected');
    if (!ASSET_TYPES.has(type)) throw new TypeError(`Unsupported asset type: ${type}`);
    if (!prompt || typeof prompt!=='string' || !prompt.trim()) throw new TypeError('Asset prompt is required');
    let last;
    for (let attempt=0;attempt<=retries;attempt++) {
      try {
        const produced=await this.providers.generateAsset(provider,{type,name,prompt,metadata});
        const record=this.catalog.register({...produced,type,name:name ?? produced?.name,metadata:{...metadata,...(produced?.metadata ?? {}),prompt,provider}});
        return {asset:record,provider,attempts:attempt+1};
      } catch (err) { last=err; }
    }
    throw new Error(`Asset generation failed after ${retries+1} attempt(s): ${last?.message ?? 'unknown error'}`,{cause:last});
  }
}
