export class CharacterBehaviorIntelligence {
  evaluate(character={}, situation={}) {
    const traits = Array.isArray(character.traits) ? character.traits : [];
    const values = Array.isArray(character.values) ? character.values : [];
    const fears = Array.isArray(character.fears) ? character.fears : [];
    const emotion = situation.emotion || character.currentEmotion || 'neutral';
    const goal = situation.goal || character.goal || 'respond to the situation';
    const constraints = [];
    if (!character.id) constraints.push('Character should have a stable library ID.');
    if (!character.personality && !traits.length) constraints.push('Personality or traits are missing; behavior may be generic.');
    if (!situation.conflict) constraints.push('Situation has no explicit conflict; reaction may be low-intensity.');
    const behavior = this.recommend({traits,values,fears,emotion,goal,conflict:situation.conflict||'', relationship:situation.relationship||''});
    return {characterId:character.id||null, emotion, goal, behavior, constraints, continuity: {knownTraits:traits, knownValues:values, currentEmotion:emotion}};
  }
  recommend({traits=[],values=[],fears=[],emotion='neutral',goal='',conflict='',relationship=''}) {
    const text=[...traits,...values].join(' ').toLowerCase();
    let reaction='pause, assess the situation, and choose an action consistent with the character’s goal';
    if(/brave|bold|confident/.test(text)) reaction='face the problem directly, while acknowledging the stakes';
    else if(/cautious|careful|anxious/.test(text)) reaction='seek information, identify risks, and proceed carefully';
    else if(/curious|inventive|creative/.test(text)) reaction='investigate an unusual detail and try a creative solution';
    else if(/kind|compassion|helpful/.test(text)) reaction='check on affected people and offer practical help';
    if(fears.length && emotion==='fearful') reaction='protect what matters, then look for a safe way to regain control';
    return {reaction, emotionalDirection:emotion, motivation:goal||'character goal', conflict:conflict||null, relationshipContext:relationship||null, consistencyNote:'Use this as guidance, not a forced action; preserve established character choices.'};
  }
}
