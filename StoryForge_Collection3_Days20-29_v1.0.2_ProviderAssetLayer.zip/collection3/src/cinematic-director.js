const shotMap={establishing:'wide',dialogue:'medium',reaction:'close_up',reveal:'wide_then_close',action:'tracking',emotion:'close_up',default:'medium'};
export class CinematicDirector {
  plan(scene={},options={}) {
    const beats=Array.isArray(scene.beats)?scene.beats:(Array.isArray(scene.actions)?scene.actions:[]);
    const shots=beats.map((beat,i)=>{const kind=beat.type||beat.kind||'default';return {shotId:`${scene.id||'scene'}-shot-${i+1}`,beatIndex:i,beat:beat.text||beat.description||kind,shot:shotMap[kind]||shotMap.default,cameraMovement:kind==='action'?'follow':kind==='reveal'?'slow_push':'static_or_subtle',durationSeconds:Math.max(2,Number(beat.durationSeconds)||options.defaultShotDuration||5),focus:beat.focus||scene.characters?.[0]||'primary subject',transition:beat.transition||'cut'};});
    if(!shots.length) shots.push({shotId:`${scene.id||'scene'}-shot-1`,beatIndex:0,beat:scene.summary||'Establish scene',shot:'wide',cameraMovement:'slow_push',durationSeconds:Math.max(2,Number(options.defaultShotDuration)||5),focus:scene.location||'environment',transition:'cut'});
    return {sceneId:scene.id||null,shots,totalDurationSeconds:shots.reduce((s,x)=>s+x.durationSeconds,0),directingNotes:scene.mood?`Preserve ${scene.mood} mood.`:'Maintain visual clarity and scene intent.'};
  }
}
