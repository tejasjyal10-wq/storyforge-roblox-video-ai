const VALID_STAGES = new Set(['setup', 'inciting', 'rising', 'turning_point', 'climax', 'resolution']);
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));


/** Deterministic story diagnostics and planning; intentionally provider-independent. */
export class StoryIntelligenceEngine {
  analyze(project = {}) {
    const scenes = Array.isArray(project.scenes) ? project.scenes : [];
    const errors = [], warnings = [], suggestions = [];
    if (!project.title?.trim()) warnings.push({code:'STORY_TITLE_MISSING', message:'Add a story title.'});
    if (!scenes.length) errors.push({code:'NO_SCENES', message:'A story needs at least one scene.'});
    const ids = new Set();
    scenes.forEach((scene, index) => {
      if (!scene?.id) errors.push({code:'SCENE_ID_MISSING', sceneIndex:index, message:'Scene ID is required.'});
      else if (ids.has(scene.id)) errors.push({code:'SCENE_ID_DUPLICATE', sceneId:scene.id, message:'Scene IDs must be unique.'});
      else ids.add(scene.id);
      if (!scene?.summary?.trim() && !scene?.description?.trim()) warnings.push({code:'SCENE_DESCRIPTION_MISSING', sceneIndex:index, message:'Add a scene summary or description.'});
      if (scene?.stage && !VALID_STAGES.has(scene.stage)) warnings.push({code:'UNKNOWN_STORY_STAGE', sceneId:scene.id, stage:scene.stage});
      if (index > 0 && scene?.stage === 'setup') suggestions.push({code:'LATE_SETUP', sceneId:scene.id, message:'A setup scene appears after the story has begun; confirm this is intentional.'});
    });
    const stages = scenes.map(s => s.stage).filter(Boolean);
    if (!stages.includes('inciting')) suggestions.push({code:'INCITING_EVENT_RECOMMENDED', message:'Consider an inciting event that starts the main conflict.'});
    if (!stages.includes('climax')) suggestions.push({code:'CLIMAX_RECOMMENDED', message:'Consider a decisive climax.'});
    if (!stages.includes('resolution')) suggestions.push({code:'RESOLUTION_RECOMMENDED', message:'Consider a resolution or intentional ending.'});
    const pacing = this.scorePacing(scenes);
    return {ok: errors.length === 0, errors, warnings, suggestions, pacing, sceneCount:scenes.length, stagesPresent:[...new Set(stages)]};
  }
  scorePacing(scenes = []) {
    const n = scenes.length;
    if (!n) return {score:0, label:'empty', notes:['Add scenes to assess pacing.']};
    const notes=[];
    const durations=scenes.map(s=>Number(s?.durationSeconds)).filter(x=>Number.isFinite(x)&&x>0);
    if (durations.length && durations.length !== n) notes.push('Some scenes have no positive duration estimate.');
    const average=durations.length ? durations.reduce((a,b)=>a+b,0)/durations.length : null;
    const stages=scenes.map(s=>s?.stage).filter(Boolean);
    const variety=new Set(stages).size;
    let score=clamp(Math.round((Math.min(n,6)/6)*50 + (variety/6)*50),0,100);
    if(n<3) notes.push('The outline is very short; consider adding room for development.');
    if(variety<3) notes.push('The outline has limited story-stage variety.');
    if(durations.length>2 && average && durations.some(d=>d>average*3)) notes.push('One scene is much longer than the average; review pacing.');
    const label=score>=80?'balanced outline':score>=50?'developing outline':'early outline';
    return {score,label,averageSceneDurationSeconds:average,notes};
  }
  buildBeatOutline(premise, options={}) {
    if(typeof premise !== 'string' || !premise.trim()) throw new TypeError('Premise must be a non-empty string.');
    const count=clamp(Number(options.sceneCount)||6,3,12);
    const beats=[
      ['setup','Establish the protagonist, ordinary world, and immediate goal.'],
      ['inciting','Introduce an event that disrupts the ordinary world.'],
      ['rising','Show attempts, obstacles, discoveries, and growing stakes.'],
      ['turning_point','Reveal information or force a consequential decision.'],
      ['climax','Bring the central conflict to its decisive moment.'],
      ['resolution','Show the outcome and what changed.']
    ];
    const selected=beats.slice(0,count);
    return {premise:premise.trim(),generatedBy:'rule-based-outline-v1',beats:selected.map(([stage,goal],i)=>({id:`beat-${i+1}`,stage,goal,prompt:`Using this premise: ${premise.trim()} — ${goal}`}))};
  }
}
