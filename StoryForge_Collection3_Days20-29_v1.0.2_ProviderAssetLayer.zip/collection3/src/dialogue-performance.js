export class DialoguePerformanceIntelligence {
  analyze(lines=[],context={}) {
    const normalized=lines.map((line,i)=>({lineId:line.id||`line-${i+1}`,speaker:line.speaker||null,text:line.text||'',emotion:line.emotion||context.mood||'neutral',delivery:line.delivery||this.delivery(line.emotion||context.mood||'neutral'),pauseAfterSeconds:Math.max(0,Number(line.pauseAfterSeconds)||0),estimatedDurationSeconds:this.estimate(line.text||line)}));
    return {valid:normalized.every(l=>l.speaker&&l.text.trim()),lines:normalized,errors:normalized.flatMap((l,i)=>[!l.speaker?`Line ${i+1}: missing speaker`:null,!l.text.trim()?`Line ${i+1}: empty dialogue`:null].filter(Boolean)),totalDurationSeconds:normalized.reduce((s,l)=>s+l.estimatedDurationSeconds+l.pauseAfterSeconds,0),performanceNotes:context.performanceNotes||[]};
  }
  estimate(text) {const words=String(text||'').trim().split(/\s+/).filter(Boolean).length;return Math.round((words/2.5)*100)/100;}
  delivery(emotion='') {const e=String(emotion).toLowerCase();if(/angry|furious/.test(e))return 'firm, controlled intensity';if(/sad|grief/.test(e))return 'gentle, slower delivery';if(/excited|happy/.test(e))return 'bright, energetic delivery';if(/fear|nervous/.test(e))return 'hesitant, alert delivery';if(/whisper/.test(e))return 'quiet, close delivery';return 'natural conversational delivery';}
}
