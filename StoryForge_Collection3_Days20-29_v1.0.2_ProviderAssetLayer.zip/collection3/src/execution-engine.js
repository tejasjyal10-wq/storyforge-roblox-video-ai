/** Executes named production tasks through registered providers with retries and validation. */
export class ProductionExecutionEngine {
  constructor({ registry, defaultProvider, retries = 1, validators = {} } = {}) {
    if (!registry || typeof registry.generate !== 'function') throw new TypeError('A provider registry is required');
    this.registry = registry;
    this.defaultProvider = defaultProvider;
    this.retries = Math.max(0, Math.floor(retries));
    this.validators = validators;
  }
  async execute(task, request, { provider = this.defaultProvider, retries = this.retries } = {}) {
    if (!task || typeof task !== 'string') throw new TypeError('task must be a string');
    if (!provider) throw new Error('No provider selected');
    const validate = this.validators[task];
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const result = await this.registry.generate(provider, { ...request, task });
        if (validate) {
          const verdict = await validate(result, request);
          if (verdict !== true) throw new Error(typeof verdict === 'string' ? verdict : `Output validation failed for task '${task}'`);
        }
        return { task, provider, attempts: attempt + 1, result };
      } catch (error) {
        lastError = error;
      }
    }
    throw new Error(`Task '${task}' failed after ${retries + 1} attempt(s): ${lastError?.message ?? 'unknown error'}`, { cause: lastError });
  }
}
