/** Provider registry for interchangeable AI/production adapters. */
export class ProviderRegistry {
  #providers = new Map();
  register(name, provider) {
    if (!name || typeof name !== 'string') throw new TypeError('Provider name must be a non-empty string');
    if (!provider || typeof provider.generate !== 'function') throw new TypeError(`Provider '${name}' must implement generate()`);
    this.#providers.set(name, provider);
    return this;
  }
  get(name) { return this.#providers.get(name); }
  has(name) { return this.#providers.has(name); }
  remove(name) { return this.#providers.delete(name); }
  list() { return [...this.#providers.keys()]; }
  async generate(name, request) {
    const provider = this.get(name);
    if (!provider) throw new Error(`Unknown provider: ${name}`);
    return provider.generate(request);
  }
}


/** OpenAI-compatible chat-completions adapter. Inject fetch for testing. */
export class OpenAICompatibleProvider {
  constructor({ baseUrl = 'https://api.openai.com/v1', model, apiKey, fetchImpl = globalThis.fetch } = {}) {
    if (!model) throw new TypeError('A model name is required');
    if (!apiKey) throw new TypeError('An API key is required');
    if (typeof fetchImpl !== 'function') throw new TypeError('A fetch implementation is required');
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.model = model;
    this.apiKey = apiKey;
    this.fetchImpl = fetchImpl;
  }
  async generate({ prompt, system = 'You are a helpful creative production assistant.', json = false, temperature = 0.7 } = {}) {
    if (typeof prompt !== 'string' || !prompt.trim()) throw new TypeError('prompt must be a non-empty string');
    const body = { model: this.model, messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }], temperature };
    if (json) body.response_format = { type: 'json_object' };
    const response = await this.fetchImpl(`${this.baseUrl}/chat/completions`, {
      method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${this.apiKey}` }, body: JSON.stringify(body)
    });
    if (!response.ok) {
      const safeMessage = `AI provider request failed (HTTP ${response.status})`;
      throw new Error(safeMessage);
    }
    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== 'string') throw new Error('AI provider returned no message content');
    let parsed;
    if (json) {
      try { parsed = JSON.parse(content); }
      catch { throw new Error('AI provider returned invalid JSON content'); }
    }
    return { provider: 'openai-compatible', model: data.model ?? this.model, content, ...(parsed === undefined ? {} : { parsed }), usage: data.usage ?? null };
  }
}
