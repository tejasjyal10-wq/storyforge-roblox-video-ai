const asText = v => typeof v === 'string' ? v.trim() : '';
export class SceneIntelligence {
  analyze(scene = {}, context = {}) {
    const missing = [];
    for (const key of ['id','summary']) if (!asText(scene[key])) missing.push(key);
    if (!asText(scene.location)) missing.push('location');
    if (!Array.isArray(scene.characters)) missing.push('characters');
    if (!asText(scene.goal)) missing.push('goal');
    const conflicts = [];
    if (context.previousScene && scene.location && context.previousScene.location && scene.location !== context.previousScene.location && !scene.transition) conflicts.push('Location changes without an explicit transition.');
    if (context.previousScene?.timeOfDay && scene.timeOfDay && context.previousScene.timeOfDay !== scene.timeOfDay && !scene.timeTransition) conflicts.push('Time changes without an explicit time transition.');
    const recommendations = [];
    if (!scene.stakes) recommendations.push('Clarify what can be lost or gained.');
    if (!scene.emotionalBeat) recommendations.push('Specify the emotional change for the scene.');
    if (!scene.exitCondition) recommendations.push('Define how the scene ends or advances.');
    return {sceneId:scene.id ?? null, valid:missing.length===0, missing, conflicts, recommendations, purpose:scene.purpose||'advance plot, reveal information, or develop character', estimatedComplexity:Math.min(5,1+(Array.isArray(scene.characters)?scene.characters.length:0)+(Array.isArray(scene.actions)?scene.actions.length:0))};
  }
  createBlueprint(input={}) {
    const {id='scene-new', summary='', location='unspecified', characters=[], goal='advance the story', mood='neutral', stage='rising'} = input;
    return {id,summary,location,characters:[...characters],goal,mood,stage,stakes:'defined by story context',emotionalBeat:'shift or reinforce character emotion',exitCondition:'transition to the next story beat',actions:[],dialogue:[],props:[],durationSeconds:30};
  }
}
