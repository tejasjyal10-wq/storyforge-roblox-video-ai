import {SceneIntelligence} from './scene-intelligence.js';
import {CharacterBehaviorIntelligence} from './character-behavior.js';
import {WorldIntelligence} from './world-intelligence.js';
import {CinematicDirector} from './cinematic-director.js';
import {ActionMotionIntelligence} from './action-motion.js';
import {VisualStyleMoodEngine} from './visual-style.js';
import {DialoguePerformanceIntelligence} from './dialogue-performance.js';
import {StoryIntelligenceEngine} from './day20-story-intelligence.js';
export class StorySequenceGenerator {
  constructor(){this.story=new StoryIntelligenceEngine();this.scene=new SceneIntelligence();this.character=new CharacterBehaviorIntelligence();this.world=new WorldIntelligence();this.director=new CinematicDirector();this.motion=new ActionMotionIntelligence();this.style=new VisualStyleMoodEngine();this.dialogue=new DialoguePerformanceIntelligence();}
  generate(project={}) {
    const storyReport=this.story.analyze(project);const scenes=project.scenes||[];const sequence=scenes.map((s,i)=>{const prev=scenes[i-1];const sceneReport=this.scene.analyze(s,{previousScene:prev});const worldReport=this.world.validate(project.world||{},s);const actions=this.motion.sequence(s.actions||[]);const directing=this.director.plan(s);const visual=this.style.resolve(project.visualStyle||{},s);const dialogue=this.dialogue.analyze(s.dialogue||[],{mood:s.mood});const characterReports=(s.characters||[]).map(c=>typeof c==='string'?this.character.evaluate({id:c,traits:[]},{goal:s.goal,conflict:s.conflict,emotion:s.mood}):this.character.evaluate(c,{goal:s.goal,conflict:s.conflict,emotion:s.mood}));return {sceneId:s.id||`scene-${i+1}`,order:i+1,sceneReport,worldReport,actionPlan:actions,directing,visual,dialogue,characterReports,transitionFromPrevious:s.transition||'cut'};});
    return {projectId:project.id||null,title:project.title||'Untitled Story',valid:storyReport.ok&&sequence.every(s=>s.sceneReport.valid&&s.worldReport.valid&&s.actionPlan.valid&&s.dialogue.valid),storyReport,sequence,totals:{sceneCount:sequence.length,shotCount:sequence.reduce((n,s)=>n+s.directing.shots.length,0),actionCount:sequence.reduce((n,s)=>n+s.actionPlan.steps.length,0),estimatedDurationSeconds:sequence.reduce((n,s)=>n+s.directing.totalDurationSeconds+s.dialogue.totalDurationSeconds+s.actionPlan.totalDurationSeconds,0)},generatedAt:null,providerIndependent:true,notes:['Deterministic planning modules: no external AI provider or renderer is invoked.','Resolve scene/world validation errors before sending this plan to production adapters.']};
  }
}
