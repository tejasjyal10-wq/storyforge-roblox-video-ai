export class VisualStyleMoodEngine {
  resolve(style={},scene={}) {
    const palette=scene.palette||style.palette||['primary','secondary','accent'];
    const mood=scene.mood||style.mood||'adventurous';
    const lighting=scene.lighting||style.lighting||this.lightingFor(mood);
    const atmosphere=scene.atmosphere||style.atmosphere||mood;
    return {styleId:style.id||null,styleName:style.name||'StoryForge default',mood,palette:[...palette],lighting,atmosphere,renderGuidance:{stylization:style.stylization||'medium',detail:style.detail||'cinematic',avoidPhotorealism:style.avoidPhotorealism??true,consistencyRule:'Apply the same style profile across all scenes unless an intentional style change is specified.'},sceneOverrides:scene.styleOverrides||{}};
  }
  lightingFor(mood='') {const m=mood.toLowerCase();if(/dark|fear|mystery|tense/.test(m))return 'low-key, directional lighting';if(/joy|warm|hope|celebrat/.test(m))return 'soft warm lighting';if(/action|urgent|adventure/.test(m))return 'dynamic cinematic lighting';return 'balanced cinematic lighting';}
  compare(a={},b={}) {const keys=['mood','palette','lighting','atmosphere'];return keys.filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k]));}
}
