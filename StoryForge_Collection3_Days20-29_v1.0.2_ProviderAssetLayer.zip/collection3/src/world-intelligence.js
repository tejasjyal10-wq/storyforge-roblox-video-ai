export class WorldIntelligence {
  validate(world={}, scene={}) {
    const errors=[], warnings=[];
    if(!world.id) warnings.push('World is missing a stable ID.');
    if(!world.rules || !Array.isArray(world.rules)) warnings.push('World rules are not defined as a list.');
    if(scene.location && Array.isArray(world.locations) && !world.locations.some(l=>typeof l==='string'?l===scene.location:l?.id===scene.location||l?.name===scene.location)) errors.push(`Scene location “${scene.location}” is not registered in the world.`);
    for(const rule of world.rules||[]) if(scene.worldFacts && scene.worldFacts.some(f=>f?.violatesRule===rule?.id)) errors.push(`Scene fact conflicts with world rule: ${rule?.id||'unnamed rule'}`);
    return {valid:errors.length===0,errors,warnings,worldId:world.id||null,location:scene.location||null,continuityNotes:scene.continuityNotes||[]};
  }
  locationGraph(world={}) { const locations=(world.locations||[]).map(l=>typeof l==='string'?{id:l,name:l,connections:[]}:{connections:[],...l}); return {nodes:locations.map(({id,name,description})=>({id:id||name,name:name||id,description:description||''})),edges:locations.flatMap(l=>(l.connections||[]).map(to=>({from:l.id||l.name,to}))).filter(e=>locations.some(l=>(l.id||l.name)===e.to))}; }
}
