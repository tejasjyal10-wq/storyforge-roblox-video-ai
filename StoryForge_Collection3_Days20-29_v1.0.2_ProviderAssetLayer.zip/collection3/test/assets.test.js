import test from 'node:test';
import assert from 'node:assert/strict';
import {AssetCatalog,AssetProductionPipeline} from '../src/index.js';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';

test('asset catalog registers, filters, retrieves and removes stable IDs',()=>{
 const c=new AssetCatalog(); const a=c.register({id:'hero-1',type:'character',name:'Hero',uri:'./assets/hero.glb'});
 assert.equal(c.get('hero-1').name,'Hero'); assert.equal(c.list({type:'character'}).length,1); assert.throws(()=>c.register({...a}),/already exists/); assert.equal(c.remove('hero-1'),true); assert.equal(c.get('hero-1'),null);
});

test('asset catalog saves and restores persistent records',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'sf-assets-')); const path=join(dir,'assets.json');
 try { const c=new AssetCatalog(); c.register({id:'a1',type:'image',name:'Forest',uri:'https://assets.example/forest.png',metadata:{style:'storybook'}}); await c.save(path); const restored=new AssetCatalog(); await restored.load(path); assert.deepEqual(restored.list(),c.list()); }
 finally {await rm(dir,{recursive:true,force:true});}
});

test('asset catalog rejects invalid types and URI forms',()=>{
 const c=new AssetCatalog(); assert.throws(()=>c.register({type:'unknown',name:'x',uri:'x'}),/Unsupported/); assert.throws(()=>c.register({type:'prop',name:'x',uri:'javascript:alert(1)'}),/URI/);
});

test('pipeline calls provider, registers asset, and returns attempt metadata',async()=>{
 const catalog=new AssetCatalog(); const providers={generateAsset:async request=>({name:request.name,uri:'./generated/forest.png',metadata:{width:1024}})};
 const pipeline=new AssetProductionPipeline({providers,catalog,defaultProvider:'mock'}); const out=await pipeline.generate({type:'environment',name:'Forest',prompt:'misty forest'});
 assert.equal(out.attempts,1); assert.equal(out.asset.metadata.width,1024); assert.equal(catalog.get(out.asset.id).name,'Forest');
});

test('asset pipeline retries provider failures and then succeeds',async()=>{
 let n=0; const providers={generateAsset:async()=>{if(++n===1)throw new Error('temporary');return {name:'Prop',uri:'./prop.png'}}};
 const pipeline=new AssetProductionPipeline({providers,defaultProvider:'test',retries:1}); const result=await pipeline.generate({type:'prop',name:'Prop',prompt:'wooden lantern'}); assert.equal(result.attempts,2);
});

test('asset pipeline reports exhausted retries',async()=>{
 const pipeline=new AssetProductionPipeline({providers:{generateAsset:async()=>{throw new Error('offline')}},defaultProvider:'test',retries:1});
 await assert.rejects(pipeline.generate({type:'model',name:'Model',prompt:'model'}),/failed after 2 attempt/);
});
