import test from 'node:test';
import assert from 'node:assert/strict';
import {ProviderRegistry, OpenAICompatibleProvider, ProductionExecutionEngine} from '../src/index.js';

test('provider registry registers, lists and dispatches', async () => {
  const registry = new ProviderRegistry().register('fake', {generate: async (r) => ({echo:r.prompt})});
  assert.deepEqual(registry.list(), ['fake']);
  assert.deepEqual(await registry.generate('fake', {prompt:'hello'}), {echo:'hello'});
  assert.equal(registry.remove('fake'), true);
});

test('OpenAI-compatible adapter sends request and parses JSON mode', async () => {
  let sent;
  const provider = new OpenAICompatibleProvider({model:'test-model', apiKey:'test-key', baseUrl:'https://example.test/v1', fetchImpl:async (url,opts) => {
    sent={url,opts}; return {ok:true,json:async()=>({model:'test-model',choices:[{message:{content:'{"ok":true}'}}],usage:{total_tokens:3}})};
  }});
  const result = await provider.generate({prompt:'make a scene plan',json:true});
  assert.equal(sent.url,'https://example.test/v1/chat/completions');
  assert.equal(JSON.parse(sent.opts.body).response_format.type,'json_object');
  assert.deepEqual(result.parsed,{ok:true});
  assert.equal(result.usage.total_tokens,3);
});

test('adapter reports HTTP errors without leaking key', async () => {
  const provider = new OpenAICompatibleProvider({model:'m',apiKey:'secret-key',fetchImpl:async()=>({ok:false,status:401})});
  await assert.rejects(provider.generate({prompt:'x'}), (err)=>!err.message.includes('secret-key') && err.message.includes('401'));
});

test('execution engine retries, validates, and reports attempt count', async () => {
  let calls=0;
  const registry = new ProviderRegistry().register('fake',{generate:async()=>{calls++;return {content:'done'}}});
  const engine = new ProductionExecutionEngine({registry,defaultProvider:'fake',retries:2,validators:{scene:()=>calls>=2}});
  const out = await engine.execute('scene',{prompt:'x'});
  assert.equal(out.attempts,2); assert.equal(calls,2);
});

test('execution engine fails clearly after retry limit', async () => {
  const registry = new ProviderRegistry().register('fake',{generate:async()=>({})});
  const engine = new ProductionExecutionEngine({registry,defaultProvider:'fake',retries:1,validators:{scene:()=>false}});
  await assert.rejects(engine.execute('scene',{}), /failed after 2 attempt/);
});
