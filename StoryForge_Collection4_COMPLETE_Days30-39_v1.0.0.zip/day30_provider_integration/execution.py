"""Provider task execution with retries and result validation."""
class TaskExecutor:
 def __init__(self,provider,retries=2):self.provider=provider;self.retries=max(0,int(retries))
 def run(self,prompt,validator=None):
  last=None
  for attempt in range(self.retries+1):
   try:
    result=self.provider.generate(prompt)
    if validator and not validator(result):raise ValueError('result validation failed')
    return {'status':'success','attempts':attempt+1,'result':result}
   except Exception as exc:last=exc
  return {'status':'failed','attempts':self.retries+1,'error_type':type(last).__name__}
