from dataclasses import dataclass
from typing import Any
@dataclass
class ProviderResult:
    provider:str
    data:Any
    raw:str=''
class Provider:
    def generate(self,prompt:str,**kwargs)->ProviderResult:raise NotImplementedError
