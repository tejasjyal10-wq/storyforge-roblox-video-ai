"""OpenAI-compatible chat completions adapter using stdlib urllib."""
import os,json,urllib.request,urllib.error
from .base import Provider,ProviderResult
class OpenAICompatibleProvider(Provider):
 def __init__(self,api_key=None,base_url=None,model=None,timeout=60):
  self.api_key=api_key or os.getenv('STORYFORGE_AI_API_KEY');self.base_url=(base_url or os.getenv('STORYFORGE_AI_BASE_URL','https://api.openai.com/v1')).rstrip('/');self.model=model or os.getenv('STORYFORGE_AI_MODEL','gpt-4o-mini');self.timeout=timeout
 def generate(self,prompt,**kwargs):
  if not self.api_key:raise RuntimeError('API credential is not configured')
  payload={'model':self.model,'messages':[{'role':'user','content':prompt}],**kwargs};req=urllib.request.Request(self.base_url+'/chat/completions',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+self.api_key,'Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(req,timeout=self.timeout) as response:raw=response.read().decode();data=json.loads(raw)
  except urllib.error.HTTPError as e:raise RuntimeError(f'Provider request failed (HTTP {e.code})') from None
  except (urllib.error.URLError,TimeoutError) as e:raise RuntimeError(f'Provider connection failed ({type(e).__name__})') from None
  choices=data.get('choices') or []
  if not choices:raise RuntimeError('Provider returned no choices')
  return ProviderResult('openai-compatible',choices[0].get('message',{}),raw)
