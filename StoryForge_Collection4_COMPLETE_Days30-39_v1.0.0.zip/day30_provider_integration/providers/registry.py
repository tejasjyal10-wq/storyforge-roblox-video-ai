class ProviderRegistry:
 def __init__(self):self._providers={}
 def register(self,name,provider,replace=False):
  if name in self._providers and not replace:raise ValueError('provider already registered')
  self._providers[name]=provider
 def get(self,name):
  if name not in self._providers:raise KeyError('unknown provider: '+name)
  return self._providers[name]
 def names(self):return sorted(self._providers)
