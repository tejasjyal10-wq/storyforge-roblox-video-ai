import json
class StructuredOutputError(ValueError):pass
def parse_json_object(text,required=()):
 try:data=json.loads(text)
 except json.JSONDecodeError as e:raise StructuredOutputError('invalid JSON') from e
 if not isinstance(data,dict):raise StructuredOutputError('expected JSON object')
 missing=[key for key in required if key not in data]
 if missing:raise StructuredOutputError('missing required keys: '+', '.join(missing))
 return data
