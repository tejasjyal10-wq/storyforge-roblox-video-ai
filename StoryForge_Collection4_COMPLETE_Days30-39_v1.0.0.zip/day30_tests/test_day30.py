import unittest
from storyforge_collection4.providers.base import ProviderResult
from storyforge_collection4.providers.registry import ProviderRegistry
from storyforge_collection4.execution import TaskExecutor
from storyforge_collection4.structured import parse_json_object,StructuredOutputError
class Fake:
 def generate(self,prompt):return ProviderResult('fake',{'ok':True})
class Tests(unittest.TestCase):
 def test_register(self):
  r=ProviderRegistry();r.register('x',Fake());self.assertEqual(r.names(),['x'])
 def test_duplicate(self):
  r=ProviderRegistry();r.register('x',Fake())
  with self.assertRaises(ValueError):r.register('x',Fake())
 def test_executor(self):self.assertEqual(TaskExecutor(Fake()).run('hi')['status'],'success')
 def test_validator(self):self.assertEqual(TaskExecutor(Fake()).run('hi',lambda r:r.data['ok'])['status'],'success')
 def test_structured(self):self.assertEqual(parse_json_object('{"name":"x"}',('name',))['name'],'x')
 def test_invalid_json(self):
  with self.assertRaises(StructuredOutputError):parse_json_object('oops')
if __name__=='__main__':unittest.main()
