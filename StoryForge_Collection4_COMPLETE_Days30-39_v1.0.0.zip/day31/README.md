# StoryForge Collection 4 — Day 31: Character Asset Creation

Adds a stable-ID character asset catalog and a provider-ready character image creation pipeline.

## Features
- JSON persistence and reload; atomic save via temporary file.
- Stable character IDs, visual prompts, style, tags, metadata, image reference, provider and version.
- Provider interface (`CharacterImageProvider`) for image creation integrations.
- Pipeline reports whether only metadata was created or a provider image reference was returned.
- Validation and duplicate-ID protection; updates increment version.

## Honest limitation
Without a configured image provider, this creates and persists character metadata only—not rendered images. Provider implementations should return an HTTPS/file/data-image reference. This module does not download or host returned images.

## Run tests
From this folder: `python -m unittest discover -s tests -v`
