"""Persistent, stable-ID character asset records."""
from __future__ import annotations
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

@dataclass
class CharacterAsset:
    character_id: str
    name: str
    prompt: str
    style: str = "cinematic-stylized"
    asset_uri: str | None = None
    provider: str = "metadata-only"
    version: int = 1
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    def validate(self) -> None:
        if not self.character_id.strip(): raise ValueError("character_id is required")
        if not self.name.strip(): raise ValueError("name is required")
        if not self.prompt.strip(): raise ValueError("prompt is required")
        if self.version < 1: raise ValueError("version must be >= 1")
        if self.asset_uri is not None and not (self.asset_uri.startswith("https://") or self.asset_uri.startswith("file://") or self.asset_uri.startswith("data:image/")):
            raise ValueError("asset_uri must be https, file, or image data URI")
class CharacterAssetStore:
    """JSON-backed catalog. Writes atomically to reduce corruption risk."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._assets: dict[str, CharacterAsset] = {}
        self.load()
    def load(self) -> None:
        if not self.path.exists(): return
        data = json.loads(self.path.read_text(encoding="utf-8"))
        records = data.get("characters", [])
        loaded = {}
        for item in records:
            obj = CharacterAsset(**item); obj.validate(); loaded[obj.character_id] = obj
        self._assets = loaded
    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema_version": 1, "characters": [asdict(x) for x in self.list()]}
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self.path)
    def register(self, asset: CharacterAsset, *, replace: bool = False) -> CharacterAsset:
        asset.validate()
        if asset.character_id in self._assets and not replace:
            raise ValueError(f"character already exists: {asset.character_id}")
        self._assets[asset.character_id] = asset
        self.save(); return asset
    def get(self, character_id: str) -> CharacterAsset | None: return self._assets.get(character_id)
    def list(self) -> list[CharacterAsset]: return sorted(self._assets.values(), key=lambda x: x.name.casefold())
    def remove(self, character_id: str) -> bool:
        if character_id not in self._assets: return False
        del self._assets[character_id]; self.save(); return True
