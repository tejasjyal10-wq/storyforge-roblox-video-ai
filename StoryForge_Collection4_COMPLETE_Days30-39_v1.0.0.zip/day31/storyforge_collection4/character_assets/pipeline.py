"""Character asset creation workflow with pluggable provider and honest output state."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol
from .models import CharacterAsset, CharacterAssetStore
@dataclass
class CharacterAssetRequest:
    character_id: str
    name: str
    visual_description: str
    style: str = "cinematic-stylized"
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
@dataclass
class CharacterAssetResult:
    character: CharacterAsset
    status: str
    notes: list[str] = field(default_factory=list)
class CharacterImageProvider(Protocol):
    def create_character_image(self, request: CharacterAssetRequest) -> str: ...
class CharacterAssetPipeline:
    def __init__(self, store: CharacterAssetStore, provider: CharacterImageProvider | None = None):
        self.store = store; self.provider = provider
    def create(self, request: CharacterAssetRequest, *, metadata_only: bool = False) -> CharacterAssetResult:
        if not request.character_id.strip() or not request.name.strip() or not request.visual_description.strip():
            raise ValueError("character_id, name, and visual_description are required")
        uri = None; provider_name = "metadata-only"; status = "metadata_created"
        notes = ["Character profile and stable ID were saved."]
        if self.provider is not None and not metadata_only:
            uri = self.provider.create_character_image(request)
            provider_name = self.provider.__class__.__name__; status = "image_reference_created"
            notes.append("Provider returned an image reference; the image itself is not stored by this module.")
        else:
            notes.append("No image provider was run; this is metadata, not a rendered image.")
        existing = self.store.get(request.character_id)
        version = existing.version + 1 if existing else 1
        asset = CharacterAsset(character_id=request.character_id, name=request.name, prompt=request.visual_description,
            style=request.style, asset_uri=uri, provider=provider_name, version=version, tags=list(request.tags), metadata=dict(request.metadata))
        self.store.register(asset, replace=existing is not None)
        return CharacterAssetResult(asset, status, notes)
