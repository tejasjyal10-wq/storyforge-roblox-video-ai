import tempfile, unittest
from pathlib import Path
from storyforge_collection4.character_assets import CharacterAssetStore, CharacterAssetPipeline, CharacterAssetRequest
class FakeProvider:
    def create_character_image(self, request): return "https://assets.example/char.png"
class CharacterAssetTests(unittest.TestCase):
    def setUp(self): self.temp=tempfile.TemporaryDirectory(); self.path=Path(self.temp.name)/"characters.json"; self.store=CharacterAssetStore(self.path)
    def tearDown(self): self.temp.cleanup()
    def req(self): return CharacterAssetRequest("char-001","Ari","Young adventurer with a teal jacket",tags=["main"])
    def test_metadata_create_and_reload(self):
        result=CharacterAssetPipeline(self.store).create(self.req())
        self.assertEqual(result.status,"metadata_created"); self.assertIsNone(result.character.asset_uri)
        reloaded=CharacterAssetStore(self.path); self.assertEqual(reloaded.get("char-001").name,"Ari")
    def test_provider_reference_and_version(self):
        pipeline=CharacterAssetPipeline(self.store,FakeProvider()); a=pipeline.create(self.req()).character; b=pipeline.create(self.req()).character
        self.assertEqual(a.asset_uri,"https://assets.example/char.png"); self.assertEqual(b.version,2)
    def test_duplicate_store_guard(self):
        a=pipeline=CharacterAssetPipeline(self.store); pipeline.create(self.req())
        with self.assertRaises(ValueError): self.store.register(pipeline.create(self.req()).character)
    def test_invalid_request(self):
        with self.assertRaises(ValueError): CharacterAssetPipeline(self.store).create(CharacterAssetRequest("","",""))
    def test_remove(self):
        CharacterAssetPipeline(self.store).create(self.req()); self.assertTrue(self.store.remove("char-001")); self.assertIsNone(self.store.get("char-001"))
if __name__ == "__main__": unittest.main()
