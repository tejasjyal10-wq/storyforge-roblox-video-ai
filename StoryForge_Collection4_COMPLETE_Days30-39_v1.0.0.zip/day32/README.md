# StoryForge Collection 4 — Day 32: Environment & Prop Creation


## Included
- JSON-backed reusable catalog for environments, locations, props, and structures.
- Stable asset IDs, tags, metadata, dependency references, and versioned updates.
- Dependency validation and deletion guards so referenced assets cannot be removed.
- Provider interface for real generation services; explicit metadata-only mode.
- Atomic file replacement on save.

## Use
Add the `storyforge_collection4` package to your Python path and import:
`WorldAssetStore`, `WorldAssetPipeline`, `WorldAssetRequest` from `storyforge_collection4.world_assets`.

This module records asset metadata and provider-returned references. It does not claim to generate 3D models or textures without a configured provider.
## Tests
Run from this directory: `python -m unittest discover -s tests -v`
