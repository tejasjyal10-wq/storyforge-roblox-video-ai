"""Persistent world/environment/prop asset records."""
from __future__ import annotations
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

ASSET_TYPES = {"environment", "location", "prop", "structure"}

@dataclass
class WorldAsset:
    asset_id: str
    name: str
    asset_type: str
    description: str
    style: str = "cinematic-stylized"
    asset_uri: str | None = None
    provider: str = "metadata-only"
    version: int = 1
    tags: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    def validate(self) -> None:
        for field_name in ("asset_id", "name", "description"):
            if not getattr(self, field_name).strip():
                raise ValueError(f"{field_name} is required")
        if self.asset_type not in ASSET_TYPES:
            raise ValueError(f"asset_type must be one of {sorted(ASSET_TYPES)}")
        if self.version < 1:
            raise ValueError("version must be >= 1")
        if self.asset_uri is not None and not self.asset_uri.startswith(("https://", "file://", "data:")):
            raise ValueError("asset_uri must use https, file, or data scheme")
        if self.asset_id in self.dependencies:
            raise ValueError("asset cannot depend on itself")

class WorldAssetStore:
    """JSON catalog with atomic saves and dependency-aware removal."""
    def __init__(self, path: str | Path):
        self.path = Path(path); self._assets: dict[str, WorldAsset] = {}; self.load()
    def load(self) -> None:
        if not self.path.exists(): return
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        loaded = {}
        for row in payload.get("assets", []):
            asset = WorldAsset(**row); asset.validate(); loaded[asset.asset_id] = asset
        self._assets = loaded
    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {"schema_version": 1, "assets": [asdict(a) for a in self.list()]}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)
    def register(self, asset: WorldAsset, *, replace: bool = False) -> WorldAsset:
        asset.validate()
        if asset.asset_id in self._assets and not replace:
            raise ValueError(f"asset already exists: {asset.asset_id}")
        missing = [dep for dep in asset.dependencies if dep not in self._assets]
        if missing: raise ValueError(f"unknown dependencies: {', '.join(missing)}")
        self._assets[asset.asset_id] = asset; self.save(); return asset
    def get(self, asset_id: str) -> WorldAsset | None: return self._assets.get(asset_id)
    def list(self, *, asset_type: str | None = None, tag: str | None = None) -> list[WorldAsset]:
        values = self._assets.values()
        if asset_type: values = (a for a in values if a.asset_type == asset_type)
        if tag: values = (a for a in values if tag in a.tags)
        return sorted(values, key=lambda a: a.name.casefold())
    def remove(self, asset_id: str) -> bool:
        if asset_id not in self._assets: return False
        users = [a.asset_id for a in self._assets.values() if asset_id in a.dependencies]
        if users: raise ValueError(f"asset is referenced by: {', '.join(users)}")
        del self._assets[asset_id]; self.save(); return True
