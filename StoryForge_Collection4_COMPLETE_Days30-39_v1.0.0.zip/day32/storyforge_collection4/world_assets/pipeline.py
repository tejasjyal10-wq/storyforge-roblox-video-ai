"""Provider-backed world asset workflow; metadata mode is explicit."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol
from .models import WorldAsset, WorldAssetStore
@dataclass
class WorldAssetRequest:
    asset_id: str
    name: str
    asset_type: str
    description: str
    style: str = "cinematic-stylized"
    tags: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
class WorldAssetProvider(Protocol):
    def create_asset(self, request: WorldAssetRequest) -> str: ...
class WorldAssetPipeline:
    def __init__(self, store: WorldAssetStore, provider: WorldAssetProvider | None = None):
        self.store = store; self.provider = provider
    def create(self, request: WorldAssetRequest, *, metadata_only: bool = False) -> WorldAsset:
        uri = None; provider_name = "metadata-only"
        if self.provider is not None and not metadata_only:
            uri = self.provider.create_asset(request)
            provider_name = type(self.provider).__name__
        existing = self.store.get(request.asset_id)
        asset = WorldAsset(asset_id=request.asset_id, name=request.name, asset_type=request.asset_type,
            description=request.description, style=request.style, asset_uri=uri, provider=provider_name,
            version=(existing.version + 1 if existing else 1), tags=list(request.tags),
            dependencies=list(request.dependencies), metadata=dict(request.metadata))
        self.store.register(asset, replace=existing is not None)
        return asset
