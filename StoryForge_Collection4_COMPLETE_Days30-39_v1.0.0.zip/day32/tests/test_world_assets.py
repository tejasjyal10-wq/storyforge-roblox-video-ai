import json, tempfile, unittest
from pathlib import Path
from storyforge_collection4.world_assets import WorldAsset, WorldAssetStore, WorldAssetRequest, WorldAssetPipeline
class FakeProvider:
    def create_asset(self, req): return "https://assets.example.test/" + req.asset_id
class Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.path=Path(self.tmp.name)/"assets.json"; self.store=WorldAssetStore(self.path)
    def tearDown(self): self.tmp.cleanup()
    def test_register_and_reload(self):
        a=WorldAsset("forest","Forest","environment","dense forest")
        self.store.register(a); self.assertEqual(WorldAssetStore(self.path).get("forest").name,"Forest")
    def test_duplicate_rejected(self):
        a=WorldAsset("x","X","prop","small object"); self.store.register(a)
        with self.assertRaises(ValueError): self.store.register(a)
    def test_type_and_uri_validation(self):
        with self.assertRaises(ValueError): WorldAsset("x","X","unknown","desc").validate()
        with self.assertRaises(ValueError): WorldAsset("x","X","prop","desc",asset_uri="bad://x").validate()
    def test_dependency_filter_and_removal_guard(self):
        self.store.register(WorldAsset("base","Base","environment","base"))
        self.store.register(WorldAsset("hut","Hut","structure","hut",dependencies=["base"],tags=["village"]))
        self.assertEqual(len(self.store.list(tag="village")),1)
        with self.assertRaises(ValueError): self.store.remove("base")
        self.assertTrue(self.store.remove("hut")); self.assertTrue(self.store.remove("base"))
    def test_pipeline_provider_and_version(self):
        pipe=WorldAssetPipeline(self.store,FakeProvider())
        req=WorldAssetRequest("tree","Tree","prop","oak tree")
        first=pipe.create(req); self.assertEqual(first.asset_uri,"https://assets.example.test/tree")
        second=pipe.create(req); self.assertEqual(second.version,2)
    def test_metadata_only_honest(self):
        a=WorldAssetPipeline(self.store,FakeProvider()).create(WorldAssetRequest("rock","Rock","prop","stone"),metadata_only=True)
        self.assertIsNone(a.asset_uri); self.assertEqual(a.provider,"metadata-only")
    def test_json_schema_and_atomic_save_file(self):
        self.store.register(WorldAsset("x","X","location","a place")); d=json.loads(self.path.read_text()); self.assertEqual(d["schema_version"],1); self.assertFalse(self.path.with_suffix(".json.tmp").exists())
if __name__=="__main__": unittest.main()
