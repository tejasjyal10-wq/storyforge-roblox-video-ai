# StoryForge Collection 4 — Day 33: Rigging & Animation Execution
Defines validated animation clips (ordered motion keys, duration, actions, loop, metadata) and an execution dispatcher to a rig/runtime adapter. The adapter interface is ready for Blender/Roblox/runtime implementations; no rigging engine is included in this day. Clip validation rejects invalid durations, unordered/out-of-range keys, empty poses, and malformed actions.
Run tests: `python -m unittest discover -s tests -v`
