from __future__ import annotations
from dataclasses import asdict
from typing import Protocol
from .models import AnimationClip
class RigAdapter(Protocol):
    def prepare(self, character_id: str) -> None: ...
    def apply_key(self, character_id: str, key: dict) -> None: ...
    def execute_action(self, character_id: str, action: dict) -> None: ...
class AnimationExecutor:
    """Validates clips and dispatches to a rig runtime. No rig runtime is bundled."""
    def __init__(self, adapter: RigAdapter): self.adapter=adapter
    def execute(self, clip: AnimationClip) -> dict:
        clip.validate(); self.adapter.prepare(clip.character_id)
        for key in clip.keys: self.adapter.apply_key(clip.character_id, asdict(key))
        for action in clip.actions: self.adapter.execute_action(clip.character_id, action)
        return {'clip_id':clip.clip_id,'character_id':clip.character_id,'status':'dispatched',
                'keys_dispatched':len(clip.keys),'actions_dispatched':len(clip.actions),'duration':clip.duration}
