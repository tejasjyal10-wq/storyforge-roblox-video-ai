from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
@dataclass
class MotionKey:
    time: float
    pose: dict[str, Any]
    def validate(self):
        if self.time < 0: raise ValueError('key time must be non-negative')
        if not isinstance(self.pose, dict) or not self.pose: raise ValueError('pose must be a non-empty object')
@dataclass
class AnimationClip:
    clip_id: str
    character_id: str
    name: str
    duration: float
    keys: list[MotionKey] = field(default_factory=list)
    actions: list[dict[str, Any]] = field(default_factory=list)
    loop: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    def validate(self):
        for f in ('clip_id','character_id','name'):
            if not getattr(self,f).strip(): raise ValueError(f'{f} is required')
        if self.duration <= 0: raise ValueError('duration must be positive')
        for k in self.keys:
            k.validate()
            if k.time > self.duration: raise ValueError('key exceeds clip duration')
        if self.keys != sorted(self.keys, key=lambda k:k.time): raise ValueError('keys must be time ordered')
        for action in self.actions:
            if not isinstance(action,dict) or not action.get('type'): raise ValueError('actions need a type')
