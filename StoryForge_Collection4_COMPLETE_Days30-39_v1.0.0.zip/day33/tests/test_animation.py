import unittest
from storyforge_collection4.animation import MotionKey, AnimationClip, AnimationExecutor
class Adapter:
 def __init__(self): self.prepared=[]; self.keys=[]; self.actions=[]
 def prepare(self,c): self.prepared.append(c)
 def apply_key(self,c,k): self.keys.append((c,k))
 def execute_action(self,c,a): self.actions.append((c,a))
class Tests(unittest.TestCase):
 def test_dispatch_valid_clip(self):
  a=Adapter(); clip=AnimationClip('walk','hero','Walk',2,[MotionKey(0,{'root':'start'}),MotionKey(1,{'root':'step'})],[{'type':'walk','speed':1.0}]); r=AnimationExecutor(a).execute(clip)
  self.assertEqual(r['status'],'dispatched'); self.assertEqual(len(a.keys),2); self.assertEqual(len(a.actions),1)
 def test_duration_and_order_validation(self):
  with self.assertRaises(ValueError): AnimationClip('bad','hero','Bad',1,[MotionKey(2,{'x':1})]).validate()
  with self.assertRaises(ValueError): AnimationClip('bad','hero','Bad',2,[MotionKey(1,{'x':1}),MotionKey(0,{'x':2})]).validate()
 def test_empty_pose_rejected(self):
  with self.assertRaises(ValueError): MotionKey(0,{}).validate()
 def test_action_type_required(self):
  with self.assertRaises(ValueError): AnimationClip('x','h','X',1,actions=[{}]).validate()
 def test_action_only_clip(self):
  a=Adapter(); r=AnimationExecutor(a).execute(AnimationClip('jump','h','Jump',1,actions=[{'type':'jump'}])); self.assertEqual(r['actions_dispatched'],1)
if __name__=='__main__': unittest.main()
