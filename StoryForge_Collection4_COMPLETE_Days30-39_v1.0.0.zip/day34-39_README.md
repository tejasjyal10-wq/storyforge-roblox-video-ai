# StoryForge Collection 4 — Days 34–39


Production execution modules (Python standard library only). Blender and Roblox Studio are external programs; FFmpeg is required for real clip assembly. These modules do not claim external-app outputs unless run and verified.

## Days
- 34 Blender CLI bridge: validated scene primitives, generated Blender script, optional CLI execution and output verification.
- 35 Cinematic shot planning, validation, timing and JSON export.
- 36 WAV test-signal generation/inspection and TTS provider interface.
- 37 FFmpeg clip assembly with source and output verification.
- 38 Roblox Luau scene bootstrap export.
- 39 resumable production manifest/status tracking.
## Tests
`python -m unittest discover -s tests -v`
