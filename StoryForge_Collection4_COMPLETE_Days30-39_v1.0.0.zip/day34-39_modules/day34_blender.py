"""Blender CLI bridge: generates a validated Blender Python scene and optionally runs Blender."""
from pathlib import Path
import json, shutil, subprocess

def make_blender_script(scene, output_blend):
    primitives=[]
    for item in scene.get('objects',[]):
        kind=item.get('type','cube')
        if kind not in ('cube','sphere','cylinder'): raise ValueError('unsupported primitive: '+kind)
        primitives.append({'type':kind,'name':str(item.get('name',kind))[:80],
          'location':[float(x) for x in item.get('location',[0,0,0])],
          'scale':[float(x) for x in item.get('scale',[1,1,1])]})
    encoded=json.dumps(primitives)
    out=repr(str(Path(output_blend).resolve()))
    return ("import bpy, json\n" "bpy.ops.object.select_all(action='SELECT')\n" "bpy.ops.object.delete(use_global=False)\n"
      f"objects=json.loads({encoded!r})\n" "for item in objects:\n" "    t=item['type']\n"
      "    if t=='cube': bpy.ops.mesh.primitive_cube_add(location=item['location'])\n"
      "    elif t=='sphere': bpy.ops.mesh.primitive_uv_sphere_add(location=item['location'])\n"
      "    else: bpy.ops.mesh.primitive_cylinder_add(location=item['location'])\n"
      "    obj=bpy.context.object; obj.name=item['name']; obj.scale=item['scale']\n"
      f"bpy.ops.wm.save_as_mainfile(filepath={out})\n")

def run_blender(scene, output_blend, script_path=None, blender_executable=None):
    exe=blender_executable or shutil.which('blender')
    if not exe: return {'status':'unavailable','reason':'Blender executable not found'}
    script_path=script_path or str(Path(output_blend).with_suffix('.blender.py'))
    Path(script_path).write_text(make_blender_script(scene,output_blend),encoding='utf8')
    proc=subprocess.run([exe,'--background','--python',script_path],capture_output=True,text=True,timeout=300)
    exists=Path(output_blend).is_file()
    return {'status':'success' if proc.returncode==0 and exists else 'failed','returncode':proc.returncode,
      'blend_file':output_blend,'stdout':proc.stdout[-2000:],'stderr':proc.stderr[-2000:]}
