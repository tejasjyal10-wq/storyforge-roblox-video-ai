"""Shot planning and cinematic validation/export."""
from dataclasses import dataclass,asdict
import json
@dataclass
class Shot:
    shot_id:str; scene_id:str; duration:float; camera:str; description:str; transition:str='cut'; mood:str='neutral'
class CinematicPlan:
    def __init__(self,shots): self.shots=[Shot(**s) for s in shots]
    def validate(self):
        errors=[]; seen=set()
        for s in self.shots:
            if not s.shot_id or s.shot_id in seen: errors.append('shot IDs must be unique and non-empty')
            seen.add(s.shot_id)
            if s.duration<=0: errors.append(f'{s.shot_id}: duration must be positive')
            if not s.camera.strip(): errors.append(f'{s.shot_id}: camera required')
            if s.transition not in {'cut','fade','dissolve','wipe'}: errors.append(f'{s.shot_id}: invalid transition')
        return errors
    def total_duration(self): return sum(s.duration for s in self.shots)
    def export(self,path):
        errors=self.validate()
        if errors: raise ValueError('; '.join(errors))
        with open(path,'w',encoding='utf8') as f: json.dump({'shots':[asdict(s) for s in self.shots],'duration':self.total_duration()},f,indent=2)
        return path
