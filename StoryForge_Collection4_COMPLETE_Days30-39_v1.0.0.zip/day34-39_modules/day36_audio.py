"""Audio utilities; test tone generation and a speech synthesis adapter contract."""
from pathlib import Path
import wave,struct,math
class SpeechProvider:
    def synthesize(self,text,output_path,voice='default'): raise NotImplementedError('connect a TTS provider')
def write_test_tone(path,seconds=.25,frequency=440,sample_rate=22050):
    if seconds<=0 or seconds>30: raise ValueError('seconds must be >0 and <=30')
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(sample_rate)
        frames=int(seconds*sample_rate)
        for i in range(frames):
            env=min(1,i/(sample_rate*.01),(frames-i)/(sample_rate*.01))
            value=int(8000*max(0,env)*math.sin(2*math.pi*frequency*i/sample_rate))
            w.writeframes(struct.pack('<h',value))
    return str(path)
def validate_audio(path):
    p=Path(path)
    if not p.exists() or p.stat().st_size<44:return {'valid':False,'reason':'file missing or too small'}
    try:
        with wave.open(str(p),'rb') as w:return {'valid':w.getnframes()>0,'duration':w.getnframes()/w.getframerate(),'channels':w.getnchannels(),'sample_rate':w.getframerate()}
    except wave.Error as e:return {'valid':False,'reason':str(e)}
