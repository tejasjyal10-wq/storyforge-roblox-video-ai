"""FFmpeg clip assembly runner with input checks and output verification."""
from pathlib import Path
import shutil,subprocess
def assemble(clips,output_path,ffmpeg=None):
    clips=[str(Path(c).resolve()) for c in clips]
    if not clips:raise ValueError('at least one clip required')
    missing=[c for c in clips if not Path(c).is_file()]
    if missing:raise FileNotFoundError(', '.join(missing))
    exe=ffmpeg or shutil.which('ffmpeg')
    if not exe:return {'status':'unavailable','reason':'FFmpeg not found'}
    listing=Path(output_path).with_suffix('.concat.txt')
    listing.write_text('\n'.join("file '"+c.replace("'","'\\''")+"'" for c in clips)+'\n',encoding='utf8')
    proc=subprocess.run([exe,'-hide_banner','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy',str(output_path)],capture_output=True,text=True,timeout=600)
    ok=proc.returncode==0 and Path(output_path).is_file() and Path(output_path).stat().st_size>0
    return {'status':'success' if ok else 'failed','returncode':proc.returncode,'output':str(output_path),'stderr':proc.stderr[-1200:]}
