"""Create a Luau scene bootstrap from structured scene object data."""
def export_luau(scene,path):
    lines=['-- StoryForge scene export','local Workspace = game:GetService("Workspace")','local sceneFolder = Instance.new("Folder")','sceneFolder.Name = "StoryForgeScene"','sceneFolder.Parent = Workspace']
    for i,obj in enumerate(scene.get('objects',[]),1):
        name=str(obj.get('name','Part')).replace('\\','').replace('"','')[:64]
        size=[float(v) for v in obj.get('size',[4,1,4])]; pos=[float(v) for v in obj.get('position',[0,3,0])]
        if len(size)!=3 or len(pos)!=3 or any(v<=0 for v in size):raise ValueError('size and position must be valid 3D vectors')
        lines.extend([f'local p{i} = Instance.new("Part")',f'p{i}.Name = "{name}"',f'p{i}.Size = Vector3.new({size[0]}, {size[1]}, {size[2]})',f'p{i}.Position = Vector3.new({pos[0]}, {pos[1]}, {pos[2]})',f'p{i}.Anchored = true',f'p{i}.Parent = sceneFolder'])
    with open(path,'w',encoding='utf8') as f:f.write('\n'.join(lines)+'\n')
    return path
