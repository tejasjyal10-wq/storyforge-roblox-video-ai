"""Persisted production stage tracking and recovery-friendly manifests."""
from pathlib import Path
import json,time
STAGES=['assets','animation','blender','cinematic','audio','video','roblox']
def create_manifest(project,path):
    data={'project_id':project.get('project_id','untitled'),'created':int(time.time()),'stages':{s:{'status':'pending'} for s in STAGES}}
    Path(path).write_text(json.dumps(data,indent=2),encoding='utf8');return data
def set_stage(path,stage,status,detail=''):
    if stage not in STAGES:raise ValueError('unknown stage')
    if status not in {'pending','running','success','failed','skipped'}:raise ValueError('invalid status')
    p=Path(path);data=json.loads(p.read_text(encoding='utf8'));data['stages'][stage]={'status':status,'detail':detail,'updated':int(time.time())};p.write_text(json.dumps(data,indent=2),encoding='utf8');return data
def summary(path):
    data=json.loads(Path(path).read_text(encoding='utf8')); values=[s['status'] for s in data['stages'].values()]
    return {'project_id':data['project_id'],'complete':all(v=='success' for v in values),'done':values.count('success'),'total':len(values),'failed':values.count('failed'),'pending':values.count('pending')}
