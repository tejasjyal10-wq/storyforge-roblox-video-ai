import tempfile,unittest
from pathlib import Path
from sf_prod.day34_blender import make_blender_script
from sf_prod.day35_cinematic import CinematicPlan
from sf_prod.day36_audio import write_test_tone,validate_audio
from sf_prod.day37_video import assemble
from sf_prod.day38_roblox import export_luau
from sf_prod.day39_pipeline import create_manifest,set_stage,summary
class ProductionTests(unittest.TestCase):
 def test_blender_script(self):self.assertIn('primitive_cube_add',make_blender_script({'objects':[{'type':'cube'}]},'test.blend'))
 def test_blender_invalid_primitive(self):
  with self.assertRaises(ValueError):make_blender_script({'objects':[{'type':'dragon'}]},'x.blend')
 def test_cinematic_plan(self):
  p=CinematicPlan([{'shot_id':'one','scene_id':'s','duration':2,'camera':'wide','description':'opening'}]);self.assertFalse(p.validate());self.assertEqual(p.total_duration(),2)
 def test_cinematic_bad(self):
  p=CinematicPlan([{'shot_id':'one','scene_id':'s','duration':0,'camera':'','description':'x'}]);self.assertTrue(p.validate())
 def test_audio_file_valid(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'test.wav';write_test_tone(p);self.assertTrue(validate_audio(p)['valid'])
 def test_audio_bad_duration(self):
  with self.assertRaises(ValueError):write_test_tone('bad.wav',0)
 def test_missing_video_clip(self):
  with self.assertRaises(FileNotFoundError):assemble(['missing.mp4'],'out.mp4')
 def test_roblox_export(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'scene.lua';export_luau({'objects':[{'name':'Tree','size':[2,5,2],'position':[0,2,0]}]},p);self.assertIn('StoryForgeScene',p.read_text())
 def test_manifest_updates(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'manifest.json';create_manifest({'project_id':'demo'},p);set_stage(p,'assets','success');self.assertEqual(summary(p)['done'],1)
 def test_invalid_stage(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'m.json';create_manifest({},p)
   with self.assertRaises(ValueError):set_stage(p,'bogus','success')
if __name__=='__main__':unittest.main()
