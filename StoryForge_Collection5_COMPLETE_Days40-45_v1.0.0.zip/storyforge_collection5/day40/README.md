Day 40 Unified Core is included in day40_package/ from the existing verified package.
