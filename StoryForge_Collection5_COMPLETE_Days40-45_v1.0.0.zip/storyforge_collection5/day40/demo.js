import { StoryForgeCore } from './src/index.js';
const core = new StoryForgeCore({ project:{id:'demo-001',title:'The Forest Gate'}, adapters:{ story:{execute:async input=>({ ...input, outline:['Arrival','Discovery','Climax'] })}, scenePlan:{execute:async input=>({ ...input, sceneCount:3 })} } });
core.addTask({id:'story',adapter:'story',input:{premise:'A traveler discovers a hidden forest gate.'}});
core.addTask({id:'scene-plan',adapter:'scenePlan',dependencies:['story'],input:{style:'cinematic'}});
console.log(JSON.stringify(await core.run(),null,2));
