/** Registry describes prior collections without falsely claiming live runtime availability. */
export const COLLECTION_MANIFEST = Object.freeze([
  { collection: 1, days: [1,9], systems: ['story model','scene runtime','character library','branching interactions'], language: 'javascript', runtimeStatus: 'code-level' },
  { collection: 2, days: [10,19], systems: ['orchestrator','pipeline','asset registry','compatibility','Blender bridge','Roblox adapter','recovery'], language: 'javascript', runtimeStatus: 'code-level' },
  { collection: 3, days: [20,29], systems: ['story intelligence','scene intelligence','cinematic director','character behavior','action motion','provider asset layer'], language: 'javascript', runtimeStatus: 'code-level' },
  { collection: 4, days: [30,39], systems: ['provider integration','character assets','environment assets','rig animation','Blender production','cinematic execution','voice/audio','video assembly','Roblox execution','integration testing'], language: 'python', runtimeStatus: 'mixed; external runtimes not all verified' },
  { collection: 5, days: [40,45], systems: ['unified core','production agent','automated film production','interactive world generation','quality continuity recovery','final integration'], language: 'planned/in progress', runtimeStatus: 'not complete' }
]);
