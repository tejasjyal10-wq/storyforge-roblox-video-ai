import { randomUUID } from 'node:crypto';

const deepClone = value => structuredClone(value);
const REQUIRED_PROJECT_FIELDS = ['id', 'title'];

/** Collection 5 Day 40: unified state, adapter registry, task graph, and event journal. */
export class StoryForgeCore {
  constructor({ project = {}, adapters = {}, clock = () => new Date().toISOString() } = {}) {
    for (const field of REQUIRED_PROJECT_FIELDS) if (!project[field]) throw new Error(`Project field required: ${field}`);
    this.project = { id: project.id, title: project.title, status: project.status ?? 'draft', metadata: deepClone(project.metadata ?? {}), story: deepClone(project.story ?? null), scenes: deepClone(project.scenes ?? []), assets: deepClone(project.assets ?? []), outputs: deepClone(project.outputs ?? []), createdAt: project.createdAt ?? clock(), updatedAt: clock() };
    this.adapters = new Map();
    this.tasks = new Map();
    this.events = [];
    this.clock = clock;
    this._event('core-created', { projectId: this.project.id });
    for (const [name, adapter] of Object.entries(adapters)) this.registerAdapter(name, adapter);
  }
  registerAdapter(name, adapter) {
    if (!name || !adapter || typeof adapter.execute !== 'function') throw new Error('Adapter requires a name and execute function');
    if (this.adapters.has(name)) throw new Error(`Adapter already registered: ${name}`);
    this.adapters.set(name, { name, execute: adapter.execute, capabilities: [...(adapter.capabilities ?? [])], status: adapter.status ?? 'available' });
    this._event('adapter-registered', { adapter: name, capabilities: [...(adapter.capabilities ?? [])] });
    return this;
  }
  listAdapters() { return [...this.adapters.values()].map(a => ({ name: a.name, capabilities: [...a.capabilities], status: a.status })); }
  updateProject(patch) {
    const allowed = ['title','status','metadata','story','scenes','assets','outputs'];
    for (const key of Object.keys(patch)) if (!allowed.includes(key)) throw new Error(`Unsupported project field: ${key}`);
    this.project = { ...this.project, ...deepClone(patch), updatedAt: this.clock() };
    this._event('project-updated', { fields: Object.keys(patch) });
    return this.snapshot();
  }
  addTask({ id = randomUUID(), adapter, input = {}, dependencies = [] } = {}) {
    if (!adapter || !this.adapters.has(adapter)) throw new Error(`Unknown adapter: ${adapter}`);
    if (this.tasks.has(id)) throw new Error(`Duplicate task: ${id}`);
    this.tasks.set(id, { id, adapter, input: deepClone(input), dependencies: [...dependencies], status: 'pending', attempts: 0, result: null, error: null });
    this._event('task-added', { taskId: id, adapter, dependencies });
    return id;
  }
  _validateTasks() {
    for (const task of this.tasks.values()) for (const dep of task.dependencies) if (!this.tasks.has(dep)) throw new Error(`Missing dependency ${dep} for task ${task.id}`);
    const visiting = new Set(), visited = new Set();
    const visit = id => { if (visiting.has(id)) throw new Error(`Dependency cycle at ${id}`); if (visited.has(id)) return; visiting.add(id); for (const dep of this.tasks.get(id).dependencies) visit(dep); visiting.delete(id); visited.add(id); };
    for (const id of this.tasks.keys()) visit(id);
  }
  async run({ maxRetries = 0 } = {}) {
    this._validateTasks();
    while ([...this.tasks.values()].some(t => t.status === 'pending')) {
      const ready = [...this.tasks.values()].filter(t => t.status === 'pending' && t.dependencies.every(d => this.tasks.get(d).status === 'completed'));
      const blocked = [...this.tasks.values()].filter(t => t.status === 'pending' && t.dependencies.some(d => ['failed','blocked'].includes(this.tasks.get(d).status)));
      for (const task of blocked) { task.status = 'blocked'; this._event('task-blocked', { taskId: task.id }); }
      if (!ready.length) { if (blocked.length) continue; throw new Error('No runnable tasks remain'); }
      await Promise.all(ready.map(async task => {
        const adapter = this.adapters.get(task.adapter); task.status = 'running'; this._event('task-started', { taskId: task.id, adapter: task.adapter });
        while (task.attempts <= maxRetries) {
          task.attempts++;
          try {
            task.result = await adapter.execute(deepClone(task.input), { project: this.snapshotProject(), taskId: task.id, dependencies: task.dependencies.map(id => deepClone(this.tasks.get(id).result)) });
            task.status = 'completed'; this._event('task-completed', { taskId: task.id, attempt: task.attempts }); break;
          } catch (err) {
            task.error = String(err?.message ?? err); this._event('task-retry', { taskId: task.id, attempt: task.attempts, error: task.error });
            if (task.attempts > maxRetries) { task.status = 'failed'; this._event('task-failed', { taskId: task.id, error: task.error }); }
          }
        }
      }));
    }
    return this.report();
  }
  snapshotProject() { return deepClone(this.project); }
  snapshot() { return { project: this.snapshotProject(), adapters: this.listAdapters(), tasks: [...this.tasks.values()].map(t => deepClone(t)), events: deepClone(this.events) }; }
  report() { const tasks = [...this.tasks.values()].map(t => deepClone(t)); return { total: tasks.length, completed: tasks.filter(t => t.status === 'completed').length, failed: tasks.filter(t => t.status === 'failed').length, blocked: tasks.filter(t => t.status === 'blocked').length, pending: tasks.filter(t => t.status === 'pending').length, tasks, adapters: this.listAdapters() }; }
  _event(type, data = {}) { this.events.push({ at: this.clock(), type, ...deepClone(data) }); }
}
