import test from 'node:test';
import assert from 'node:assert/strict';
import { StoryForgeCore, COLLECTION_MANIFEST } from '../src/index.js';

function makeCore() {
  return new StoryForgeCore({
    project: { id: 'p1', title: 'Demo Story' },
    adapters: {
      story: { capabilities: ['story'], execute: async input => ({ ...input, storyReady: true }) },
      render: { capabilities: ['render'], execute: async (input, ctx) => ({ input, projectId: ctx.project.id }) }
    }
  });
}

test('requires project id and title', () => { assert.throws(() => new StoryForgeCore({ project: { id: 'x' } }), /Project field required: title/); });
test('registers adapters and exposes capability list', () => { const c = makeCore(); assert.deepEqual(c.listAdapters().map(a => a.name), ['story', 'render']); });
test('rejects malformed and duplicate adapters', () => { const c = makeCore(); assert.throws(() => c.registerAdapter('bad', {}), /execute function/); assert.throws(() => c.registerAdapter('story', { execute() {} }), /already registered/); });
test('patches allowed project fields and rejects arbitrary fields', () => { const c = makeCore(); c.updateProject({ status: 'ready', scenes: [{ id: 's1' }] }); assert.equal(c.project.status, 'ready'); assert.equal(c.project.scenes.length, 1); assert.throws(() => c.updateProject({ secret: true }), /Unsupported project field/); });
test('executes tasks in dependency order and completes', async () => { const c = makeCore(); c.addTask({ id: 'a', adapter: 'story', input: { seed: 1 } }); c.addTask({ id: 'b', adapter: 'render', dependencies: ['a'], input: { frame: 10 } }); const r = await c.run(); assert.equal(r.completed, 2); assert.equal(c.tasks.get('b').result.projectId, 'p1'); });
test('rejects missing dependencies', async () => { const c = makeCore(); c.addTask({ id: 'a', adapter: 'story', dependencies: ['missing'] }); await assert.rejects(c.run(), /Missing dependency/); });
test('detects dependency cycles', async () => { const c = makeCore(); c.addTask({ id: 'a', adapter: 'story', dependencies: ['b'] }); c.addTask({ id: 'b', adapter: 'render', dependencies: ['a'] }); await assert.rejects(c.run(), /Dependency cycle/); });
test('retry failure and block downstream tasks', async () => { const c = new StoryForgeCore({ project: { id: 'p', title: 'Retry' }, adapters: { flaky: { execute: async () => { throw new Error('offline'); } }, pass: { execute: async () => true } } }); c.addTask({ id: 'a', adapter: 'flaky' }); c.addTask({ id: 'b', adapter: 'pass', dependencies: ['a'] }); const r = await c.run({ maxRetries: 1 }); assert.equal(r.failed, 1); assert.equal(r.blocked, 1); assert.equal(c.tasks.get('a').attempts, 2); });
test('snapshot is isolated from internal project state', () => { const c = makeCore(); const s = c.snapshot(); s.project.title = 'mutated'; assert.equal(c.project.title, 'Demo Story'); });
test('manifest lists collection 1 through 5 and Day 45', () => { assert.deepEqual(COLLECTION_MANIFEST.map(c => c.collection), [1, 2, 3, 4, 5]); assert.equal(COLLECTION_MANIFEST[4].days[1], 45); });
