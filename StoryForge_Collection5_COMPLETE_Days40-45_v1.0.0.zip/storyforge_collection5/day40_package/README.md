# StoryForge Collection 5 — Day 40: Unified Core

Day 40 creates a shared project state, adapter/capability registry, dependency-aware task graph, retry policy, event journal, and snapshot/report APIs. This is an integration core, not a claim that external runtimes (Blender, Roblox Studio, AI providers, or TTS) are connected or verified.

## Run
Requires Node.js 18+.
- `npm test` runs the built-in Node test suite.
- `npm run demo` runs a local demonstration using stub adapters.

## Adapter contract
An adapter registers with `{ execute(input, context) }`, optionally declares `capabilities`, and may declare `status`. `context` contains a project snapshot, task id, and completed dependency results. Task inputs/results are copied to avoid accidental mutation.
