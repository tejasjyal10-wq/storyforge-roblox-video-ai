Day 41 module: see src/day41_*.py and tests/test_collection5.py.
