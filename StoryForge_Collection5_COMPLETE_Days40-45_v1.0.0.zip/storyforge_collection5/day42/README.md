Day 42 module: see src/day42_*.py and tests/test_collection5.py.
