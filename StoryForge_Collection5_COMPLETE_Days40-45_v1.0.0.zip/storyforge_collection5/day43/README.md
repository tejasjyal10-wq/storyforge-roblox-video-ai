Day 43 module: see src/day43_*.py and tests/test_collection5.py.
