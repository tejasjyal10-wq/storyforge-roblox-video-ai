Day 44 module: see src/day44_*.py and tests/test_collection5.py.
