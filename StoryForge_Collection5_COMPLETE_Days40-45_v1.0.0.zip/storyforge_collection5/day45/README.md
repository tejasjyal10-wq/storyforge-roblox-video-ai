Day 45 module: see src/day45_*.py and tests/test_collection5.py.
