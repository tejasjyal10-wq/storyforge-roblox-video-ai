from src.day41_agent import ProductionAgent
from src.day42_film import FilmPlanner
from src.day43_world import WorldBuilder
from src.day44_quality import QualityGate
from src.day45_integrator import FinalIntegrator
brief='A traveler discovers an ancient forest and rescues a village.'
plan=ProductionAgent().plan(brief,'demo')
film=FilmPlanner().create('A traveler discovers an ancient forest. The village needs help.','demo')
world=WorldBuilder().build('Ancient Forest',['Village','Forest Path','Ruined Temple'],'demo-world')
quality=QualityGate().audit({'scenes':film['scenes']})
report=FinalIntegrator().audit({'id':'demo'},[{'status':'success'}])
print({'tasks':len(plan['tasks']),'scenes':len(film['scenes']),'shots':film['total_shots'],'world_locations':len(world['locations']),'quality':quality,'release_ready':report['ready_for_release']})
