"""Day 41: production agent planning, capability routing, and safe task intents."""
from dataclasses import dataclass, asdict
from typing import Any

@dataclass
class ProductionTask:
    id: str
    kind: str
    description: str
    adapter: str|None = None
    depends_on: list[str] = None
    status: str = 'planned'
    payload: dict[str,Any] = None
    def to_dict(self): return asdict(self)
class ProductionAgent:
    def __init__(self, capability_map=None):
        self.capabilities = capability_map or {'story':['story'], 'scene':['scene','environment'], 'character':['character','voice'], 'animation':['animation'], 'render':['blender','render'], 'video':['video','assembly'], 'interactive':['roblox','world']}
    def plan(self, brief, project_id='project'):
        if not isinstance(brief,str) or not brief.strip(): raise ValueError('brief must be non-empty')
        words=brief.strip(); tasks=[]
        tasks.append(ProductionTask(f'{project_id}-story','story','Develop a story outline and script', 'story',[],payload={'brief':words}))
        tasks.append(ProductionTask(f'{project_id}-scenes','scene','Break story into scenes and shots','scene',[f'{project_id}-story'],payload={'brief':words}))
        tasks.append(ProductionTask(f'{project_id}-assets','character','Resolve character, world, and prop assets','asset',[f'{project_id}-scenes'],payload={'brief':words}))
        tasks.append(ProductionTask(f'{project_id}-animation','animation','Prepare scene actions and animation','animation',[f'{project_id}-assets'],payload={'brief':words}))
        tasks.append(ProductionTask(f'{project_id}-render','render','Render planned scenes when renderer is available','blender',[f'{project_id}-animation'],payload={'brief':words}))
        tasks.append(ProductionTask(f'{project_id}-assembly','video','Assemble rendered shots and audio','video',[f'{project_id}-render'],payload={'brief':words}))
        return {'project_id':project_id,'brief':words,'tasks':[t.to_dict() for t in tasks],'routing':self.route(tasks)}
    def route(self,tasks):
        result=[]
        for task in tasks:
            kind=task.kind if isinstance(task,ProductionTask) else task.get('kind')
            matches=[adapter for adapter,capabilities in self.capabilities.items() if kind in capabilities]
            result.append({'task_id':task.id if isinstance(task,ProductionTask) else task['id'],'candidate_adapters':matches})
        return result
