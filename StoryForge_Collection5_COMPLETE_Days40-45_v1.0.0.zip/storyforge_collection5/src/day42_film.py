"""Day 42: film production breakdown, shot list, and task dependency graph."""
import re
class FilmPlanner:
    def create(self, story, project_id='film'):
        if not isinstance(story,str) or not story.strip(): raise ValueError('story is required')
        blocks=[b.strip() for b in re.split(r'(?<=[.!?])\s+|\n+',story.strip()) if b.strip()]
        scenes=[]
        for i,beat in enumerate(blocks,1):
            sid=f'{project_id}-scene-{i:03d}'
            scenes.append({'id':sid,'number':i,'beat':beat,'shots':[{'id':sid+'-shot-01','type':'wide','duration_seconds':5,'description':beat},{'id':sid+'-shot-02','type':'medium','duration_seconds':4,'description':f'Focus on the main action: {beat}'}], 'assets':[], 'audio_cues':[]})
        return {'project_id':project_id,'scenes':scenes,'total_shots':sum(len(s['shots']) for s in scenes),'estimated_duration_seconds':sum(x['duration_seconds'] for s in scenes for x in s['shots'])}
    def validate(self,plan):
        errors=[]; ids=set()
        for scene in plan.get('scenes',[]):
            if not scene.get('id'): errors.append('scene missing id')
            if scene.get('id') in ids: errors.append('duplicate scene id')
            ids.add(scene.get('id'))
            for shot in scene.get('shots',[]):
                if shot.get('duration_seconds',0)<=0: errors.append(f"shot {shot.get('id')} duration must be positive")
        return {'valid':not errors,'errors':errors}
