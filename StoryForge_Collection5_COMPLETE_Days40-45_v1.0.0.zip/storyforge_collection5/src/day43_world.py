"""Day 43: structured world, location, interactable, obstacle, and checkpoint generator."""
from copy import deepcopy
class WorldBuilder:
    def build(self,world_name,locations,seed_key='world'):
        if not world_name or not locations: raise ValueError('world name and locations required')
        result={'id':seed_key,'name':world_name,'locations':[],'interactables':[],'obstacles':[],'checkpoints':[],'triggers':[]}
        for i,loc in enumerate(locations,1):
            if isinstance(loc,str): loc={'name':loc}
            lid=f'{seed_key}-loc-{i:03d}'; result['locations'].append({'id':lid,'name':loc['name'],'description':loc.get('description',''),'connections':[]})
            if i>1: result['locations'][i-2]['connections'].append(lid)
            result['checkpoints'].append({'id':f'{seed_key}-cp-{i:03d}','location_id':lid,'enabled':True})
        return result
    def add_interactable(self,world,name,location_id,action):
        self._check_location(world,location_id); item={'id':f"{world['id']}-item-{len(world['interactables'])+1:03d}",'name':name,'location_id':location_id,'action':action};world['interactables'].append(item);return item
    def add_obstacle(self,world,name,location_id,kind='platform'):
        self._check_location(world,location_id); item={'id':f"{world['id']}-obstacle-{len(world['obstacles'])+1:03d}",'name':name,'location_id':location_id,'kind':kind};world['obstacles'].append(item);return item
    def add_trigger(self,world,name,location_id,event):
        self._check_location(world,location_id); item={'id':f"{world['id']}-trigger-{len(world['triggers'])+1:03d}",'name':name,'location_id':location_id,'event':event};world['triggers'].append(item);return item
    def _check_location(self,world,lid):
        if lid not in {x['id'] for x in world['locations']}: raise ValueError('location id not found')
    def validate(self,world):
        locids={x['id'] for x in world['locations']}; errors=[]
        for group in ('interactables','obstacles','checkpoints','triggers'):
            for obj in world.get(group,[]):
                if obj.get('location_id') not in locids: errors.append(f'{group}: invalid location reference')
        return {'valid':not errors,'errors':errors}
