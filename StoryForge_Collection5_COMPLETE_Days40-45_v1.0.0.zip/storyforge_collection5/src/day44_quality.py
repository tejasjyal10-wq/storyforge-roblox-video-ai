"""Day 44: quality gates, continuity checks, and retry-aware recovery."""
from copy import deepcopy
class QualityGate:
    def audit(self,project):
        errors=[]; warnings=[]
        scenes=project.get('scenes',[]); sceneids=set(); assetids=set()
        if not scenes: warnings.append('project has no scenes')
        for s in scenes:
            sid=s.get('id')
            if not sid: errors.append('scene missing id')
            elif sid in sceneids: errors.append(f'duplicate scene id: {sid}')
            sceneids.add(sid)
            for shot in s.get('shots',[]):
                if shot.get('duration_seconds',0)<=0: errors.append(f"invalid shot duration: {shot.get('id')}")
            for a in s.get('assets',[]):
                aid=a.get('id')
                if aid in assetids: warnings.append(f'duplicate asset reference: {aid}')
                assetids.add(aid)
        return {'passed':not errors,'errors':errors,'warnings':warnings,'score':max(0,100-25*len(errors)-5*len(warnings))}
class RecoveryManager:
    def recover(self,task,attempts=0,max_attempts=3,previous_output=None):
        if task.get('status')=='success': return {'action':'keep','task':deepcopy(task),'attempt':attempts}
        if attempts<max_attempts:
            updated=deepcopy(task); updated['status']='retrying'; updated['attempt']=attempts+1
            return {'action':'retry','task':updated,'attempt':attempts+1,'preserved_output':previous_output}
        updated=deepcopy(task); updated['status']='failed'; updated['error']=task.get('error','max retries exceeded')
        return {'action':'stop','task':updated,'attempt':attempts,'preserved_output':previous_output}
