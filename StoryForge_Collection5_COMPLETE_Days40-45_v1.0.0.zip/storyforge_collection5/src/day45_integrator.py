"""Day 45: collection manifest, capability audit, and end-to-end readiness report."""
from pathlib import Path
import json
COLLECTIONS=[{'id':1,'days':[1,9],'status':'checkpoint'},{'id':2,'days':[10,19],'status':'checkpoint'},{'id':3,'days':[20,29],'status':'checkpoint'},{'id':4,'days':[30,39],'status':'checkpoint'},{'id':5,'days':[40,45],'status':'in_progress'}]
EXTERNAL={'blender_runtime':'requires connected desktop Blender','roblox_studio_runtime':'requires Roblox Studio desktop','live_ai_provider':'requires provider configuration and credentials','live_tts':'requires provider configuration'}
class FinalIntegrator:
    def audit(self,project,task_results=None,capabilities=None):
        task_results=task_results or []; capabilities=capabilities or {}
        counts={s:sum(t.get('status')==s for t in task_results) for s in ('success','failed','pending','blocked')}
        unresolved=[name for name,info in EXTERNAL.items() if not capabilities.get(name,False)]
        return {'project_id':project.get('id'),'collections':COLLECTIONS,'task_counts':counts,'external_dependencies':EXTERNAL,'unverified_external':unresolved,'ready_for_release':bool(task_results) and counts['failed']==0 and counts['pending']==0 and counts['blocked']==0 and not unresolved,'notes':['Code-level checks do not replace live runtime verification.']}
    def write_report(self,report,path):
        Path(path).write_text(json.dumps(report,indent=2),encoding='utf-8');return str(path)
