import unittest
from src.day41_agent import ProductionAgent
from src.day42_film import FilmPlanner
from src.day43_world import WorldBuilder
from src.day44_quality import QualityGate, RecoveryManager
from src.day45_integrator import FinalIntegrator
class TestCollection5(unittest.TestCase):
 def test_agent_plan_and_routes(self):
  p=ProductionAgent().plan('A young explorer finds a hidden city', 'p'); self.assertEqual(len(p['tasks']),6); self.assertTrue(p['routing'])
 def test_agent_empty(self):
  with self.assertRaises(ValueError): ProductionAgent().plan('')
 def test_film_plan(self):
  planner=FilmPlanner(); p=planner.create('A door opens. A hero enters.'); self.assertEqual(len(p['scenes']),2); self.assertTrue(planner.validate(p)['valid'])
 def test_film_invalid_duration(self):
  self.assertFalse(FilmPlanner().validate({'scenes':[{'id':'s','shots':[{'duration_seconds':0}]}]})['valid'])
 def test_world_generation(self):
  w=WorldBuilder().build('Forest',['Gate','River','Fort']); self.assertEqual(len(w['locations']),3); self.assertTrue(WorldBuilder().validate(w)['valid'])
 def test_world_add_entities(self):
  b=WorldBuilder(); w=b.build('World',['Start']); lid=w['locations'][0]['id']; b.add_obstacle(w,'Wall',lid); b.add_interactable(w,'Chest',lid,'open'); b.add_trigger(w,'Switch',lid,'activate'); self.assertEqual(len(w['obstacles']),1)
 def test_world_invalid_ref(self):
  with self.assertRaises(ValueError): WorldBuilder().add_obstacle(WorldBuilder().build('W',['A']),'bad','missing')
 def test_quality_clean(self):
  self.assertTrue(QualityGate().audit({'scenes':[{'id':'s','shots':[{'duration_seconds':3}]}]})['passed'])
 def test_quality_duplicate(self):
  self.assertFalse(QualityGate().audit({'scenes':[{'id':'s'},{'id':'s'}]})['passed'])
 def test_recovery_retry_then_stop(self):
  r=RecoveryManager(); t={'status':'failed','error':'render'}; self.assertEqual(r.recover(t,0)['action'],'retry'); self.assertEqual(r.recover(t,3)['action'],'stop')
 def test_final_audit_blocks_external(self):
  r=FinalIntegrator().audit({'id':'p'},[{'status':'success'}]); self.assertFalse(r['ready_for_release']); self.assertIn('blender_runtime',r['unverified_external'])
 def test_final_report(self):
  r=FinalIntegrator().audit({'id':'p'},[]); self.assertEqual(r['collections'][-1]['id'],5)
if __name__=='__main__': unittest.main()
