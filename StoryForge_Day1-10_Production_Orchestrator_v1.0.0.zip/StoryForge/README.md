# StoryForge Roblox Video AI — Day 1 + Day 2 Integrated Package

This package combines the Node.js backend foundation with the local story/scene planning engine and a browser studio UI. It is a working planning system, not an AI video renderer. It does not connect an LLM or generate images, voice, animation, Blender scenes, or MP4s.

## Requirements
- Node.js 20 or newer
- No third-party packages required

## Run locally
1. Open the `server` folder in a terminal.
2. Run `npm test` to execute backend and frontend-helper tests.
3. Run `npm start` to launch the API (default port 3001).
4. Serve the `web` folder from a static web server. Open `studio.html` through that server (not `file://`, due to browser module restrictions). If web and API are on separate origins, set `globalThis.STORYFORGE_API_BASE` before the module script in `studio.html` to the backend URL and configure `CORS_ORIGINS` on the backend.

## API
- `GET /` welcome and links
- `GET /health` health status
- `GET /api/meta` metadata and capability disclosure
- `GET /api/status` status
- `GET /api/agent/capabilities` capability list
- `POST /api/agent/validate-request` prompt validation
- `POST /api/agent/plan` structured story/scene plan

Example plan body:
```json
{
  "prompt": "A Roblox explorer finds a hidden city above the clouds.",
  "storyOptions": {"genre":"fantasy","tone":"adventurous","protagonist":"an explorer"},
  "sceneOptions": {"sceneCount": 6, "sceneDurationSeconds": 12}
}
```
## Deployment
Set `PORT` (hosting provider usually sets it), optional `HOST`, and `CORS_ORIGINS` (comma-separated exact origin allowlist). Deploy `server/` as the Node service. Deploy `web/` as a static site, or serve it from the same origin with a hosting setup. On Replit, import this package/project and use the server's start command `npm start` from `server/` or configure the root deployment to target the server folder.
## Honest capability boundaries
Planning output is deterministic scaffold content. It uses prompt text and option values but is not LLM-authored narrative. LLM generation, image generation, character persistence, audio, animation, Blender, and video export remain unimplemented/unconnected.


## Day 3 — Character Intelligence & Memory


### Character Library
The backend now includes a persistent local character library. Profiles contain a stable UUID, name, appearance/model description, personality, story role, voice description, notes, tags, and creation/update timestamps. The library supports list, create, get, update, and delete operations and rejects blank names and duplicate names (case-insensitive).

**API endpoints**
- `GET /api/characters` — list all profiles
- `POST /api/characters` — create profile
- `GET /api/characters/:id` — retrieve profile
- `PUT /api/characters/:id` — update profile
- `DELETE /api/characters/:id` — delete profile

Characters are stored in `server/data/characters.json` by default. Set an explicit writable `characterFile` path when creating the server in a test, or ensure your host's disk is persistent before relying on the library across restarts/deploys. This storage is not a cloud database and does not yet sync across separate instances.


### Browser UI
Open `web/character-library.html` alongside the StoryForge Studio page to create, view, edit, and delete profiles. It requires the backend to be running and the pages to be hosted together (or the configured API base to be reachable).


### Day 3 test results
The automated suite includes CRUD operations, update behavior, duplicate-name validation, empty-name validation, and deletion. Run it with `npm test` from the `server` directory.

## Day 4 — World & Environment Engine (v0.4.0)

Day 4 adds a persistent world/location library and local structured generators:

- `GET/POST /api/worlds`, `GET/PUT/DELETE /api/worlds/:id`
- `POST /api/worlds/generate` — prompt-based, rule-driven world draft that saves to the library
- `GET/POST /api/worlds/:id/locations`, `PUT/DELETE /api/worlds/:id/locations/:locationId`
- `POST /api/environments/generate` — environment specification (not image or 3D rendering)
- `POST /api/interiors/generate` — template-based interior layout specification
- Story planning accepts `worldId` to include the selected saved world and reusable locations in its production plan
- `web/world-library.html` — responsive World & Environment Library UI
- World data defaults to `server/data/worlds.json`; tests use temporary files.


### Day 4 limits
World/environment/interior drafts are rule-based/template-based. They do not call an LLM, render images, create 3D geometry, or invoke Blender. Rendering and external AI providers remain future integration tasks.

### Test
Run from `server/` with Node 20 or newer: `npm test`. The test suite includes the prior backend/frontend/character tests and Day 4 world, location, persistence, environment, interior, and scene integration tests.


## Day 5 — Scene Production Breakdown

`POST /api/production/breakdown` accepts `{ "scenes": [...] , "options": { "shotCount": 5, "visualStyle": "..." } }` or a production object containing scenes. It returns per-scene production packages with shot order, framing, camera angle/movement, focus target, timing, character blocking, dialogue cue, ambience/SFX/music mood, continuity notes, and asset needs. Shot count is bounded from 3 to 8. This endpoint produces a structured plan only; it does not generate images, audio, animation, or video.

### Roblox-oriented scene planning and obstacle routes

Day 5 packages now include Roblox-compatible staging guidance by default. Each scene can receive a deterministic obstacle sequence (platform gaps, roadblocks, moving barriers, bridge crossings, climb routes, and checkpoint gates), traversal/action cues, checkpoint placement, camera suggestions, and asset requirements. This is planning data only: Roblox Studio project creation, 3D asset generation, rigging/animation playback, and publishing are not connected in this package.


To disable Roblox obstacle planning for a breakdown, pass `options.robloxEnabled: false` to `POST /api/production/breakdown`.

## Day 6 — Animation & Motion Engine (foundation)

Day 6 adds a deterministic animation action library and sequence planner.

- `GET /api/animation/library` returns supported actions and Roblox action mappings.
- `POST /api/animation/sequence` creates timed action sequences. Body: `{ "name": "Forest traversal", "characterId": "hero-1", "target": "roblox", "actions": ["run", "jump", "land", "look"] }`.
- Actions can be strings or objects such as `{ "action": "walk", "durationMs": 1500 }`.
- Supported actions: idle, walk, run, sprint, jump, land, climb, dodge, turn, look, interact, sit, wave, cheer, hurt.
- Durations must be integer milliseconds from 100 to 60000; sequence length is capped at 100 actions. Unknown actions are rejected.

This is animation planning and timing data. It does not yet play 3D animation, operate Roblox Studio, or render video.

## Day 7 — Character Motion & Behavior
- `GET /api/animation/behavior-profiles` returns supported behavior profiles.
- `POST /api/animation/behavior-plan` creates a contextual single-character behavior plan.
- `POST /api/animation/group-interaction` creates a validated multi-character interaction/turn-order plan.
- Plans are descriptive outputs; they are not rendered or executed animation.


## Day 8: Scene Interaction & Event System

Implemented scene event queue, character-object interaction plans, synchronized scene timeline validation, and a scene director planning endpoint. See `DAY8_SCENE_INTERACTION_EVENT_SYSTEM_REPORT.md`.

## Day 9 — Stateful Scene Engine & Branching Logic (v0.9.0)

Day 9 adds stateful scene planning: variables and flags, condition evaluation, state mutation operations, interactive object states, objective completion, branch resolution, and revisioned change history. APIs are listed in `DAY9_STATEFUL_SCENE_BRANCHING_REPORT.md`. Test suite: 86 passing.

## Day 10 — Production Orchestrator

Day 10 adds a dependency-aware production task runner integrated with the backend. It supports task graph validation, scheduling, retries, failure/block handling, parallel execution, progress summaries, checkpoints, restoration, JSON persistence, reports, and production event logs. The story and scene planners are now connected as sequential orchestrator tasks.


### Production Orchestrator API
- `POST /api/orchestrator/productions` with a prompt and optional story/scene options
- `GET /api/orchestrator/productions` list saved productions
- `GET /api/orchestrator/productions/:id` summary
- `POST /api/orchestrator/productions/:id/run` run workflow (optional concurrency/retry settings)
- `POST /api/orchestrator/productions/:id/checkpoint` create checkpoint
- `POST /api/orchestrator/productions/:id/restore` restore checkpoint
- `GET /api/orchestrator/productions/:id/report` report and recent events

See `DAY10_PRODUCTION_ORCHESTRATOR_REPORT.md` for implementation scope and verification.
