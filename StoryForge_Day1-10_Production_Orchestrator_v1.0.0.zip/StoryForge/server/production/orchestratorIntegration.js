import { createProduction, createCheckpoint, restoreCheckpoint, runProduction, getProductionSummary, createProductionReport } from './taskOrchestrator.js';
import { planStory } from '../planning/storyPlanner.js';
import { planScenes } from '../planning/scenePlanner.js';


export function createStoryProduction(input = {}) {
  if (typeof input.prompt !== 'string' || !input.prompt.trim()) throw new TypeError('prompt must be a non-empty string');
  const tasks = input.tasks ?? [
    { id: 'story_plan', name: 'Plan story', type: 'story-plan', maxRetries: 1, metadata: { storyOptions: input.storyOptions ?? {} } },
    { id: 'scene_plan', name: 'Plan scenes', type: 'scene-plan', dependsOn: ['story_plan'], maxRetries: 1, metadata: { sceneOptions: input.sceneOptions ?? {} } }
  ];
  return createProduction({ name: input.name || 'StoryForge Story Production', tasks, metadata: { prompt: input.prompt.trim(), storyOptions: input.storyOptions ?? {}, sceneOptions: input.sceneOptions ?? {} } });
}


export function createStoryProductionHandlers() {
  return {
    'story-plan': async (task, context) => planStory(context.production.metadata.prompt, task.metadata.storyOptions ?? {}),
    'scene-plan': async (task, context) => {
      const storyTask = context.production.tasks.find(t => t.id === 'story_plan');
      if (!storyTask?.result) throw new Error('story-plan task result is missing');
      return planScenes(storyTask.result, task.metadata.sceneOptions ?? {});
    }
  };
}
export async function executeStoryProduction(production, options = {}) {
  return runProduction(production, createStoryProductionHandlers(), options);
}
export { createCheckpoint, restoreCheckpoint, getProductionSummary, createProductionReport };
