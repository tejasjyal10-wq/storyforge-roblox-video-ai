import test from 'node:test';
import { mkdtemp, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import assert from 'node:assert/strict';
import { createStoryProduction, executeStoryProduction, getProductionSummary, createProductionReport, createCheckpoint, restoreCheckpoint } from './orchestratorIntegration.js';
import { createServer } from '../server.js';


test('Day 10 builds a story production with dependent story and scene tasks', () => {
  const p = createStoryProduction({ prompt: 'A young explorer finds a lost city.' });
  assert.equal(p.tasks.length, 2);
  assert.deepEqual(p.tasks[1].dependsOn, ['story_plan']);
  assert.equal(p.status, 'queued');
});

test('Day 10 integrated workflow executes story planning then scene planning', async () => {
  const p = createStoryProduction({ prompt: 'A young explorer finds a lost city.', sceneOptions: { sceneCount: 4 } });
  await executeStoryProduction(p);
  assert.equal(p.status, 'completed');
  assert.equal(p.tasks[0].status, 'completed');
  assert.equal(p.tasks[1].status, 'completed');
  assert.equal(p.tasks[0].result.title, 'A young explorer finds a lost city');
  assert.equal(p.tasks[1].result.length, 4);
  assert.equal(getProductionSummary(p).progressPercent, 100);
});

test('Day 10 rejects blank prompt and preserves dependency validation', () => {
  assert.throws(() => createStoryProduction({ prompt: '   ' }), /prompt/);
  assert.throws(() => createStoryProduction({ prompt: 'ok', tasks: [{ id: 'a', name: 'A', dependsOn: ['missing'] }] }), /missing dependency/);
});

test('Day 10 checkpoint and restore recover production state', async () => {
  const p = createStoryProduction({ prompt: 'Test story' });
  const cp = createCheckpoint(p, 'before-run');
  await executeStoryProduction(p);
  const restored = restoreCheckpoint(p, cp.id);
  assert.equal(restored.tasks[0].status, 'pending');
  assert.equal(restored.status, 'queued');
  assert.ok(restored.checkpoints.some(c => c.id === cp.id), 'checkpoint remains available after restore');
});

test('Day 10 report summarizes task results and production events', async () => {
  const p = createStoryProduction({ prompt: 'Test report story' });
  await executeStoryProduction(p);
  const report = createProductionReport(p);
  assert.equal(report.production.completed, 2);
  assert.ok(report.recentEvents.some(e => e.type === 'production_finished'));
});

test('Day 10 HTTP API creates, runs, checkpoints, reports, and lists productions', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'sf-day10-api-'));
  const server = createServer({ port: 0, host: '127.0.0.1', productionDirectory: dir });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const createdRes = await fetch(`${base}/api/orchestrator/productions`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'A robot learns gardening.', sceneOptions: { sceneCount: 3 } }) });
    assert.equal(createdRes.status, 201);
    const created = await createdRes.json(); const id = created.production.id;
    const runRes = await fetch(`${base}/api/orchestrator/productions/${id}/run`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
    assert.equal(runRes.status, 200); assert.equal((await runRes.json()).summary.status, 'completed');
    const cpRes = await fetch(`${base}/api/orchestrator/productions/${id}/checkpoint`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ label: 'post-run' }) });
    assert.equal(cpRes.status, 201);
    const reportRes = await fetch(`${base}/api/orchestrator/productions/${id}/report`); assert.equal(reportRes.status, 200); assert.equal((await reportRes.json()).report.production.completed, 2);
    const listRes = await fetch(`${base}/api/orchestrator/productions`); assert.equal(listRes.status, 200); assert.equal((await listRes.json()).productions.length, 1);
  } finally { await new Promise(resolve => server.close(resolve)); await rm(dir, { recursive: true, force: true }); }
});


test('Day 10 productions persist and can be loaded by a fresh server instance', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'sf-day10-restart-'));
  let server = createServer({ port: 0, host: '127.0.0.1', productionDirectory: dir });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  let id;
  try {
    const res = await fetch(`${base}/api/orchestrator/productions`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'A curious fox explores a library.' }) });
    assert.equal(res.status, 201); id = (await res.json()).production.id;
  } finally { await new Promise(resolve => server.close(resolve)); }
  server = createServer({ port: 0, host: '127.0.0.1', productionDirectory: dir });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base2 = `http://127.0.0.1:${server.address().port}`;
  try {
    const list = await fetch(`${base2}/api/orchestrator/productions`);
    assert.equal(list.status, 200); assert.equal((await list.json()).productions.length, 1);
    const loaded = await fetch(`${base2}/api/orchestrator/productions/${id}`);
    assert.equal(loaded.status, 200); assert.equal((await loaded.json()).production.status, 'queued');
  } finally { await new Promise(resolve => server.close(resolve)); await rm(dir, { recursive: true, force: true }); }
});
