import { randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';


const STATES = new Set(['pending', 'running', 'completed', 'failed', 'skipped']);
const TERMINAL = new Set(['completed', 'failed', 'skipped']);


function clone(value) { return structuredClone(value); }
function now() { return new Date().toISOString(); }
function assertText(value, label) {
  if (typeof value !== 'string' || !value.trim()) throw new TypeError(`${label} must be a non-empty string`);
}


export function createTask(input = {}) {
  assertText(input.name, 'task.name');
  if (input.dependsOn !== undefined && !Array.isArray(input.dependsOn)) throw new TypeError('dependsOn must be an array');
  const maxRetries = input.maxRetries ?? 0;
  if (!Number.isInteger(maxRetries) || maxRetries < 0 || maxRetries > 10) throw new RangeError('maxRetries must be an integer from 0 to 10');
  return {
    id: input.id ?? `task_${randomUUID()}`,
    name: input.name.trim(),
    type: input.type ?? 'generic',
    dependsOn: [...(input.dependsOn ?? [])],
    maxRetries,
    retryCount: 0,
    status: 'pending',
    createdAt: now(),
    startedAt: null,
    finishedAt: null,
    lastError: null,
    result: null,
    metadata: clone(input.metadata ?? {})
  };
}


export function validateTaskGraph(tasks) {
  if (!Array.isArray(tasks) || tasks.length === 0) throw new TypeError('tasks must be a non-empty array');
  const ids = new Set();
  for (const task of tasks) {
    assertText(task.id, 'task.id');
    if (ids.has(task.id)) throw new Error(`duplicate task id: ${task.id}`);
    ids.add(task.id);
    if (!STATES.has(task.status)) throw new Error(`invalid status for task ${task.id}`);
  }
  for (const task of tasks) {
    for (const dependency of task.dependsOn ?? []) {
      if (!ids.has(dependency)) throw new Error(`task ${task.id} references missing dependency ${dependency}`);
      if (dependency === task.id) throw new Error(`task ${task.id} cannot depend on itself`);
    }
  }
  // Cycle detection (DFS)
  const map = new Map(tasks.map(t => [t.id, t]));
  const visiting = new Set(); const visited = new Set();
  const visit = (id) => {
    if (visiting.has(id)) throw new Error(`dependency cycle detected at ${id}`);
    if (visited.has(id)) return;
    visiting.add(id);
    for (const dep of map.get(id).dependsOn ?? []) visit(dep);
    visiting.delete(id); visited.add(id);
  };
  for (const id of ids) visit(id);
  return true;
}


export function createProduction(input = {}) {
  const tasks = (input.tasks ?? []).map(t => createTask(t));
  if (tasks.length) validateTaskGraph(tasks);
  return {
    id: input.id ?? `production_${randomUUID()}`,
    name: input.name ?? 'StoryForge Production',
    status: tasks.length ? 'queued' : 'draft',
    createdAt: now(),
    updatedAt: now(),
    startedAt: null,
    finishedAt: null,
    tasks,
    checkpoints: [],
    eventLog: [{ at: now(), type: 'production_created', detail: { taskCount: tasks.length } }],
    metadata: clone(input.metadata ?? {})
  };
}


export function getReadyTasks(production) {
  const tasksById = new Map(production.tasks.map(t => [t.id, t]));
  return production.tasks.filter(task => task.status === 'pending' && task.dependsOn.every(id => tasksById.get(id)?.status === 'completed'));
}


export function getProductionSummary(production) {
  const counts = Object.fromEntries([...STATES].map(state => [state, production.tasks.filter(t => t.status === state).length]));
  const total = production.tasks.length;
  const done = counts.completed + counts.failed + counts.skipped;
  return { id: production.id, name: production.name, status: production.status, totalTasks: total, ...counts, progressPercent: total ? Math.round((counts.completed / total) * 100) : 0, settledPercent: total ? Math.round((done / total) * 100) : 0, updatedAt: production.updatedAt };
}


export function createCheckpoint(production, label = 'checkpoint') {
  const checkpoint = { id: `checkpoint_${randomUUID()}`, label, createdAt: now(), snapshot: clone(production) };
  production.checkpoints.push(checkpoint);
  production.updatedAt = now();;
  production.eventLog.push({ at: now(), type: 'checkpoint_created', detail: { checkpointId: checkpoint.id, label } });
  return checkpoint;
}


export function restoreCheckpoint(production, checkpointId) {
  const checkpoint = production.checkpoints.find(c => c.id === checkpointId);
  if (!checkpoint) throw new Error(`checkpoint not found: ${checkpointId}`);
  const restored = clone(checkpoint.snapshot);
  restored.checkpoints = clone(production.checkpoints);
  restored.eventLog.push({ at: now(), type: 'checkpoint_restored', detail: { checkpointId } });
  restored.updatedAt = now();
  return restored;
}


export async function saveProduction(production, filePath) {
  const target = resolve(filePath);
  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, JSON.stringify(production, null, 2), 'utf8');
  return target;
}
export async function loadProduction(filePath) {
  const production = JSON.parse(await readFile(resolve(filePath), 'utf8'));
  if (production.tasks?.length) validateTaskGraph(production.tasks);
  return production;
}


export async function runProduction(production, handlers = {}, options = {}) {
  const concurrency = options.concurrency ?? 1;
  if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 32) throw new RangeError('concurrency must be an integer from 1 to 32');
  if (production.status === 'completed') return production;
  if (production.tasks.length === 0) throw new Error('production has no tasks');
  validateTaskGraph(production.tasks);
  production.status = 'running'; production.startedAt ??= now(); production.updatedAt = now();
  production.eventLog.push({ at: now(), type: 'production_started', detail: { concurrency } });
  const taskMap = new Map(production.tasks.map(t => [t.id, t]));
  let fatalStop = false;
  const executeTask = async (task) => {
    task.status = 'running'; task.startedAt ??= now(); task.lastError = null;
    production.eventLog.push({ at: now(), type: 'task_started', detail: { taskId: task.id } });
    const handler = handlers[task.type] ?? handlers.default;
    try {
      if (!handler) throw new Error(`no handler registered for task type: ${task.type}`);
      const result = await handler(clone(task), { production: clone(production), attempt: task.retryCount + 1 });
      task.result = result ?? null; task.status = 'completed'; task.finishedAt = now();
      production.eventLog.push({ at: now(), type: 'task_completed', detail: { taskId: task.id } });
    } catch (error) {
      task.lastError = { message: error?.message ?? String(error), at: now() };
      if (task.retryCount < task.maxRetries && options.retryFailed !== false) {
        task.retryCount += 1; task.status = 'pending'; task.startedAt = null;
        production.eventLog.push({ at: now(), type: 'task_retry_scheduled', detail: { taskId: task.id, retry: task.retryCount, error: task.lastError.message } });
      } else {
        task.status = 'failed'; task.finishedAt = now();
        production.eventLog.push({ at: now(), type: 'task_failed', detail: { taskId: task.id, error: task.lastError.message } });
        if (options.stopOnFailure) fatalStop = true;
      }
    }
    production.updatedAt = now();
  };
  while (production.tasks.some(t => !TERMINAL.has(t.status))) {
    if (fatalStop) {
      for (const task of production.tasks) if (task.status === 'pending') task.status = 'skipped';
      break;
    }
    const ready = getReadyTasks(production);
    if (!ready.length) {
      const pending = production.tasks.filter(t => t.status === 'pending');
      if (pending.length) {
        for (const task of pending) {
          const blockedBy = task.dependsOn.filter(id => taskMap.get(id)?.status !== 'completed');
          task.status = 'skipped'; task.finishedAt = now();
          task.lastError = { message: `blocked by unsuccessful dependencies: ${blockedBy.join(', ')}`, at: now() };
        }
      }
      break;
    }
    for (let i = 0; i < ready.length; i += concurrency) {
      await Promise.all(ready.slice(i, i + concurrency).map(executeTask));
    }
  }
  const summary = getProductionSummary(production);
  production.status = summary.failed ? 'failed' : summary.skipped ? 'partial' : 'completed';
  production.finishedAt = now(); production.updatedAt = now();
  production.eventLog.push({ at: now(), type: 'production_finished', detail: { status: production.status, summary } });
  return production;
}


export function createProductionReport(production) {
  const summary = getProductionSummary(production);
  return { generatedAt: now(), production: summary, tasks: production.tasks.map(t => ({ id: t.id, name: t.name, type: t.type, status: t.status, retryCount: t.retryCount, error: t.lastError, result: t.result })), checkpoints: production.checkpoints.map(c => ({ id: c.id, label: c.label, createdAt: c.createdAt })), recentEvents: production.eventLog.slice(-30) };
}
