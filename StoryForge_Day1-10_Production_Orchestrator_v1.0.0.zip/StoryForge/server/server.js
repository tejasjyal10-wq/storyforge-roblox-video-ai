import http from 'node:http';
import { mkdir, readdir } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { URL } from 'node:url';
import { pathToFileURL } from 'node:url';
import { createAgentOrchestrator } from './agents/orchestrator.js';
import { createCharacterStore } from './characters/characterStore.js';
import { createWorldStore } from './worlds/worldStore.js';
import { generateWorld, generateEnvironment, generateInterior, WORLD_ENVIRONMENT_TYPES } from './worlds/worldGenerator.js';
import { createProductionBreakdown } from './production/sceneBreakdown.js';
import { getAnimationLibrary, buildAnimationSequence } from './animation/animationEngine.js';
import { getMotionBehaviorProfiles, createMotionBehaviorPlan, createGroupInteractionPlan } from './animation/motionBehavior.js';
import { getSceneInteractionCatalog, buildEventQueue, createInteractionPlan, createSceneTimeline, createSceneDirectorPlan } from './scene/sceneInteraction.js';
import { createSceneState, evaluateCondition, applySceneUpdate, defineSceneObject, updateSceneObject, resolveSceneBranch, completeSceneObjective, getSceneStateCatalog } from './scene/sceneState.js';
import { createStoryProduction, executeStoryProduction, createCheckpoint, restoreCheckpoint, getProductionSummary, createProductionReport } from './production/orchestratorIntegration.js';
import { saveProduction, loadProduction } from './production/taskOrchestrator.js';

const VERSION = '1.0.0';
const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || '0.0.0.0';
const allowedOrigins = new Set((process.env.CORS_ORIGINS || 'http://localhost:3000,http://127.0.0.1:3000,http://localhost:5173,http://127.0.0.1:5173').split(',').map(s => s.trim()).filter(Boolean));
const MAX_BODY_BYTES = 16 * 1024;


export function createServer({ port = PORT, host = HOST, corsOrigins = allowedOrigins, characterFile, worldFile, productionDirectory = process.env.STORYFORGE_PRODUCTION_DIR || join(dirname(fileURLToPath(import.meta.url)), 'data', 'productions') } = {}) {
  const startedAt = Date.now();
  const orchestrator = createAgentOrchestrator();
  const characters = createCharacterStore(characterFile ? { filePath: characterFile } : {});
  const worlds = createWorldStore(worldFile ? { filePath: worldFile } : {});
  const routes = new Map();
  const managedProductions = new Map();
  const productionPath = (id) => join(productionDirectory, `${id}.json`);
  async function persistProduction(p) { await saveProduction(p, productionPath(p.id)); }
  async function loadManagedProduction(id) { if (managedProductions.has(id)) return managedProductions.get(id); try { const p = await loadProduction(productionPath(id)); managedProductions.set(id, p); return p; } catch { return null; } }
  async function loadAllProductions() { await mkdir(productionDirectory, { recursive: true }); for (const name of await readdir(productionDirectory)) { if (!name.endsWith('.json')) continue; const id = name.slice(0, -5); try { const p = await loadProduction(productionPath(id)); managedProductions.set(p.id, p); } catch { /* ignore corrupt files in listing; individual load reports errors */ } } }
  function route(method, path, handler) { routes.set(`${method} ${path}`, handler); }
  function json(res, status, body) {
    const payload = JSON.stringify(body);
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'content-length': Buffer.byteLength(payload),
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
    });
    res.end(payload);
  }
  async function readJson(req) {
    let body = '';
    for await (const chunk of req) {
      body += chunk;
      if (Buffer.byteLength(body) > MAX_BODY_BYTES) throw Object.assign(new Error('Request body too large.'), { status: 413 });
    }
    if (!body) return {};
    try { return JSON.parse(body); }
    catch { throw Object.assign(new Error('Request body must be valid JSON.'), { status: 400 }); }
  }
  route('GET', '/', (_req, res) => json(res, 200, { message: 'StoryForge backend is running.', links: ['/health', '/api/meta', '/api/status'] }));
  route('POST', '/api/orchestrator/productions', async (req, res) => { const data = await readJson(req); try { const production = createStoryProduction(data); managedProductions.set(production.id, production); await persistProduction(production); return json(res, 201, { production, summary: getProductionSummary(production) }); } catch (error) { return json(res, 400, { error: 'invalid_production', message: error.message }); } });
  route('GET', '/api/orchestrator/productions', async (_req, res) => { await loadAllProductions(); return json(res, 200, { productions: [...managedProductions.values()].map(getProductionSummary) }); });
  route('GET', '/health', (_req, res) => json(res, 200, { status: 'ok', service: 'storyforge-agent-core', version: VERSION, uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000), timestamp: new Date().toISOString() }));
  route('GET', '/api/meta', (_req, res) => json(res, 200, { name: 'StoryForge Story and Video AI', version: VERSION, phase: 'day-10-production-orchestrator', capabilities: ['health-check', 'metadata', 'frontend-connection', 'request-validation', 'local-story-planning', 'scene-planning', 'production-plan', 'persistent-character-library', 'world-library', 'location-library', 'rule-based-world-drafting', 'environment-specification', 'interior-planning', 'scene-shot-breakdown', 'camera-and-audio-cue-planning', 'scene-production-packages', 'expanded-animation-catalog', 'animation-sequence-builder', 'animation-overlays', 'blend-timing', 'roblox-action-mapping', 'motion-behavior-profiles', 'contextual-character-reactions', 'dialogue-gesture-coordination', 'multi-character-interaction-plans', 'roblox-obstacle-behavior-planning', 'scene-event-queue', 'environment-interaction-plans', 'scene-timeline-synchronization', 'scene-director-planning', 'scene-state-tracking', 'condition-evaluation', 'branching-story-resolution', 'interactive-object-state', 'objective-tracking', 'production-orchestration', 'task-dependency-scheduling', 'retry-and-recovery', 'checkpointing', 'production-reporting'], notYetImplemented: ['llm-powered-story-generation', 'image-generation', '3d-environment-rendering', 'blender-integration', 'video-rendering'] }));
  route('GET', '/api/status', (_req, res) => json(res, 200, { backend: 'online', day1Foundation: 'ready', day10Orchestrator: 'integrated', aiGeneration: 'not-connected', blender: 'not-connected', videoExport: 'not-connected', uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000) }));
  route('GET', '/api/agent/capabilities', (_req, res) => json(res, 200, {
    agent: orchestrator.name, version: orchestrator.version,
    implemented: ['prompt-validation', 'local-story-structure', 'scene-outline-planning', 'production-plan-assembly', 'persistent-character-library', 'persistent-world-library', 'persistent-location-library', 'rule-based-world-drafting', 'environment-specification', 'interior-planning', 'scene-shot-breakdown', 'camera-and-audio-cue-planning', 'scene-production-packages', 'expanded-animation-catalog', 'animation-sequence-builder', 'animation-overlays', 'blend-timing', 'roblox-action-mapping', 'motion-behavior-profiles', 'contextual-character-reactions', 'dialogue-gesture-coordination', 'multi-character-interaction-plans', 'roblox-obstacle-behavior-planning', 'scene-event-queue', 'environment-interaction-plans', 'scene-timeline-synchronization', 'scene-director-planning', 'scene-state-tracking', 'condition-evaluation', 'branching-story-resolution', 'interactive-object-state', 'objective-tracking'],
    notConnected: ['llm-provider', 'image-generation', '3d-environment-rendering', 'voice-generation', 'animation-rendering', 'blender', 'mp4-export']
  }));
  route('GET', '/api/worlds', async (_req, res) => json(res, 200, { worlds: await worlds.list() }));
  route('POST', '/api/worlds', async (req, res) => { const data = await readJson(req); const world = await worlds.create(data); return json(res, 201, { world }); });
  route('POST', '/api/worlds/generate', async (req, res) => { const data = await readJson(req); const draft = generateWorld(data); const world = await worlds.create(draft); return json(res, 201, { world, generation: draft.generation }); });
  route('POST', '/api/environments/generate', async (req, res) => json(res, 201, { environment: generateEnvironment(await readJson(req)), supportedTypes: WORLD_ENVIRONMENT_TYPES }));
  route('POST', '/api/interiors/generate', async (req, res) => json(res, 201, { interior: generateInterior(await readJson(req)) }));
  route('GET', '/api/worlds/:id', async (_req, res, id) => { const world = await worlds.get(id); return json(res, world ? 200 : 404, world ? { world } : { error: 'not_found', message: 'World not found.' }); });
  route('PUT', '/api/worlds/:id', async (req, res, id) => { const world = await worlds.update(id, await readJson(req)); return json(res, world ? 200 : 404, world ? { world } : { error: 'not_found', message: 'World not found.' }); });
  route('DELETE', '/api/worlds/:id', async (_req, res, id) => { const deleted = await worlds.delete(id); return json(res, deleted ? 200 : 404, deleted ? { deleted: true, id } : { error: 'not_found', message: 'World not found.' }); });
  route('GET', '/api/characters', async (_req, res) => json(res, 200, { characters: await characters.list() }));
  route('POST', '/api/characters', async (req, res) => {
    const data = await readJson(req);
    const character = await characters.create(data);
    return json(res, 201, { character });
  });
  route('POST', '/api/production/breakdown', async (req, res) => { const data = await readJson(req); try { const breakdown = createProductionBreakdown(data); return json(res, 201, breakdown); } catch (error) { return json(res, 400, { error: 'invalid_scene_data', message: error.message }); } });
  route('GET', '/api/animation/library', (_req, res) => json(res, 200, { animations: getAnimationLibrary(), count: getAnimationLibrary().length }));
  route('POST', '/api/animation/sequence', async (req, res) => { const data = await readJson(req); try { return json(res, 201, { sequence: buildAnimationSequence(data) }); } catch (error) { return json(res, 400, { error: 'invalid_animation_sequence', message: error.message }); } });
  route('GET', '/api/animation/behavior-profiles', (_req, res) => json(res, 200, { profiles: getMotionBehaviorProfiles(), count: getMotionBehaviorProfiles().length }));
  route('POST', '/api/animation/behavior-plan', async (req, res) => { const data = await readJson(req); try { return json(res, 201, { plan: createMotionBehaviorPlan(data) }); } catch (error) { return json(res, 400, { error: 'invalid_behavior_plan', message: error.message }); } });
  route('POST', '/api/animation/group-interaction', async (req, res) => { const data = await readJson(req); try { return json(res, 201, { plan: createGroupInteractionPlan(data) }); } catch (error) { return json(res, 400, { error: 'invalid_group_interaction', message: error.message }); } });
  route('GET', '/api/scene/interaction-catalog', (_req, res) => json(res, 200, getSceneInteractionCatalog()));
  route('POST', '/api/scene/events', async (req, res) => { const data = await readJson(req); try { return json(res, 201, buildEventQueue(data.events)); } catch (error) { return json(res, 400, { error: 'invalid_event_queue', message: error.message }); } });
  route('POST', '/api/scene/interaction-plan', async (req, res) => { const data = await readJson(req); try { return json(res, 201, { plan: createInteractionPlan(data) }); } catch (error) { return json(res, 400, { error: 'invalid_interaction', message: error.message }); } });
  route('POST', '/api/scene/timeline', async (req, res) => { const data = await readJson(req); try { return json(res, 201, createSceneTimeline(data)); } catch (error) { return json(res, 400, { error: 'invalid_timeline', message: error.message }); } });
  route('POST', '/api/scene/director-plan', async (req, res) => { const data = await readJson(req); try { return json(res, 201, { plan: createSceneDirectorPlan(data) }); } catch (error) { return json(res, 400, { error: 'invalid_director_plan', message: error.message }); } });
  route('GET', '/api/scene/state-catalog', (_req, res) => json(res, 200, getSceneStateCatalog()));
  route('POST', '/api/scene/state/create', async (req, res) => { const data = await readJson(req); try { return json(res, 201, { state: createSceneState(data) }); } catch (error) { return json(res, 400, { error: 'invalid_scene_state', message: error.message }); } });
  route('POST', '/api/scene/state/condition', async (req, res) => { const data = await readJson(req); try { return json(res, 200, { result: evaluateCondition(data.condition, data.state) }); } catch (error) { return json(res, 400, { error: 'invalid_condition', message: error.message }); } });
  route('POST', '/api/scene/state/update', async (req, res) => { const data = await readJson(req); try { return json(res, 200, { state: applySceneUpdate(data.state, data.update) }); } catch (error) { return json(res, 400, { error: 'invalid_state_update', message: error.message }); } });
  route('POST', '/api/scene/state/object/define', async (req, res) => { const data = await readJson(req); try { const state = data.state; const object = defineSceneObject(state, data.object); return json(res, 201, { state, object }); } catch (error) { return json(res, 400, { error: 'invalid_scene_object', message: error.message }); } });
  route('POST', '/api/scene/state/object/update', async (req, res) => { const data = await readJson(req); try { return json(res, 200, { object: updateSceneObject(data.state, data.update) }); } catch (error) { return json(res, 400, { error: 'invalid_scene_object_update', message: error.message }); } });
  route('POST', '/api/scene/branch/resolve', async (req, res) => { const data = await readJson(req); try { return json(res, 200, { branch: resolveSceneBranch(data.state, data.branches) }); } catch (error) { return json(res, 400, { error: 'invalid_branch_resolution', message: error.message }); } });
  route('POST', '/api/scene/objective/complete', async (req, res) => { const data = await readJson(req); try { return json(res, 200, { state: data.state, objective: completeSceneObjective(data.state, data.objectiveId, data.details) }); } catch (error) { return json(res, 400, { error: 'invalid_objective', message: error.message }); } });
  route('POST', '/api/agent/plan', async (req, res) => {
    const data = await readJson(req);
    if (typeof data.prompt !== 'string' || !data.prompt.trim()) return json(res, 400, { error: 'invalid_prompt', message: 'prompt must be a non-empty string.' });
    if (data.prompt.length > 4000) return json(res, 400, { error: 'prompt_too_long', message: 'prompt must be 4000 characters or fewer.' });
    const production = await orchestrator.createPlan(data);
    if (data.worldId) { const world = await worlds.get(String(data.worldId)); if (!world) return json(res, 404, { error: 'world_not_found', message: 'Selected world not found.' }); production.worldContext = { id: world.id, name: world.name, worldType: world.worldType, artStyle: world.artStyle, palette: world.palette, locations: world.locations }; production.scenes = production.scenes.map((scene, index) => ({ ...scene, worldId: world.id, environment: world.locations[index % Math.max(world.locations.length, 1)] || { environmentType: 'custom', description: 'Scene environment to be specified.' } })); }
    return json(res, 201, production);
  });
  route('POST', '/api/agent/validate-request', async (req, res) => {
    const data = await readJson(req);
    if (typeof data.prompt !== 'string' || !data.prompt.trim()) return json(res, 400, { error: 'invalid_prompt', message: 'prompt must be a non-empty string.' });
    if (data.prompt.length > 4000) return json(res, 400, { error: 'prompt_too_long', message: 'prompt must be 4000 characters or fewer.' });
    json(res, 200, { valid: true, promptLength: data.prompt.trim().length, message: 'Request is valid. AI generation is not connected in Day 1.' });
  });

  const server = http.createServer(async (req, res) => {
    const origin = req.headers.origin;
    if (origin && corsOrigins.has(origin)) {
      res.setHeader('access-control-allow-origin', origin);
      res.setHeader('vary', 'Origin');
    }
    res.setHeader('access-control-allow-methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('access-control-allow-headers', 'Content-Type');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const worldLocationsMatch = url.pathname.match(/^\/api\/worlds\/([^/]+)\/locations$/);
    const worldLocationMatch = url.pathname.match(/^\/api\/worlds\/([^/]+)\/locations\/([^/]+)$/);
    const worldMatch = url.pathname.match(/^\/api\/worlds\/([^/]+)$/);
    if (worldLocationsMatch && ['GET','POST'].includes(req.method)) { const id=decodeURIComponent(worldLocationsMatch[1]); try { if(req.method==='GET'){const list=await worlds.listLocations(id);return json(res,list?200:404,list?{locations:list}:{error:'not_found',message:'World not found.'});} const location=await worlds.createLocation(id,await readJson(req));return json(res,location?201:404,location?{location}:{error:'not_found',message:'World not found.'}); } catch(error){return json(res,error.status||500,{error:error.status?'request_error':'internal_error',message:error.status?error.message:'Unexpected server error.'});} }
    if (worldLocationMatch && ['PUT','DELETE'].includes(req.method)) { const wid=decodeURIComponent(worldLocationMatch[1]),lid=decodeURIComponent(worldLocationMatch[2]); try { if(req.method==='PUT'){const location=await worlds.updateLocation(wid,lid,await readJson(req));return json(res,location===null?404:location===false?404:200,location?{location}:{error:'not_found',message:'World or location not found.'});} const deleted=await worlds.deleteLocation(wid,lid);return json(res,deleted===null||deleted===false?404:200,deleted?{deleted:true,id:lid}:{error:'not_found',message:'World or location not found.'}); }catch(error){return json(res,error.status||500,{error:error.status?'request_error':'internal_error',message:error.status?error.message:'Unexpected server error.'});} }
    if (worldMatch && ['GET','PUT','DELETE'].includes(req.method)) { const id=decodeURIComponent(worldMatch[1]); try { if(req.method==='GET'){const world=await worlds.get(id);return json(res,world?200:404,world?{world}:{error:'not_found',message:'World not found.'});} if(req.method==='PUT'){const world=await worlds.update(id,await readJson(req));return json(res,world?200:404,world?{world}:{error:'not_found',message:'World not found.'});} const deleted=await worlds.delete(id);return json(res,deleted?200:404,deleted?{deleted:true,id}:{error:'not_found',message:'World not found.'});}catch(error){return json(res,error.status||500,{error:error.status?'request_error':'internal_error',message:error.status?error.message:'Unexpected server error.'});} }
    const orchestratorMatch = url.pathname.match(/^\/api\/orchestrator\/productions\/([^/]+)(?:\/(run|checkpoint|restore|report))?$/);
    if (orchestratorMatch && ['GET','POST'].includes(req.method)) {
      const id = decodeURIComponent(orchestratorMatch[1]), action = orchestratorMatch[2] || 'summary', production = await loadManagedProduction(id);
      if (!production) return json(res, 404, { error: 'not_found', message: 'Production not found.' });
      try {
        if (req.method === 'GET' && action === 'summary') return json(res, 200, { production: getProductionSummary(production) });
        if (req.method === 'GET' && action === 'report') return json(res, 200, { report: createProductionReport(production) });
        if (req.method === 'POST' && action === 'run') { const options = await readJson(req); await executeStoryProduction(production, options); await persistProduction(production); return json(res, 200, { production, summary: getProductionSummary(production) }); }
        if (req.method === 'POST' && action === 'checkpoint') { const data = await readJson(req); const checkpoint = createCheckpoint(production, data.label || 'manual'); await persistProduction(production); return json(res, 201, { checkpoint: { id: checkpoint.id, label: checkpoint.label, createdAt: checkpoint.createdAt }, summary: getProductionSummary(production) }); }
        if (req.method === 'POST' && action === 'restore') { const data = await readJson(req); const restored = restoreCheckpoint(production, data.checkpointId); managedProductions.set(id, restored); await persistProduction(restored); return json(res, 200, { production: restored, summary: getProductionSummary(restored) }); }
        return json(res, 405, { error: 'method_not_allowed', message: 'Method/action not supported.' });
      } catch (error) { return json(res, 400, { error: 'orchestrator_error', message: error.message }); }
    }
    const characterMatch = url.pathname.match(/^\/api\/characters\/([^/]+)$/);
    if (characterMatch && ['GET', 'PUT', 'DELETE'].includes(req.method)) {
      const id = decodeURIComponent(characterMatch[1]);
      try {
        if (req.method === 'GET') {
          const character = await characters.get(id);
          return json(res, character ? 200 : 404, character ? { character } : { error: 'not_found', message: 'Character not found.' });
        }
        if (req.method === 'PUT') {
          const updated = await characters.update(id, await readJson(req));
          return json(res, updated ? 200 : 404, updated ? { character: updated } : { error: 'not_found', message: 'Character not found.' });
        }
        const deleted = await characters.delete(id);
        return json(res, deleted ? 200 : 404, deleted ? { deleted: true, id } : { error: 'not_found', message: 'Character not found.' });
      } catch (error) { return json(res, error.status || 500, { error: error.status ? 'request_error' : 'internal_error', message: error.status ? error.message : 'Unexpected server error.' }); }
    }
    const handler = routes.get(`${req.method} ${url.pathname}`);
    if (handler) {
      try { return await handler(req, res); }
      catch (error) { return json(res, error.status || 500, { error: error.status ? 'request_error' : 'internal_error', message: error.status ? error.message : 'Unexpected server error.' }); }
    }
    json(res, 404, { error: 'not_found', message: 'No route matches this request.' });
  });
  server.on('clientError', (_error, socket) => socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r'));
  return server;
}


const isDirectRun = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isDirectRun) {
  const server = createServer();
  server.listen(PORT, HOST, () => console.log(`StoryForge backend listening on ${HOST}:${PORT}`));
  const shutdown = () => server.close(() => process.exit(0));
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
