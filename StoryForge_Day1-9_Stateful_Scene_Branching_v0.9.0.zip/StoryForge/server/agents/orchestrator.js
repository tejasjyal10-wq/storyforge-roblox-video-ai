import { planStory } from '../planning/storyPlanner.js';
import { planScenes } from '../planning/scenePlanner.js';
import { createProduction } from '../pipeline/productionPipeline.js';

export function createAgentOrchestrator() {
  return {
    name: 'StoryForge Agent Orchestrator',
    version: '0.2.0',
    async createPlan(input = {}) {
      const prompt = input.prompt;
      const story = planStory(prompt, input.storyOptions || {});
      const scenes = planScenes(story, input.sceneOptions || {});
      return createProduction({ story, scenes });
    }
  };
}
