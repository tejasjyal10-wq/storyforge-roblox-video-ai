import test from 'node:test';
import assert from 'node:assert/strict';
import { getAnimationLibrary, buildAnimationSequence } from './animationEngine.js';

test('animation library exposes movement and Roblox mappings', () => {
  const library = getAnimationLibrary();
  assert.ok(library.some(item => item.id === 'jump' && item.roblox === 'Jump'));
  assert.ok(library.some(item => item.id === 'climb'));
  assert.ok(library.length >= 12);
});

test('sequence timing is cumulative and action order preserved', () => {
  const sequence = buildAnimationSequence({ actions: ['run', 'jump', 'land', 'look'], target: 'roblox' });
  assert.equal(sequence.stepCount, 4);
  assert.deepEqual(sequence.steps.map(step => step.action), ['run', 'jump', 'land', 'look']);
  assert.equal(sequence.steps[0].startMs, 0);
  assert.equal(sequence.steps[1].startMs, sequence.steps[0].endMs);
  assert.equal(sequence.totalDurationMs, sequence.steps.at(-1).endMs);
  assert.equal(sequence.target, 'roblox');
});

test('custom action duration and character id are honored', () => {
  const sequence = buildAnimationSequence({ characterId: 'char-7', actions: [{ action: 'walk', durationMs: 1500 }, 'turn' ] });
  assert.equal(sequence.characterId, 'char-7');
  assert.equal(sequence.steps[0].durationMs, 1500);
  assert.equal(sequence.steps[1].startMs, 1500);
});

test('invalid and oversized sequences are rejected', () => {
  assert.throws(() => buildAnimationSequence({ actions: [] }), /non-empty array/);
  assert.throws(() => buildAnimationSequence({ actions: ['teleport'] }), /Unknown action/);
  assert.throws(() => buildAnimationSequence({ actions: [{ action: 'walk', durationMs: 99 }] }), /durationMs/);
  assert.throws(() => buildAnimationSequence({ actions: Array(101).fill('idle') }), /at most 100/);
});


test('expanded catalog covers social, emotion, interaction, cinematic, and Roblox actions', () => {
  const ids = new Set(getAnimationLibrary().map(item => item.id));
  for (const id of ['wave','laugh','sad','handshake','read','openDoor','heroPose','checkpoint','respawn','vault','swim','sneak']) assert.ok(ids.has(id), `missing ${id}`);
});

test('sequence supports validated animation overlays and blend timing', () => {
  const sequence = buildAnimationSequence({ actions: [{ action: 'walk', blendInMs: 250, blendOutMs: 300, overlays: ['talk', 'happy'] }] });
  assert.equal(sequence.steps[0].blendInMs, 250);
  assert.deepEqual(sequence.steps[0].overlays.map(x => x.action), ['talk', 'happy']);
  assert.throws(() => buildAnimationSequence({ actions: [{ action: 'walk', overlays: ['jump'] }] }), /Invalid overlay/);
  assert.throws(() => buildAnimationSequence({ actions: [{ action: 'walk', blendInMs: 6000 }] }), /Blend durations/);
});
