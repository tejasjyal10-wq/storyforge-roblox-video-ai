const intents = new Set(['neutral','travel','follow','explore','talk','listen','react','celebrate','comfort','suspense','interact','traverse','roblox_obstacle']);
const profiles = {
  neutral: { posture:'relaxed', movement:'idle', attention:'environment', expression:'neutral', pace:1 },
  travel: { posture:'upright', movement:'walk', attention:'path', expression:'focused', pace:1.15 },
  follow: { posture:'upright', movement:'follow_target', attention:'target', expression:'attentive', pace:1 },
  explore: { posture:'alert', movement:'walk_then_pause', attention:'scan_environment', expression:'curious', pace:0.9 },
  talk: { posture:'engaged', movement:'small_gestures', attention:'listener', expression:'speaking', pace:1 },
  listen: { posture:'engaged', movement:'still_with_reactions', attention:'speaker', expression:'attentive', pace:0.85 },
  react: { posture:'responsive', movement:'reaction_then_settle', attention:'event', expression:'contextual', pace:1.2 },
  celebrate: { posture:'open', movement:'celebration', attention:'group', expression:'happy', pace:1.2 },
  comfort: { posture:'gentle', movement:'approach_then_pause', attention:'person', expression:'warm', pace:0.8 },
  suspense: { posture:'guarded', movement:'slow_step_and_hold', attention:'threat_or_reveal', expression:'tense', pace:0.65 },
  interact: { posture:'task_ready', movement:'approach_and_use', attention:'object', expression:'focused', pace:1 },
  traverse: { posture:'dynamic', movement:'traversal_sequence', attention:'route', expression:'determined', pace:1.25 },
  roblox_obstacle: { posture:'game_ready', movement:'obstacle_course_sequence', attention:'obstacle_and_checkpoint', expression:'focused', pace:1.25 }
};
const cueRules = [
  { words:/surpris|sudden|bang|crash|appear|reveals?/i, reaction:'surprised', actions:['look','react'] },
  { words:/danger|threat|monster|enemy|alarm/i, reaction:'alert', actions:['look','block'] },
  { words:/sad|hurt|cry|upset/i, reaction:'concerned', actions:['listen','comfort'] },
  { words:/happy|win|success|cheer/i, reaction:'joyful', actions:['cheer','clap'] },
  { words:/door|switch|lever|button|object/i, reaction:'task-focused', actions:['interact'] },
  { words:/jump|gap|platform|obstacle|checkpoint/i, reaction:'route-focused', actions:['traverse','checkpoint'] }
];
function cleanText(value, field, max=300) {
  if (value === undefined || value === null) return '';
  if (typeof value !== 'string') throw new Error(`${field} must be a string.`);
  if (value.length > max) throw new Error(`${field} must be ${max} characters or fewer.`);
  return value.trim();
}
export function getMotionBehaviorProfiles() { return Object.entries(profiles).map(([intent, profile])=>({intent, ...profile})); }
export function createMotionBehaviorPlan(input={}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Request must be an object.');
  const intent = input.intent || 'neutral';
  if (!intents.has(intent)) throw new Error(`Unknown intent. Supported intents: ${[...intents].join(', ')}.`);
  const characterId = cleanText(input.characterId,'characterId',100) || 'character-1';
  const name = cleanText(input.characterName,'characterName',100) || characterId;
  const context = cleanText(input.context,'context',1200);
  const dialogue = cleanText(input.dialogue,'dialogue',1000);
  const targetId = cleanText(input.targetId,'targetId',100);
  const platform = input.platform === 'roblox' ? 'roblox' : 'cinematic';
  const profile = profiles[intent];
  const cueText = `${context} ${dialogue}`;
  const reactions = cueRules.filter(rule=>rule.words.test(cueText)).map(rule=>({reaction:rule.reaction, suggestedActions:rule.actions}));
  const events = [];
  events.push({at:'start',type:'posture',value:profile.posture});
  events.push({at:'start',type:'movement',value:profile.movement,pace:profile.pace});
  events.push({at:'throughout',type:'attention',value:profile.attention,targetId:targetId||undefined});
  if (dialogue) events.push({at:'dialogue',type:'gesture',value:intent==='talk'?'small_gestures':'subtle_listening', synchronized:true});
  for (const reaction of reactions) events.push({at:'context_cue',type:'reaction',value:reaction.reaction,actions:reaction.suggestedActions});
  if (platform==='roblox' && (intent==='traverse'||intent==='roblox_obstacle')) events.push({at:'route_events',type:'gameplay',value:['obstacle_check','traversal','checkpoint_update','landing_or_settle']});
  events.push({at:'end',type:'settle',value:'blend_to_scene_state'});
  return {version:'0.7.0',character:{id:characterId,name},intent,platform,targetId:targetId||null,context,profile:{...profile},reactions,events,notes:['This is a behavior plan, not rendered or executed animation.','Use scene state and character continuity to resolve exact timing and movement.']};
}
export function createGroupInteractionPlan(input={}) {
  const actors = input.characters;
  if (!Array.isArray(actors) || actors.length<2 || actors.length>8) throw new Error('characters must contain 2 to 8 participants.');
  const interaction = cleanText(input.interaction,'interaction',500) || 'conversation';
  const leadId = cleanText(input.leadId,'leadId',100) || actors[0]?.id;
  if (!actors.every(a=>a && typeof a.id==='string' && a.id.trim())) throw new Error('Every character must have a non-empty id.');
  if (!actors.some(a=>a.id===leadId)) throw new Error('leadId must match a participant.');
  const unique = new Set(actors.map(a=>a.id));
  if (unique.size!==actors.length) throw new Error('Character ids must be unique.');
  return {version:'0.7.0',interaction,leadId,participants:actors.map((a,index)=>({id:a.id,name:cleanText(a.name,'character name',100)||a.id,role:index===0?'initiator':'participant',attention:index===0?'group':'lead',turnOrder:index+1,spacing:'comfortable conversational distance'})),coordination:['initiator begins','participants react in turn','allow short response pauses','avoid simultaneous gestures unless the scene calls for them','maintain facing and spacing continuity'],note:'Interaction timing is a plan; no motion is executed or rendered.'};
}
