import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const MAX_TEXT = 2000;
const fields = ['name', 'appearance', 'personality', 'role', 'voice', 'notes'];
function normalizeCharacter(input, { partial = false } = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw Object.assign(new Error('Character must be an object.'), { status: 400 });
  const out = {};
  for (const field of fields) {
    if (partial && !(field in input)) continue;
    const value = input[field] ?? '';
    if (typeof value !== 'string') throw Object.assign(new Error(`${field} must be a string.`), { status: 400 });
    if (value.length > MAX_TEXT) throw Object.assign(new Error(`${field} must be ${MAX_TEXT} characters or fewer.`), { status: 400 });
    out[field] = value.trim();
  }
  if (!partial && !out.name) throw Object.assign(new Error('name is required.'), { status: 400 });
  if (partial && 'name' in out && !out.name) throw Object.assign(new Error('name cannot be empty.'), { status: 400 });
  if ('tags' in input) {
    if (!Array.isArray(input.tags) || input.tags.length > 30 || input.tags.some(t => typeof t !== 'string' || t.length > 80)) throw Object.assign(new Error('tags must be an array of up to 30 short strings.'), { status: 400 });
    out.tags = [...new Set(input.tags.map(t => t.trim()).filter(Boolean))];
  } else if (!partial) out.tags = [];
  return out;
}

export function createCharacterStore({ filePath = path.join(process.cwd(), 'data', 'characters.json') } = {}) {
  async function readAll() {
    try {
      const data = JSON.parse(await fs.readFile(filePath, 'utf8'));
      return Array.isArray(data) ? data : [];
    } catch (error) {
      if (error.code === 'ENOENT') return [];
      throw error;
    }
  }
  async function writeAll(characters) {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    const temp = `${filePath}.${process.pid}.tmp`;
    await fs.writeFile(temp, JSON.stringify(characters, null, 2), 'utf8');
    await fs.rename(temp, filePath);
  }
  return {
    list: async () => readAll(),
    get: async id => (await readAll()).find(c => c.id === id) || null,
    create: async input => {
      const normalized = normalizeCharacter(input);
      const characters = await readAll();
      if (characters.some(c => c.name.toLowerCase() === normalized.name.toLowerCase())) throw Object.assign(new Error('A character with this name already exists.'), { status: 409 });
      const now = new Date().toISOString();
      const character = { id: randomUUID(), ...normalized, createdAt: now, updatedAt: now };
      characters.push(character); await writeAll(characters); return character;
    },
    update: async (id, input) => {
      const normalized = normalizeCharacter(input, { partial: true });
      const characters = await readAll();
      const index = characters.findIndex(c => c.id === id);
      if (index < 0) return null;
      if (normalized.name && characters.some(c => c.id !== id && c.name.toLowerCase() === normalized.name.toLowerCase())) throw Object.assign(new Error('A character with this name already exists.'), { status: 409 });
      characters[index] = { ...characters[index], ...normalized, updatedAt: new Date().toISOString() };
      await writeAll(characters); return characters[index];
    },
    delete: async id => {
      const characters = await readAll();
      const index = characters.findIndex(c => c.id === id);
      if (index < 0) return false;
      characters.splice(index, 1); await writeAll(characters); return true;
    }
  };
}
