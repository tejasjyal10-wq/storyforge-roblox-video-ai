import { randomUUID } from 'node:crypto';
export const PIPELINE_STAGES = ['request-received', 'story-planned', 'scenes-planned', 'ready-for-production'];
export function createProduction({ story, scenes }) {
  const now = new Date().toISOString();
  return {
    productionId: randomUUID(),
    createdAt: now,
    updatedAt: now,
    status: 'planning-complete',
    stage: 'ready-for-production',
    progress: 0,
    story,
    scenes,
    assets: { characters: [], environments: [], audio: [], animation: [] },
    export: { status: 'not-started', formats: ['mp4'], note: 'Rendering/export is not implemented in Day 2.' },
    capabilityStatus: { localPlanning: 'implemented', llmStoryGeneration: 'not-connected', imageGeneration: 'not-connected', animation: 'not-connected', audio: 'not-connected', blender: 'not-connected', videoRendering: 'not-connected' }
  };
}
