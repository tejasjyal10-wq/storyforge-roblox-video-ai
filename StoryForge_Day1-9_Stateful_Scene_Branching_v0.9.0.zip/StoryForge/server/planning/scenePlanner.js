const sceneTemplates = [
  { slug: 'opening', name: 'The World', beat: 'opening', goal: 'Establish the world, lead character, and visual mood.' },
  { slug: 'inciting', name: 'The Disruption', beat: 'inciting-incident', goal: 'Introduce the event that changes the protagonist’s direction.' },
  { slug: 'challenge', name: 'The First Challenge', beat: 'rising-action', goal: 'Show an obstacle and the protagonist’s response.' },
  { slug: 'turning-point', name: 'The Turning Point', beat: 'rising-action', goal: 'Reveal a discovery or raise the stakes.' },
  { slug: 'finale', name: 'The Confrontation', beat: 'climax', goal: 'Stage the decisive conflict and its outcome.' },
  { slug: 'ending', name: 'Aftermath', beat: 'resolution', goal: 'Show the consequence and leave a clear closing image.' }
];
export function planScenes(story, options = {}) {
  if (!story || typeof story !== 'object' || typeof story.sourcePrompt !== 'string') throw new TypeError('story plan is required');
  const count = Math.max(3, Math.min(12, Number.isInteger(options.sceneCount) ? options.sceneCount : 6));
  const selected = Array.from({ length: count }, (_, i) => sceneTemplates[Math.min(i, sceneTemplates.length - 1)]);
  return selected.map((template, index) => ({
    id: `scene-${String(index + 1).padStart(2, '0')}`,
    order: index + 1,
    title: index >= sceneTemplates.length ? `${template.name} ${index - sceneTemplates.length + 2}` : template.name,
    storyBeat: template.beat,
    purpose: template.goal,
    location: story.setting,
    characters: [story.protagonist],
    action: index === 0 ? `Introduce ${story.protagonist} and the setting.` : index === count - 1 ? 'Close the story with a consequence and memorable final image.' : 'Advance the story prompt and show a meaningful character action.',
    camera: { shot: index === 0 ? 'wide establishing shot' : index === count - 1 ? 'closing wide shot' : 'medium cinematic shot', movement: index === 0 ? 'slow push-in' : 'controlled cinematic movement' },
    dialoguePlaceholder: null,
    durationSeconds: Number.isInteger(options.sceneDurationSeconds) ? Math.max(5, Math.min(60, options.sceneDurationSeconds)) : 12,
    status: 'planned'
  }));
}
