const cleanPrompt = (prompt) => prompt.trim().replace(/\s+/g, ' ');

export function planStory(prompt, options = {}) {
  if (typeof prompt !== 'string' || !prompt.trim()) throw new TypeError('prompt must be a non-empty string');
  if (prompt.length > 4000) throw new RangeError('prompt must be 4000 characters or fewer');
  const storyPrompt = cleanPrompt(prompt);
  const title = options.title?.trim() || storyPrompt.split(/[.!?]/)[0].slice(0, 72) || 'Untitled Story';
  const genre = options.genre?.trim() || 'adventure';
  const tone = options.tone?.trim() || 'cinematic';
  const protagonist = options.protagonist?.trim() || 'the main character';
  const antagonist = options.antagonist?.trim() || 'an opposing force';
  const setting = options.setting?.trim() || 'a world shaped by the story prompt';
  return {
    title,
    sourcePrompt: storyPrompt,
    genre,
    tone,
    setting,
    protagonist,
    antagonist,
    logline: `${protagonist} faces ${antagonist} in ${setting}, driven by the idea: ${storyPrompt}`,
    beats: [
      { id: 'opening', label: 'Opening', purpose: 'Introduce the protagonist, setting, and ordinary world.' },
      { id: 'inciting-incident', label: 'Inciting Incident', purpose: 'Present the event that forces the protagonist to act.' },
      { id: 'rising-action', label: 'Rising Action', purpose: 'Escalate obstacles, stakes, and discoveries.' },
      { id: 'climax', label: 'Climax', purpose: 'Resolve the central confrontation through a decisive choice or action.' },
      { id: 'resolution', label: 'Resolution', purpose: 'Show the outcome and close the story arc.' }
    ],
    generatedBy: 'storyforge-local-planner',
    requiresLLM: true,
    note: 'This is a structured planning scaffold. A language-model provider is not connected yet.'
  };
}
