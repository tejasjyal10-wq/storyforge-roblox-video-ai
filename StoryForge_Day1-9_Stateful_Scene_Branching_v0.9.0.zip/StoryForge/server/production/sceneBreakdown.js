import { randomUUID } from 'node:crypto';
const bounded = (n,min,max,fallback) => Number.isFinite(n) ? Math.max(min,Math.min(max,Math.round(n))) : fallback;
const shotTemplates = [
 {type:'establishing', framing:'wide', angle:'eye-level', movement:'slow push-in', focus:'location'},
 {type:'character-introduction', framing:'medium', angle:'eye-level', movement:'gentle pan', focus:'primary character'},
 {type:'action', framing:'medium-wide', angle:'dynamic three-quarter', movement:'tracking', focus:'action'},
 {type:'reaction', framing:'close-up', angle:'eye-level', movement:'subtle push-in', focus:'emotion'},
 {type:'closing', framing:'wide', angle:'eye-level', movement:'slow pull-back', focus:'scene outcome'}
];
const obstacleTemplates = [
 {type:'gap-platforms',name:'Platform Gap',challenge:'cross a safe series of gaps',action:'jump and land on marked platforms',camera:'side tracking shot'},
 {type:'blocked-path',name:'Roadblock',challenge:'find a route around a blocked path',action:'inspect, route around, and proceed',camera:'obstacle reveal then follow shot'},
 {type:'moving-barrier',name:'Moving Barrier',challenge:'time movement around a moving obstacle',action:'pause, observe timing, pass safely',camera:'tracking shot with clear timing'},
 {type:'bridge-crossing',name:'Bridge Crossing',challenge:'cross a narrow bridge section',action:'move steadily across and regroup',camera:'wide reveal followed by tracking'},
 {type:'climb-route',name:'Climb Route',challenge:'reach a higher path using climbable steps',action:'climb in stages and reach the ledge',camera:'tilt-up then follow'},
 {type:'checkpoint-gate',name:'Checkpoint Gate',challenge:'reach a checkpoint before the next segment',action:'activate checkpoint and continue',camera:'frontal approach and short reveal'}
];
function makeRobloxPlan(scene, index, enabled) {
 if (!enabled) return {enabled:false,target:'Roblox-compatible planning disabled for this package',obstacles:[],route:[],characterActions:[],checkpoints:[]};
 const seed=Math.max(0,Number(scene.order)||index+1);
 const count=bounded(scene.obstacleCount,1,5,2+(seed%2));
 const obstacles=Array.from({length:count},(_,i)=>{const t=obstacleTemplates[(seed+i)%obstacleTemplates.length];return {id:`${scene.id}-obstacle-${i+1}`,sequence:i+1,...t,placement:`segment ${i+1}`,interactionRequired:true,failState:'retry from nearest checkpoint',checkpointAfter:i===count-1};});
 return {enabled:true,target:'Roblox-style scene staging and gameplay obstacle plan',sceneMode:scene.robloxSceneMode||'cinematic-gameplay',obstacles,route:obstacles.map(o=>o.name),characterActions:['run','jump','dodge','climb','interact','react'].filter((a,ai)=>ai<Math.max(3,count+2)),checkpoints:obstacles.filter(o=>o.checkpointAfter).map(o=>({afterObstacleId:o.id,type:'checkpoint',restartPoint:'safe landing area'})),assetRequirements:['platforms','collision-safe obstacle geometry','checkpoint marker','character rig','environment props'],notes:'Planning specification only; it does not create or publish a Roblox place, model, or animation.'};
}
export function createSceneBreakdown(scene, options={}) {
 if(!scene || typeof scene !== 'object' || typeof scene.id !== 'string') throw new TypeError('scene with an id is required');
 const characters=Array.isArray(scene.characters)?scene.characters:[];
 const total=bounded(options.shotCount,3,8,5);
 const duration=bounded(scene.durationSeconds,5,120,12);
 const robloxEnabled=options.robloxEnabled!==false;
 const robloxPlan=makeRobloxPlan(scene,scene.order??0,robloxEnabled);
 const shots=Array.from({length:total},(_,i)=>{
   const t=shotTemplates[Math.min(i,shotTemplates.length-1)];
   const baseSeconds=Math.floor(duration/total); const seconds=Math.max(2,baseSeconds+(i<duration%total?1:0));
   const obstacle=robloxPlan.obstacles[i%Math.max(robloxPlan.obstacles.length,1)];
   return {id:`${scene.id}-shot-${String(i+1).padStart(2,'0')}`,order:i+1,type:t.type,framing:t.framing,cameraAngle:t.angle,cameraMovement:t.movement,focusTarget:t.focus,estimatedDurationSeconds:seconds,transitionIn:i===0?'cut':'cut',actionNotes:i===0?scene.purpose||'Establish the scene context.':scene.action||'Advance the scene action.',characterBlocking:characters.map(name=>({character:name,position:i===0?'foreground/entry point':'maintain continuity from prior shot',facing:'toward scene action'})),dialogueCue:scene.dialoguePlaceholder||null,audioCues:{ambience:scene.location?`Ambient sound for ${scene.location}`:'Scene ambience',soundEffects:[],musicMood:'supporting mood; no specific track selected'},robloxActionCue:robloxEnabled?(i===2&&obstacle?`Stage interaction with ${obstacle.name}: ${obstacle.action}.`:'Roblox-compatible character staging; preserve collision and clear pathing.') : null,obstacleCue:robloxEnabled&&obstacle?{obstacleId:obstacle.id,name:obstacle.name,action:obstacle.action,camera:obstacle.camera}:null,continuityNotes:'Preserve character identity, outfit, props, environment palette, and spatial orientation across adjacent shots.'};
 });
 return {packageId:randomUUID(),sceneId:scene.id,sceneOrder:scene.order??null,title:scene.title||scene.id,location:scene.location||null,storyBeat:scene.storyBeat||null,characters,visualStyle:options.visualStyle||'inherit-from-world',shots,totalEstimatedDurationSeconds:shots.reduce((s,x)=>s+x.estimatedDurationSeconds,0),roblox:robloxPlan,assetsNeeded:{characterReferences:characters,environmentReference:scene.location?[scene.location]:[],props:robloxPlan.enabled?robloxPlan.assetRequirements:[],audio:[]},productionReadiness:{status:'planning-ready',requiresExternalGeneration:true,missingIntegrations:['image-generation','animation','voice-generation','rendering','Roblox Studio/asset pipeline'],notes:'This is a production plan, not rendered video or generated assets.'}};
}
export function createProductionBreakdown(input={}) {
 const scenes=Array.isArray(input.scenes)?input.scenes:input.production?.scenes;
 if(!Array.isArray(scenes)||scenes.length===0) throw new TypeError('scenes array is required');
 const packages=scenes.map((s,i)=>createSceneBreakdown(s,{...(input.options||{}),sceneIndex:i}));
 return {breakdownId:randomUUID(),createdAt:new Date().toISOString(),sceneCount:packages.length,shotCount:packages.reduce((n,p)=>n+p.shots.length,0),totalEstimatedDurationSeconds:packages.reduce((n,p)=>n+p.totalEstimatedDurationSeconds,0),robloxEnabled:packages.some(p=>p.roblox.enabled),obstacleCount:packages.reduce((n,p)=>n+p.roblox.obstacles.length,0),packages};
}
