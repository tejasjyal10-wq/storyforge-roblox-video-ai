const EVENT_TYPES = ['trigger','dialogue','animation','interaction','environment','camera','audio','transition','gameplay'];
const INTERACTIONS = ['open','close','activate','deactivate','pickup','putdown','inspect','use','push','pull','enter','exit'];
const PLATFORMS = ['cinematic','roblox','blender'];
const clean = (v, fallback='') => typeof v === 'string' ? v.trim() : fallback;
function validateId(id, label='id') { if (typeof id !== 'string' || !id.trim()) throw new Error(`${label} must be a non-empty string.`); return id.trim(); }
export function createSceneEvent(input={}) {
  const id=validateId(input.id,'event id'); const type=clean(input.type);
  if(!EVENT_TYPES.includes(type)) throw new Error(`Unsupported event type: ${type}`);
  const priority=Number.isInteger(input.priority)?input.priority:0;
  if(priority < -10 || priority > 10) throw new Error('priority must be between -10 and 10.');
  const delayMs=Number.isInteger(input.delayMs)?input.delayMs:0;
  if(delayMs<0 || delayMs>3600000) throw new Error('delayMs must be between 0 and 3600000.');
  return {id,type,priority,delayMs,actorId:input.actorId||null,targetId:input.targetId||null,condition:input.condition||null,payload:input.payload||{},status:'queued'};
}
export function buildEventQueue(events=[]) {
  if(!Array.isArray(events)||events.length>200) throw new Error('events must be an array with at most 200 items.');
  const normalized=events.map(createSceneEvent); if(new Set(normalized.map(e=>e.id)).size!==normalized.length) throw new Error('event ids must be unique.');
  normalized.sort((a,b)=>a.delayMs-b.delayMs || b.priority-a.priority);
  return {count:normalized.length,events:normalized,queue:normalized.map(e=>e.id)};
}
export function createInteractionPlan(input={}) {
  const action=clean(input.action); if(!INTERACTIONS.includes(action)) throw new Error(`Unsupported interaction action: ${action}`);
  const actorId=validateId(input.actorId,'actorId'); const targetId=validateId(input.targetId,'targetId');
  const platform=clean(input.platform,'cinematic'); if(!PLATFORMS.includes(platform)) throw new Error('Unsupported platform.');
  const requirements={approach:true,animation:action,attentionTarget:targetId,successEvent:`${action}_completed`,failureEvent:`${action}_failed`};
  return {actorId,targetId,action,platform,requirements,events:[{type:'interaction',actorId,targetId,action,phase:'start'},{type:'animation',actorId,animation:action},{type:'interaction',actorId,targetId,action,phase:'complete',condition:'interaction_success'}]};
}
export function createSceneTimeline(input={}) {
  const items=input.items; if(!Array.isArray(items)||items.length===0||items.length>200) throw new Error('items must be a non-empty array of at most 200 timeline entries.');
  let cursor=0; const timeline=items.map((item,index)=>{const duration=Number(item.durationMs??1000);if(!Number.isFinite(duration)||duration<0||duration>3600000)throw new Error('durationMs must be 0–3600000.'); const start=Number.isFinite(item.startMs)?item.startMs:cursor;if(start<0)throw new Error('startMs must be non-negative.');const end=start+duration;cursor=Math.max(cursor,end);return {id:validateId(item.id,`timeline item ${index+1} id`),kind:clean(item.kind,'event'),startMs:start,durationMs:duration,endMs:end,actorId:item.actorId||null,dependencies:Array.isArray(item.dependencies)?item.dependencies:[]};});
  const ids=new Set(timeline.map(x=>x.id)); if(ids.size!==timeline.length)throw new Error('timeline item ids must be unique.'); for(const x of timeline)for(const dep of x.dependencies)if(!ids.has(dep))throw new Error(`Unknown timeline dependency: ${dep}`);
  return {durationMs:Math.max(...timeline.map(x=>x.endMs)),items:timeline.sort((a,b)=>a.startMs-b.startMs),synchronizationWarnings:timeline.filter(x=>x.dependencies.includes(x.id)).map(x=>`Self-dependency detected: ${x.id}`)};
}
export function createSceneDirectorPlan(input={}) {
  const sceneId=validateId(input.sceneId,'sceneId'); const events=buildEventQueue(input.events||[]); const timeline=createSceneTimeline({items:input.timeline||[{id:'scene-start',kind:'transition',durationMs:0}]}); const platform=clean(input.platform,'cinematic');if(!PLATFORMS.includes(platform))throw new Error('Unsupported platform.');
  return {sceneId,platform,events,timeline,sequence:[{step:1,type:'scene-initialize'},{step:2,type:'event-queue-ready',count:events.count},{step:3,type:'timeline-ready',durationMs:timeline.durationMs},{step:4,type:'scene-complete',condition:'all_required_events_resolved'}],status:'planned'};
}
export const getSceneInteractionCatalog=()=>({eventTypes:EVENT_TYPES,interactionActions:INTERACTIONS,platforms:PLATFORMS});
