const VALID_OPERATORS = new Set(['eq','neq','gt','gte','lt','lte','truthy','falsy','contains']);
const VALID_UPDATES = new Set(['set','increment','decrement','append','toggle']);
const VALID_OBJECT_STATES = new Set(['locked','unlocked','inactive','active','available','collected','closed','open']);
const clone = (value) => structuredClone(value);

function requireKey(key, label='key') {
  if (typeof key !== 'string' || !key.trim() || key.length > 100) throw new Error(`${label} must be a non-empty string (max 100 characters).`);
  return key.trim();
}
export function createSceneState(input={}) {
  const vars = input.variables ?? {};
  const flags = input.flags ?? {};
  if (!vars || typeof vars !== 'object' || Array.isArray(vars)) throw new Error('variables must be an object.');
  if (!flags || typeof flags !== 'object' || Array.isArray(flags)) throw new Error('flags must be an object.');
  if (Object.keys(vars).length > 100 || Object.keys(flags).length > 100) throw new Error('Scene state is limited to 100 variables and 100 flags.');
  return { sceneId: input.sceneId ? String(input.sceneId) : 'scene-1', variables: clone(vars), flags: clone(flags), objects: {}, objectives: {}, history: [], revision: 0 };
}
export function evaluateCondition(condition, state) {
  if (!condition || typeof condition !== 'object' || Array.isArray(condition)) throw new Error('condition must be an object.');
  const key = requireKey(condition.key, 'condition key');
  const op = condition.operator;
  if (!VALID_OPERATORS.has(op)) throw new Error(`Unsupported condition operator: ${op}`);
  const actual = key in state.variables ? state.variables[key] : state.flags[key];
  switch(op) {
    case 'eq': return actual === condition.value;
    case 'neq': return actual !== condition.value;
    case 'gt': return typeof actual === 'number' && typeof condition.value === 'number' && actual > condition.value;
    case 'gte': return typeof actual === 'number' && typeof condition.value === 'number' && actual >= condition.value;
    case 'lt': return typeof actual === 'number' && typeof condition.value === 'number' && actual < condition.value;
    case 'lte': return typeof actual === 'number' && typeof condition.value === 'number' && actual <= condition.value;
    case 'truthy': return Boolean(actual);
    case 'falsy': return !actual;
    case 'contains': return typeof actual === 'string' ? actual.includes(String(condition.value)) : Array.isArray(actual) ? actual.includes(condition.value) : false;
  }
}
export function applySceneUpdate(state, update) {
  if (!update || typeof update !== 'object' || Array.isArray(update)) throw new Error('update must be an object.');
  const key = requireKey(update.key, 'update key');
  if (!VALID_UPDATES.has(update.operation)) throw new Error(`Unsupported update operation: ${update.operation}`);
  const target = update.target === 'flag' ? state.flags : state.variables;
  const current = target[key];
  let next;
  switch(update.operation) {
    case 'set': next = clone(update.value); break;
    case 'increment': if (typeof current !== 'number' || typeof update.value !== 'number') throw new Error('increment requires numeric current and value.'); next = current + update.value; break;
    case 'decrement': if (typeof current !== 'number' || typeof update.value !== 'number') throw new Error('decrement requires numeric current and value.'); next = current - update.value; break;
    case 'append': if (!Array.isArray(current)) throw new Error('append requires an array variable.'); next = [...current, clone(update.value)]; break;
    case 'toggle': if (typeof current !== 'boolean') throw new Error('toggle requires a boolean current value.'); next = !current; break;
  }
  target[key] = next; state.revision += 1;
  state.history.push({ revision: state.revision, type: 'state-update', target: update.target === 'flag' ? 'flag' : 'variable', key, operation: update.operation, value: clone(next) });
  return state;
}
export function defineSceneObject(state, object) {
  const id = requireKey(object?.id, 'object id');
  const status = object.status ?? 'available';
  if (!VALID_OBJECT_STATES.has(status)) throw new Error(`Unsupported object status: ${status}`);
  state.objects[id] = { id, name: object.name ? String(object.name) : id, status, properties: clone(object.properties ?? {}) };
  state.revision += 1;
  state.history.push({ revision: state.revision, type: 'object-defined', objectId: id, status });
  return state.objects[id];
}
export function updateSceneObject(state, input) {
  const id = requireKey(input?.id, 'object id');
  const object = state.objects[id];
  if (!object) throw new Error(`Scene object not found: ${id}`);
  const status = input.status;
  if (!VALID_OBJECT_STATES.has(status)) throw new Error(`Unsupported object status: ${status}`);
  object.status = status;
  if (input.property && typeof input.property.key === 'string') object.properties[input.property.key] = clone(input.property.value);
  state.revision += 1;
  state.history.push({ revision: state.revision, type: 'object-updated', objectId: id, status });
  return object;
}
export function resolveSceneBranch(state, branches) {
  if (!Array.isArray(branches) || branches.length === 0 || branches.length > 50) throw new Error('branches must be a non-empty array (max 50).');
  for (const branch of branches) {
    if (!branch || typeof branch !== 'object' || !branch.id) throw new Error('Each branch requires an id.');
    if (branch.conditions === undefined || branch.conditions === null) return { branchId: String(branch.id), label: branch.label ?? String(branch.id), selectedBy: 'fallback' };
    if (!Array.isArray(branch.conditions)) throw new Error(`Branch ${branch.id} conditions must be an array.`);
    const matched = branch.conditions.every(c => evaluateCondition(c, state));
    if (matched) return { branchId: String(branch.id), label: branch.label ?? String(branch.id), selectedBy: 'conditions' };
  }
  return null;
}
export function completeSceneObjective(state, objectiveId, details={}) {
  const id = requireKey(objectiveId, 'objective id');
  state.objectives[id] = { completed: true, completedAtRevision: state.revision + 1, details: clone(details) };
  state.revision += 1;
  state.history.push({ revision: state.revision, type: 'objective-completed', objectiveId: id });
  return state.objectives[id];
}
export function getSceneStateCatalog() {
  return { operators: [...VALID_OPERATORS], updates: [...VALID_UPDATES], objectStates: [...VALID_OBJECT_STATES], limits: { variables: 100, flags: 100, branches: 50 }, features: ['variables-and-flags','condition-evaluation','branch-resolution','object-state-tracking','objective-completion','revisioned-history'] };
}
