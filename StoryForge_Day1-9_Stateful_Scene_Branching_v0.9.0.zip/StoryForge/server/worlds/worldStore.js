import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
const textFields=['name','description','worldType','artStyle','palette','lore','geography','climate','atmosphere','rules'];
const MAX=4000;
function normalize(input,{partial=false}={}){
 if(!input||typeof input!=='object'||Array.isArray(input)) throw Object.assign(new Error('World must be an object.'),{status:400});
 const out={}; for(const f of textFields){if(partial&&!(f in input))continue;const v=input[f]??'';if(typeof v!=='string'||v.length>MAX)throw Object.assign(new Error(`${f} must be a string of ${MAX} characters or fewer.`),{status:400});out[f]=v.trim();}
 if(!partial&&!out.name)throw Object.assign(new Error('World name is required.'),{status:400});
 for(const f of ['regions','tags']){if(f in input){if(!Array.isArray(input[f])||input[f].length>100||input[f].some(x=>typeof x!=='string'||x.length>160))throw Object.assign(new Error(`${f} must be an array of up to 100 short strings.`),{status:400});out[f]=[...new Set(input[f].map(x=>x.trim()).filter(Boolean))];}else if(!partial)out[f]=[];}
 return out;
}
function normalizeLocation(input,{partial=false}={}){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Object.assign(new Error('Location must be an object.'),{status:400});
 const fields=['name','description','environmentType','visualIdentity','lighting','weather','timeOfDay','atmosphere','objects','connections','interior'];const out={};
 for(const f of fields){if(partial&&!(f in input))continue;const v=input[f]??(f==='objects'||f==='connections'?[]:f==='interior'?null:'');if(['objects','connections'].includes(f)){if(!Array.isArray(v)||v.length>100||v.some(x=>typeof x!=='string'||x.length>160))throw Object.assign(new Error(`${f} must be an array of up to 100 short strings.`),{status:400});out[f]=[...new Set(v.map(x=>x.trim()).filter(Boolean))];}else if(f==='interior'){if(v!==null&&(typeof v!=='object'||Array.isArray(v)))throw Object.assign(new Error('interior must be an object or null.'),{status:400});out[f]=v;}else{if(typeof v!=='string'||v.length>MAX)throw Object.assign(new Error(`${f} must be a string of ${MAX} characters or fewer.`),{status:400});out[f]=v.trim();}}
 if(!partial&&!out.name)throw Object.assign(new Error('Location name is required.'),{status:400});return out;
}
export function createWorldStore({filePath=path.join(process.cwd(),'data','worlds.json')}={}){
 async function read(){try{const d=JSON.parse(await fs.readFile(filePath,'utf8'));return Array.isArray(d)?d:[]}catch(e){if(e.code==='ENOENT')return [];throw e;}}
 async function write(items){await fs.mkdir(path.dirname(filePath),{recursive:true});const tmp=`${filePath}.${process.pid}.tmp`;await fs.writeFile(tmp,JSON.stringify(items,null,2),'utf8');await fs.rename(tmp,filePath);}
 return {
 list:async()=>read(),get:async id=>(await read()).find(w=>w.id===id)||null,
 create:async input=>{const n=normalize(input);const a=await read();if(a.some(w=>w.name.toLowerCase()===n.name.toLowerCase()))throw Object.assign(new Error('A world with this name already exists.'),{status:409});const now=new Date().toISOString();const w={id:randomUUID(),...n,locations:[],createdAt:now,updatedAt:now};a.push(w);await write(a);return w;},
 update:async(id,input)=>{const n=normalize(input,{partial:true}),a=await read(),i=a.findIndex(w=>w.id===id);if(i<0)return null;if(n.name&&a.some(w=>w.id!==id&&w.name.toLowerCase()===n.name.toLowerCase()))throw Object.assign(new Error('A world with this name already exists.'),{status:409});a[i]={...a[i],...n,updatedAt:new Date().toISOString()};await write(a);return a[i];},
 delete:async id=>{const a=await read(),i=a.findIndex(w=>w.id===id);if(i<0)return false;a.splice(i,1);await write(a);return true;},
 listLocations:async id=>{const w=(await read()).find(w=>w.id===id);return w?w.locations:null;},
 createLocation:async(id,input)=>{const n=normalizeLocation(input),a=await read(),i=a.findIndex(w=>w.id===id);if(i<0)return null;if(a[i].locations.some(l=>l.name.toLowerCase()===n.name.toLowerCase()))throw Object.assign(new Error('A location with this name already exists in this world.'),{status:409});const now=new Date().toISOString(),loc={id:randomUUID(),...n,createdAt:now,updatedAt:now};a[i].locations.push(loc);a[i].updatedAt=now;await write(a);return loc;},
 updateLocation:async(id,lid,input)=>{const n=normalizeLocation(input,{partial:true}),a=await read(),i=a.findIndex(w=>w.id===id);if(i<0)return null;const j=a[i].locations.findIndex(l=>l.id===lid);if(j<0)return false;if(n.name&&a[i].locations.some(l=>l.id!==lid&&l.name.toLowerCase()===n.name.toLowerCase()))throw Object.assign(new Error('A location with this name already exists in this world.'),{status:409});const now=new Date().toISOString();a[i].locations[j]={...a[i].locations[j],...n,updatedAt:now};a[i].updatedAt=now;await write(a);return a[i].locations[j];},
 deleteLocation:async(id,lid)=>{const a=await read(),i=a.findIndex(w=>w.id===id);if(i<0)return null;const j=a[i].locations.findIndex(l=>l.id===lid);if(j<0)return false;a[i].locations.splice(j,1);a[i].updatedAt=new Date().toISOString();await write(a);return true;}
 };
}
