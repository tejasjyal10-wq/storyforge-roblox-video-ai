/** StoryForge frontend API helper. For same-origin deployment leave API base empty. */
const API_BASE = (globalThis.STORYFORGE_API_BASE || '').replace(/\/$/, '');
async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { ...(options.headers || {}), ...(options.body ? { 'content-type': 'application/json' } : {}) },
    });
  } catch (error) {
    throw new Error(`Cannot reach StoryForge backend. Check the server URL and that the server is running. ${error?.message || ''}`.trim());
  }
  let payload;
  try { payload = await response.json(); }
  catch { throw new Error(`StoryForge backend returned an unreadable response (${response.status}).`); }
  if (!response.ok) throw new Error(payload.message || `StoryForge API error (${response.status})`);
  return payload;
}
export const storyforgeAPI = {
  health: () => request('/health'),
  status: () => request('/api/status'),
  metadata: () => request('/api/meta'),
  capabilities: () => request('/api/agent/capabilities'),
  validatePrompt: (prompt) => request('/api/agent/validate-request', { method: 'POST', body: JSON.stringify({ prompt }) }),
  plan: (prompt, options = {}) => request('/api/agent/plan', { method: 'POST', body: JSON.stringify({ prompt, worldId: options.worldId || undefined, storyOptions: options.storyOptions || {}, sceneOptions: options.sceneOptions || {} }) }),
  worlds: () => request('/api/worlds'),
  getWorld: (id) => request(`/api/worlds/${encodeURIComponent(id)}`),
  createWorld: (world) => request('/api/worlds', { method: 'POST', body: JSON.stringify(world) }),
  generateWorld: (data) => request('/api/worlds/generate', { method: 'POST', body: JSON.stringify(data) }),
  updateWorld: (id, changes) => request(`/api/worlds/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(changes) }),
  deleteWorld: (id) => request(`/api/worlds/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  locations: (worldId) => request(`/api/worlds/${encodeURIComponent(worldId)}/locations`),
  createLocation: (worldId, location) => request(`/api/worlds/${encodeURIComponent(worldId)}/locations`, { method: 'POST', body: JSON.stringify(location) }),
  updateLocation: (worldId, locationId, changes) => request(`/api/worlds/${encodeURIComponent(worldId)}/locations/${encodeURIComponent(locationId)}`, { method: 'PUT', body: JSON.stringify(changes) }),
  deleteLocation: (worldId, locationId) => request(`/api/worlds/${encodeURIComponent(worldId)}/locations/${encodeURIComponent(locationId)}`, { method: 'DELETE' }),
  generateEnvironment: (data) => request('/api/environments/generate', { method: 'POST', body: JSON.stringify(data) }),
  generateInterior: (data) => request('/api/interiors/generate', { method: 'POST', body: JSON.stringify(data) }),
  characters: () => request('/api/characters'),
  getCharacter: (id) => request(`/api/characters/${encodeURIComponent(id)}`),
  createCharacter: (character) => request('/api/characters', { method: 'POST', body: JSON.stringify(character) }),
  updateCharacter: (id, changes) => request(`/api/characters/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(changes) }),
  deleteCharacter: (id) => request(`/api/characters/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};
