# StoryForge — Day 1 Foundation (v0.1.1)

A dependency-free Node.js 20+ backend foundation with API health/status endpoints, metadata, request validation, configurable CORS, error handling, frontend helper, integration example, and tests. This package is a foundation, not an AI video generator.


## Contents
- `server/`: backend source and Node built-in test suite
- `web/storyforge-api.js`: small frontend API helper for connecting UI code
- `web/integration-example.html`: standalone example page
- `deployment/`: environment and deployment notes


## Run
```bash
cd server
npm start
```
Server listens on `0.0.0.0:3001` by default; override `PORT`, `HOST`, and `CORS_ORIGINS` via environment variables.


## Test
```bash
cd server
npm test
```

## API endpoints
- `GET /` service landing JSON
- `GET /health` health check
- `GET /api/meta` project metadata and explicit not-yet-implemented capabilities
- `GET /api/status` backend/integration status
- `POST /api/agent/validate-request` validates a prompt only (does not generate content)

Example validation payload:
```json
{ "prompt": "A Roblox adventure story" }
```

## Frontend helper
Include `web/storyforge-api.js` in your frontend and set `globalThis.STORYFORGE_API_BASE` to the backend origin if the backend is hosted separately. It exports `storyforgeAPI.health()`, `.status()`, `.metadata()`, and `.validatePrompt(prompt)`.


## CORS
Set `CORS_ORIGINS` to exact origins separated by commas. Unapproved origins are not reflected. For same-origin deployment, no CORS is needed.


## Deployment
See `deployment/replit.md` and `deployment/.env.example`. Use Node 20+ and configure the Replit run command to start `server/server.js` from the `server` folder.


## Day 1 completion boundary
Day 1 verifies the backend foundation and a frontend integration adapter/example. The adapter has not been merged into the user's original website because its original source ZIP has not been supplied in this conversation. AI story/video generation, Blender integration, persistent character memory, and rendering are future work.
