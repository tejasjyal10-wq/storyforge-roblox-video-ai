# Replit deployment notes

1. Upload/extract the `server` folder into your project, or merge its files if your repo already has a backend.
2. Set Replit run command to `cd server && npm start` (or adapt to the repository root).
3. Use Node.js 20 or newer.
4. Set environment variable `PORT` if your host requires it; the server defaults to 3001 but honors `PORT`.
5. Set `HOST=0.0.0.0` for hosted deployment.
6. Set `CORS_ORIGINS` to the exact origin(s) of your frontend, comma-separated.
7. Deploy, then verify `/health`, `/api/meta`, and `/api/status` from the deployed domain.

This backend currently validates requests only. It does not perform AI story/video generation.
