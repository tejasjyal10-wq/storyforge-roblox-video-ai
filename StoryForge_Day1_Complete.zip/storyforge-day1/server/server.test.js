import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from './server.js';

async function withServer(fn) {
  const server = createServer({ host: '127.0.0.1', port: 0, corsOrigins: new Set(['https://storyforge.example']) });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  const base = `http://127.0.0.1:${address.port}`;
  try { await fn(base); } finally { await new Promise(resolve => server.close(resolve)); }
}

test('root returns service message', async () => withServer(async base => {
  const r = await fetch(base); assert.equal(r.status, 200); assert.match((await r.json()).message, /running/);
}));
test('health endpoint reports ok', async () => withServer(async base => {
  const r = await fetch(`${base}/health`); assert.equal(r.status, 200); assert.equal((await r.json()).status, 'ok');
}));
test('metadata endpoint exists and describes foundation', async () => withServer(async base => {
  const r = await fetch(`${base}/api/meta`); const d = await r.json(); assert.equal(r.status, 200); assert.equal(d.phase, 'day-1-foundation');
}));
test('status endpoint clearly distinguishes unavailable AI integrations', async () => withServer(async base => {
  const d = await (await fetch(`${base}/api/status`)).json(); assert.equal(d.backend, 'online'); assert.equal(d.aiGeneration, 'not-connected');
}));
test('valid request is accepted for validation only', async () => withServer(async base => {
  const r = await fetch(`${base}/api/agent/validate-request`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'A Roblox adventure story' }) });
  assert.equal(r.status, 200); assert.equal((await r.json()).valid, true);
}));
test('empty prompt rejected', async () => withServer(async base => {
  const r = await fetch(`${base}/api/agent/validate-request`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: ' ' }) }); assert.equal(r.status, 400);
}));
test('malformed JSON rejected', async () => withServer(async base => {
  const r = await fetch(`${base}/api/agent/validate-request`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{oops' }); assert.equal(r.status, 400);
}));
test('unknown route returns 404', async () => withServer(async base => {
  const r = await fetch(`${base}/missing`); assert.equal(r.status, 404); assert.equal((await r.json()).error, 'not_found');
}));
test('allowed origin receives CORS header', async () => withServer(async base => {
  const r = await fetch(`${base}/health`, { headers: { origin: 'https://storyforge.example' } }); assert.equal(r.headers.get('access-control-allow-origin'), 'https://storyforge.example');
}));
test('unapproved origin is not reflected', async () => withServer(async base => {
  const r = await fetch(`${base}/health`, { headers: { origin: 'https://evil.example' } }); assert.equal(r.headers.get('access-control-allow-origin'), null);
}));
