/** StoryForge frontend API helper. Configure STORYFORGE_API_BASE to your deployed backend URL. */
const API_BASE = (globalThis.STORYFORGE_API_BASE || '').replace(/\/$/, '');
async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers: { ...(options.headers || {}), ...(options.body ? { 'content-type': 'application/json' } : {}) } });
  let payload;
  try { payload = await response.json(); } catch { throw new Error(`StoryForge backend returned non-JSON (${response.status})`); }
  if (!response.ok) throw new Error(payload.message || `StoryForge API error (${response.status})`);
  return payload;
}
export const storyforgeAPI = {
  health: () => request('/health'),
  status: () => request('/api/status'),
  metadata: () => request('/api/meta'),
  validatePrompt: (prompt) => request('/api/agent/validate-request', { method: 'POST', body: JSON.stringify({ prompt }) }),
};
