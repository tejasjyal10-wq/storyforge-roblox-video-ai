# StoryForge Roblox Video AI — Day 1 + Day 2 Integrated Package

This package combines the Node.js backend foundation with the local story/scene planning engine and a browser studio UI. It is a working planning system, not an AI video renderer. It does not connect an LLM or generate images, voice, animation, Blender scenes, or MP4s.

## Requirements
- Node.js 20 or newer
- No third-party packages required

## Run locally
1. Open the `server` folder in a terminal.
2. Run `npm test` to execute backend and frontend-helper tests.
3. Run `npm start` to launch the API (default port 3001).
4. Serve the `web` folder from a static web server. Open `studio.html` through that server (not `file://`, due to browser module restrictions). If web and API are on separate origins, set `globalThis.STORYFORGE_API_BASE` before the module script in `studio.html` to the backend URL and configure `CORS_ORIGINS` on the backend.

## API
- `GET /` welcome and links
- `GET /health` health status
- `GET /api/meta` metadata and capability disclosure
- `GET /api/status` status
- `GET /api/agent/capabilities` capability list
- `POST /api/agent/validate-request` prompt validation
- `POST /api/agent/plan` structured story/scene plan

Example plan body:
```json
{
  "prompt": "A Roblox explorer finds a hidden city above the clouds.",
  "storyOptions": {"genre":"fantasy","tone":"adventurous","protagonist":"an explorer"},
  "sceneOptions": {"sceneCount": 6, "sceneDurationSeconds": 12}
}
```
## Deployment
Set `PORT` (hosting provider usually sets it), optional `HOST`, and `CORS_ORIGINS` (comma-separated exact origin allowlist). Deploy `server/` as the Node service. Deploy `web/` as a static site, or serve it from the same origin with a hosting setup. On Replit, import this package/project and use the server's start command `npm start` from `server/` or configure the root deployment to target the server folder.
## Honest capability boundaries
Planning output is deterministic scaffold content. It uses prompt text and option values but is not LLM-authored narrative. LLM generation, image generation, character persistence, audio, animation, Blender, and video export remain unimplemented/unconnected.
