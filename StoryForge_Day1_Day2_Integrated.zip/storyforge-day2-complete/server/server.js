import http from 'node:http';
import { URL } from 'node:url';
import { pathToFileURL } from 'node:url';
import { createAgentOrchestrator } from './agents/orchestrator.js';

const VERSION = '0.2.0';
const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || '0.0.0.0';
const allowedOrigins = new Set((process.env.CORS_ORIGINS || 'http://localhost:3000,http://127.0.0.1:3000,http://localhost:5173,http://127.0.0.1:5173').split(',').map(s => s.trim()).filter(Boolean));
const MAX_BODY_BYTES = 16 * 1024;


export function createServer({ port = PORT, host = HOST, corsOrigins = allowedOrigins } = {}) {
  const startedAt = Date.now();
  const orchestrator = createAgentOrchestrator();
  const routes = new Map();
  function route(method, path, handler) { routes.set(`${method} ${path}`, handler); }
  function json(res, status, body) {
    const payload = JSON.stringify(body);
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'content-length': Buffer.byteLength(payload),
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
    });
    res.end(payload);
  }
  async function readJson(req) {
    let body = '';
    for await (const chunk of req) {
      body += chunk;
      if (Buffer.byteLength(body) > MAX_BODY_BYTES) throw Object.assign(new Error('Request body too large.'), { status: 413 });
    }
    if (!body) return {};
    try { return JSON.parse(body); }
    catch { throw Object.assign(new Error('Request body must be valid JSON.'), { status: 400 }); }
  }
  route('GET', '/', (_req, res) => json(res, 200, { message: 'StoryForge backend is running.', links: ['/health', '/api/meta', '/api/status'] }));
  route('GET', '/health', (_req, res) => json(res, 200, { status: 'ok', service: 'storyforge-agent-core', version: VERSION, uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000), timestamp: new Date().toISOString() }));
  route('GET', '/api/meta', (_req, res) => json(res, 200, { name: 'StoryForge Roblox Video AI', version: VERSION, phase: 'day-2-planning-engine', capabilities: ['health-check', 'metadata', 'frontend-connection', 'request-validation', 'local-story-planning', 'scene-planning', 'production-plan'], notYetImplemented: ['llm-powered-story-generation', 'image-generation', 'character-memory', 'voice-audio', 'world-generation', 'blender-integration', 'video-rendering'] }));
  route('GET', '/api/status', (_req, res) => json(res, 200, { backend: 'online', day1Foundation: 'ready', aiGeneration: 'not-connected', blender: 'not-connected', videoExport: 'not-connected', uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000) }));
  route('GET', '/api/agent/capabilities', (_req, res) => json(res, 200, {
    agent: orchestrator.name, version: orchestrator.version,
    implemented: ['prompt-validation', 'local-story-structure', 'scene-outline-planning', 'production-plan-assembly'],
    notConnected: ['llm-provider', 'image-generation', 'voice-generation', 'animation-rendering', 'blender', 'mp4-export']
  }));
  route('POST', '/api/agent/plan', async (req, res) => {
    const data = await readJson(req);
    if (typeof data.prompt !== 'string' || !data.prompt.trim()) return json(res, 400, { error: 'invalid_prompt', message: 'prompt must be a non-empty string.' });
    if (data.prompt.length > 4000) return json(res, 400, { error: 'prompt_too_long', message: 'prompt must be 4000 characters or fewer.' });
    const production = await orchestrator.createPlan(data);
    return json(res, 201, production);
  });
  route('POST', '/api/agent/validate-request', async (req, res) => {
    const data = await readJson(req);
    if (typeof data.prompt !== 'string' || !data.prompt.trim()) return json(res, 400, { error: 'invalid_prompt', message: 'prompt must be a non-empty string.' });
    if (data.prompt.length > 4000) return json(res, 400, { error: 'prompt_too_long', message: 'prompt must be 4000 characters or fewer.' });
    json(res, 200, { valid: true, promptLength: data.prompt.trim().length, message: 'Request is valid. AI generation is not connected in Day 1.' });
  });

  const server = http.createServer(async (req, res) => {
    const origin = req.headers.origin;
    if (origin && corsOrigins.has(origin)) {
      res.setHeader('access-control-allow-origin', origin);
      res.setHeader('vary', 'Origin');
    }
    res.setHeader('access-control-allow-methods', 'GET, POST, OPTIONS');
    res.setHeader('access-control-allow-headers', 'Content-Type');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const handler = routes.get(`${req.method} ${url.pathname}`);
    if (handler) {
      try { return await handler(req, res); }
      catch (error) { return json(res, error.status || 500, { error: error.status ? 'request_error' : 'internal_error', message: error.status ? error.message : 'Unexpected server error.' }); }
    }
    json(res, 404, { error: 'not_found', message: 'No route matches this request.' });
  });
  server.on('clientError', (_error, socket) => socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r'));
  return server;
}


const isDirectRun = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isDirectRun) {
  const server = createServer();
  server.listen(PORT, HOST, () => console.log(`StoryForge backend listening on ${HOST}:${PORT}`));
  const shutdown = () => server.close(() => process.exit(0));
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
