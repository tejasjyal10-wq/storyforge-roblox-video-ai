import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from './server.js';

async function withServer(fn) {
  const server = createServer({ port: 0, host: '127.0.0.1', corsOrigins: new Set(['http://localhost:3000']) });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await fn(base); } finally { await new Promise(resolve => server.close(resolve)); }
}
test('root endpoint responds', async () => withServer(async base => { const r = await fetch(base); assert.equal(r.status, 200); }));
test('health endpoint responds', async () => withServer(async base => { const r = await fetch(`${base}/health`); assert.equal(r.status, 200); assert.equal((await r.json()).status, 'ok'); }));
test('metadata reports planning engine', async () => withServer(async base => { const d = await (await fetch(`${base}/api/meta`)).json(); assert.equal(d.phase, 'day-2-planning-engine'); }));
test('capabilities list planning', async () => withServer(async base => { const d = await (await fetch(`${base}/api/agent/capabilities`)).json(); assert.ok(d.implemented.includes('scene-outline-planning')); }));
test('planning endpoint creates production plan', async () => withServer(async base => { const r = await fetch(`${base}/api/agent/plan`, { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({prompt:'A Roblox hero protects a village from a storm monster.'}) }); assert.equal(r.status, 201); const d = await r.json(); assert.equal(d.status, 'planning-complete'); assert.equal(d.scenes.length, 6); assert.equal(d.story.beats.length, 5); }));
test('planning endpoint accepts scene count bounds', async () => withServer(async base => { const r = await fetch(`${base}/api/agent/plan`, { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({prompt:'A mystery in a floating city', sceneOptions:{sceneCount:3}}) }); const d = await r.json(); assert.equal(d.scenes.length, 3); }));
test('planning rejects blank prompt', async () => withServer(async base => { const r = await fetch(`${base}/api/agent/plan`, { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({prompt:'  '}) }); assert.equal(r.status, 400); }));
test('planning rejects prompt over limit', async () => withServer(async base => { const r = await fetch(`${base}/api/agent/plan`, { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({prompt:'x'.repeat(4001)}) }); assert.equal(r.status, 400); }));
test('validation endpoint accepts prompt', async () => withServer(async base => { const r = await fetch(`${base}/api/agent/validate-request`, { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({prompt:'Test story'}) }); assert.equal(r.status, 200); }));
test('invalid JSON receives 400', async () => withServer(async base => { const r = await fetch(`${base}/api/agent/plan`, { method: 'POST', headers: {'content-type':'application/json'}, body: '{bad' }); assert.equal(r.status, 400); }));
test('unknown endpoint returns 404', async () => withServer(async base => { const r = await fetch(`${base}/nope`); assert.equal(r.status, 404); }));
