import test from 'node:test';
import assert from 'node:assert/strict';
import { storyforgeAPI } from './storyforge-api.js';
const originalFetch = globalThis.fetch;
test.afterEach(() => { globalThis.fetch = originalFetch; });
test('API helper parses successful JSON response', async () => { globalThis.fetch = async () => new Response(JSON.stringify({status:'ok'}), {status:200,headers:{'content-type':'application/json'}}); assert.deepEqual(await storyforgeAPI.health(), {status:'ok'}); });
test('API helper reports server error message', async () => { globalThis.fetch = async () => new Response(JSON.stringify({message:'bad prompt'}), {status:400,headers:{'content-type':'application/json'}}); await assert.rejects(storyforgeAPI.plan(''), /bad prompt/); });
test('API helper wraps network errors', async () => { globalThis.fetch = async () => { throw new Error('offline'); }; await assert.rejects(storyforgeAPI.status(), /Cannot reach StoryForge backend/); });
test('plan helper sends prompt and options to correct endpoint', async () => { let captured; globalThis.fetch = async (url,opts) => {captured={url,opts}; return new Response(JSON.stringify({status:'planning-complete'}),{status:201,headers:{'content-type':'application/json'}});}; await storyforgeAPI.plan('test prompt',{sceneOptions:{sceneCount:4}}); assert.equal(captured.url,'/api/agent/plan'); assert.equal(JSON.parse(captured.opts.body).prompt,'test prompt'); assert.equal(JSON.parse(captured.opts.body).sceneOptions.sceneCount,4); });
