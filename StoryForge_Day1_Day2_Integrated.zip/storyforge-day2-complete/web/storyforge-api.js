/** StoryForge frontend API helper. For same-origin deployment leave API base empty. */
const API_BASE = (globalThis.STORYFORGE_API_BASE || '').replace(/\/$/, '');
async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { ...(options.headers || {}), ...(options.body ? { 'content-type': 'application/json' } : {}) },
    });
  } catch (error) {
    throw new Error(`Cannot reach StoryForge backend. Check the server URL and that the server is running. ${error?.message || ''}`.trim());
  }
  let payload;
  try { payload = await response.json(); }
  catch { throw new Error(`StoryForge backend returned an unreadable response (${response.status}).`); }
  if (!response.ok) throw new Error(payload.message || `StoryForge API error (${response.status})`);
  return payload;
}
export const storyforgeAPI = {
  health: () => request('/health'),
  status: () => request('/api/status'),
  metadata: () => request('/api/meta'),
  capabilities: () => request('/api/agent/capabilities'),
  validatePrompt: (prompt) => request('/api/agent/validate-request', { method: 'POST', body: JSON.stringify({ prompt }) }),
  plan: (prompt, options = {}) => request('/api/agent/plan', { method: 'POST', body: JSON.stringify({ prompt, storyOptions: options.storyOptions || {}, sceneOptions: options.sceneOptions || {} }) }),
};
