'use strict';
const DEFAULTS = Object.freeze({ maxChecks: 15, initialDelayMs: 1000, multiplier: 1.5, maxDelayMs: 5000, requestTimeoutMs: 8000, maxRequestRetries: 2 });
const activeJobs = new Map();
const COMPLETE = new Set(['completed','complete','succeeded','success','ready']);
const FAILED = new Set(['failed','failure','error']);
const CANCELLED = new Set(['cancelled','canceled']);
function validateOptions(options) {
  const merged = { ...DEFAULTS, ...options };
  for (const key of ['maxChecks','initialDelayMs','maxDelayMs','requestTimeoutMs','maxRequestRetries']) {
    if (!Number.isInteger(merged[key]) || merged[key] < (key === 'maxRequestRetries' ? 0 : 1)) throw new TypeError(`${key} must be a valid positive integer`);
  }
  if (typeof merged.multiplier !== 'number' || !Number.isFinite(merged.multiplier) || merged.multiplier < 1) throw new TypeError('multiplier must be a finite number >= 1');
  return merged;
}
function abortError(message = 'Polling aborted') { const e = new Error(message); e.name = 'AbortError'; return e; }
function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(signal.reason || abortError());
    const timer = setTimeout(done, ms);
    function done() { signal?.removeEventListener('abort', onAbort); resolve(); }
    function onAbort() { clearTimeout(timer); signal?.removeEventListener('abort', onAbort); reject(signal.reason || abortError()); }
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}
async function fetchWithTimeout(jobId, fetchStatus, timeoutMs, parentSignal) {
  const controller = new AbortController(); let timedOut = false;
  const onParentAbort = () => controller.abort(parentSignal.reason || abortError());
  if (parentSignal?.aborted) onParentAbort(); else parentSignal?.addEventListener('abort', onParentAbort, { once: true });
  let timeoutTimer;
  let abortListener;
  const timeoutPromise = new Promise((_, reject) => {
    timeoutTimer = setTimeout(() => {
      timedOut = true;
      const e = new Error(`Status request timed out after ${timeoutMs}ms`); e.name = 'TimeoutError';
      controller.abort(e); reject(e);
    }, timeoutMs);
  });
  const abortPromise = parentSignal ? new Promise((_, reject) => {
    abortListener = () => reject(parentSignal.reason || abortError());
    if (parentSignal.aborted) abortListener(); else parentSignal.addEventListener('abort', abortListener, { once: true });
  }) : new Promise(() => {});
  try {
    return await Promise.race([Promise.resolve().then(() => fetchStatus(jobId, { signal: controller.signal, timeoutMs })), timeoutPromise, abortPromise]);
  } catch (error) {
    if (timedOut && error?.name !== 'TimeoutError') { const e = new Error(`Status request timed out after ${timeoutMs}ms`); e.name = 'TimeoutError'; e.cause = error; throw e; }
    throw error;
  } finally { clearTimeout(timeoutTimer); parentSignal?.removeEventListener('abort', onParentAbort); if (abortListener) parentSignal?.removeEventListener('abort', abortListener); }
}
function normalizeStatus(result) { return String(result?.status ?? result?.state ?? result?.jobStatus ?? '').toLowerCase().trim(); }
function isRetryable(error) {
  if (error?.name === 'AbortError') return false;
  if (error?.name === 'TimeoutError') return true;
  if (Number.isInteger(error?.status)) return error.status === 408 || error.status === 429 || error.status >= 500;
  return true;
}
async function requestStatus(jobId, fetchStatus, options, signal) {
  let retries = 0;
  while (true) {
    try { return await fetchWithTimeout(jobId, fetchStatus, options.requestTimeoutMs, signal); }
    catch (error) {
      if (signal?.aborted) throw signal.reason || abortError();
      if (retries >= options.maxRequestRetries || !isRetryable(error)) throw error;
      retries++;
      await sleep(Math.min(options.initialDelayMs * (options.multiplier ** (retries - 1)), options.maxDelayMs), signal);
    }
  }
}
async function runPolling(jobId, fetchStatus, options, signal) {
  let checks = 0; let delayMs = options.initialDelayMs;
  while (checks < options.maxChecks) {
    if (signal?.aborted) throw signal.reason || abortError();
    checks++;
    let result;
    try { result = await requestStatus(jobId, fetchStatus, options, signal); }
    catch (error) {
      if (signal?.aborted || error?.name === 'AbortError') throw error;
      return { outcome: 'status_error', jobId, checks, error: { name: error.name || 'Error', message: error.message || 'Status request failed' } };
    }
    const status = normalizeStatus(result);
    if (COMPLETE.has(status)) return { outcome: 'completed', result, checks };
    if (FAILED.has(status)) return { outcome: 'failed', result, checks };
    if (CANCELLED.has(status)) return { outcome: 'cancelled', result, checks };
    if (checks >= options.maxChecks) break;
    await sleep(delayMs, signal); delayMs = Math.min(delayMs * options.multiplier, options.maxDelayMs);
  }
  return { outcome: 'still_processing', jobId, checks: options.maxChecks };
}
/** Same-job calls share one promise; reaching the polling cap never cancels the render job. */
function pollVideoJob(jobId, fetchStatus, suppliedOptions = {}) {
  if (typeof jobId !== 'string' || !jobId.trim()) throw new TypeError('jobId must be a non-empty string');
  if (typeof fetchStatus !== 'function') throw new TypeError('fetchStatus must be a function');
  const options = validateOptions(suppliedOptions); const signal = suppliedOptions.signal;
  if (activeJobs.has(jobId)) return activeJobs.get(jobId);
  const promise = runPolling(jobId, fetchStatus, options, signal).finally(() => activeJobs.delete(jobId));
  activeJobs.set(jobId, promise); return promise;
}
function isPolling(jobId) { return activeJobs.has(jobId); }
module.exports = { pollVideoJob, isPolling, DEFAULTS };
