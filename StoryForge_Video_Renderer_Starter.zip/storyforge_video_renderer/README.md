# StoryForge Video Renderer Starter (standalone)

This ZIP is a **standalone render-service starter**, not an update to your existing StoryForge repository. It renders a simple animated title/story card into a playable MP4 using Pillow + FFmpeg. It does not yet provide AI image/video generation, character animation, voice synthesis, or connect to your deployed website.


## What it provides
- `GET /health` health check
- `POST /render` renders a simple animated card MP4 (3–20 seconds)
- `GET /videos/{job_id}` downloads the MP4
- Docker deployment with FFmpeg installed

## Run locally
Install FFmpeg, Python 3.12+, then:
```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
Open `http://localhost:8000/docs` to test the API.

## Docker
```bash
docker build -t storyforge-renderer .
docker run -p 8000:8000 -v storyforge-videos:/videos storyforge-renderer
```

## Render request example
```json
{
  "title": "The Journey Begins",
  "prompt": "A young explorer steps into a glowing forest at sunset.",
  "duration_seconds": 8,
  "width": 1280,
  "height": 720
}
```
The service returns a `video_url` path. Retrieve that path from the same service to download the MP4.

## Production notes
- Protect the API with authentication and rate limits before public deployment.
- Add persistent storage and cleanup/retention policy.
- This starter is not wired into the StoryForge front end or orchestration pipeline.
- Deploy on a container host that can run FFmpeg; a standard Cloudflare Worker is not a native FFmpeg process host.
