import os, uuid, subprocess, textwrap
from pathlib import Path
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from PIL import Image, ImageDraw, ImageFont

app = FastAPI(title="StoryForge Video Renderer Starter", version="0.1.0")
OUT = Path(os.getenv("OUTPUT_DIR", "/tmp/storyforge-videos")); OUT.mkdir(parents=True, exist_ok=True)

class RenderRequest(BaseModel):
    title: str = Field(default="StoryForge Demo", max_length=100)
    prompt: str = Field(default="A cinematic journey begins", max_length=1000)
    duration_seconds: int = Field(default=8, ge=3, le=20)
    width: int = Field(default=1280, ge=320, le=1920)
    height: int = Field(default=720, ge=240, le=1080)

@app.get("/health")
def health():
    return {"status":"ok", "renderer":"starter", "ffmpeg_available": bool(subprocess.run(["ffmpeg","-version"], capture_output=True).returncode == 0)}

def font(size):
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"]:
        if Path(p).exists(): return ImageFont.truetype(p,size)
    return ImageFont.load_default()

@app.post("/render")
def render(req: RenderRequest):
    if not shutil_which("ffmpeg"): raise HTTPException(503, "FFmpeg is required on the render host")
    job_id = uuid.uuid4().hex[:12]; work = OUT / job_id; work.mkdir()
    fps=24; total=req.duration_seconds*fps
    title_font=font(max(28, req.width//22)); body_font=font(max(20, req.width//42))
    words=textwrap.wrap(req.prompt, width=48)
    try:
        for i in range(total):
            t=i/total; shift=int(30*t)
            img=Image.new("RGB",(req.width,req.height),(10+int(16*t),22+int(25*t),42+int(40*t)))
            d=ImageDraw.Draw(img)
            # Subtle moving glow circles for simple cinematic motion
            cx=int(req.width*(0.25+0.5*t)); cy=int(req.height*0.42)
            for radius in range(220,20,-20):
                col=(int(22+radius/15),int(65+radius/12),int(110+radius/9))
                d.ellipse((cx-radius,cy-radius,cx+radius,cy+radius), fill=col)
            # Dark translucent panel
            panel=(req.width//10, req.height//4, req.width*9//10, req.height*3//4)
            d.rounded_rectangle(panel, radius=28, fill=(8,15,27))
            title=req.title
            bb=d.textbbox((0,0),title,font=title_font); tw=bb[2]-bb[0]
            d.text(((req.width-tw)//2,req.height//3+shift),title,font=title_font,fill=(245,248,255))
            y=req.height//2+40
            for line in words[:6]:
                bb=d.textbbox((0,0),line,font=body_font); w=bb[2]-bb[0]
                d.text(((req.width-w)//2,y),line,font=body_font,fill=(205,220,240)); y+=body_font.size+12
            d.text((30,req.height-45),"StoryForge Renderer Starter",font=font(18),fill=(150,170,190))
            img.save(work/f"frame_{i:05d}.jpg", quality=88)
        output=work/f"video.mp4"
        cmd=["ffmpeg","-y","-framerate",str(fps),"-i",str(work/"frame_%05d.jpg"),"-c:v","libx264","-pix_fmt","yuv420p","-movflags","+faststart",str(output)]
        result=subprocess.run(cmd,capture_output=True,text=True)
        if result.returncode: raise RuntimeError(result.stderr[-1200:])
        return {"job_id":job_id,"status":"completed","video_url":f"/videos/{job_id}","message":"Starter animation rendered successfully; this is not yet the full StoryForge production pipeline."}
    except Exception as e:
        raise HTTPException(500, f"Render failed: {e}")

@app.get("/videos/{job_id}")
def get_video(job_id:str):
    path=OUT/job_id/"video.mp4"
    if not path.exists(): raise HTTPException(404,"Video not found")
    from fastapi.responses import FileResponse
    return FileResponse(path, media_type="video/mp4", filename=f"storyforge-{job_id}.mp4")

def shutil_which(cmd):
    return subprocess.run(["which",cmd],capture_output=True).returncode==0
