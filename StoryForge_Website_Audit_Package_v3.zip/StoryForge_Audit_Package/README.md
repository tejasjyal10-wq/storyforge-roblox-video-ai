# StoryForge Website Audit Package

This is a consolidated snapshot of StoryForge's website and associated backend files for the upcoming functional audit and repair work.

## Included
- `index.html` — latest available StoryForge AI Studio page, packaged as the website entry page.
- `server.js` — video-generation API backend and related routes.
- `storyforge-learning.js` — adaptive learning API router used by `server.js`.
- `package.json` — minimal Node/Express startup metadata.
- `.env.example` — provider configuration template (no secrets).

## Bundled story endpoint
- `POST /api/storyforge` supports `health`, `analyze`, and `chat` actions.
- `analyze` produces deterministic scene cards from the supplied text. This is a local heuristic planner, not a live AI model.
- The frontend defaults to this bundled endpoint when served by the backend. Custom AI endpoints can be configured separately.

## Run locally
1. Install Node.js (18+ recommended).
2. Copy `.env.example` to `.env` and set `AGNES_API_KEY` only if you have a valid provider key.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Note: This package is a snapshot of files available in the library, not a verified complete export of the current GitHub repository. The website and backend have not yet been fully audited or proven to be integrated end-to-end. This ZIP is intended for inspection and functionalization, not a production release.

## Test local planner
Run `npm test` to execute the dependency-free planner tests.
