# Character Intelligence integration into StoryForge Collection 2

This update connects the Character Intelligence Agent to the reconstructed StoryForge Collection 2 project.

## Connected behavior
- Syncs stable IDs and character records from the project's character library.
- Enriches scene cast with character identity, appearance, personality, dialogue profile, emotional state, relationships, recent memories, and growth records.
- Records scene-event memories for cast members and applies basic contextual emotion cues (alert/sad/happy). These are deterministic heuristics, not model inference.
- Scene enrichment is wired into the combined bridge's script and scene-plan handlers.
- Bridge snapshots include Character Intelligence state.

## Test
Run `npm test` from the Collection 2 root. Tests exercise library-to-agent sync and scene enrichment.

## Limits
This is a real code-level integration with the reconstructed Collection 2 bridge. It does not connect to a live LLM, hosted database, video service, or Roblox Studio runtime. It also does not verify the entire recovered StoryForge ecosystem end-to-end.
