import { randomUUID } from 'node:crypto';

const clone = (v) => structuredClone(v);
const clamp = (n, min=0, max=100) => Math.max(min, Math.min(max, Number(n) || 0));
const list = (v) => Array.isArray(v) ? v : (v == null ? [] : [v]);

export class CharacterIntelligenceAgent {
  constructor({ store = new Map(), clock = () => new Date().toISOString(), idFactory = () => randomUUID() } = {}) {
    this.store = store; this.clock = clock; this.idFactory = idFactory;
  }
  createCharacter(input = {}) {
    if (!input.name?.trim()) throw new Error('Character name is required');
    const id = input.id || this.idFactory();
    if (this.store.has(id)) throw new Error(`Character ID already exists: ${id}`);
    const character = {
      id, name: input.name.trim(), role: input.role || 'unspecified', appearance: clone(input.appearance || {}),
      personality: { traits: list(input.personality?.traits), strengths: list(input.personality?.strengths), weaknesses: list(input.personality?.weaknesses), motivation: input.personality?.motivation || '', fear: input.personality?.fear || '', values: list(input.personality?.values) },
      dialogue: clone(input.dialogue || { style: '', vocabulary: '', mannerisms: [] }),
      emotions: { current: input.emotion || 'neutral', intensity: 0 }, relationships: {}, memories: [], growth: [], knowledge: list(input.knowledge),
      createdAt: this.clock(), updatedAt: this.clock(), version: 1
    };
    this.store.set(id, character); return clone(character);
  }
  getCharacter(id) { const c = this.store.get(id); return c ? clone(c) : null; }
  listCharacters() { return [...this.store.values()].map(clone); }
  updateCharacter(id, patch = {}) {
    const c = this.#require(id);
    if (patch.name !== undefined) { if (!patch.name.trim()) throw new Error('Character name cannot be empty'); c.name = patch.name.trim(); }
    for (const key of ['role','appearance','personality','dialogue','knowledge']) if (patch[key] !== undefined) c[key] = key === 'role' ? patch[key] : clone(patch[key]);
    c.updatedAt = this.clock(); c.version++; return clone(c);
  }
  addMemory(id, memory, { importance = 50, tags = [] } = {}) {
    if (!memory?.trim()) throw new Error('Memory text is required'); const c = this.#require(id);
    const entry = { id: this.idFactory(), text: memory.trim(), importance: clamp(importance), tags: list(tags), createdAt: this.clock() };
    c.memories.push(entry); c.updatedAt = this.clock(); c.version++; return clone(entry);
  }
  setEmotion(id, emotion, intensity = 50, reason = '') {
    if (!emotion?.trim()) throw new Error('Emotion label is required'); const c = this.#require(id);
    c.emotions = { current: emotion.trim(), intensity: clamp(intensity), reason, updatedAt: this.clock() }; c.updatedAt = this.clock(); c.version++; return clone(c.emotions);
  }
  setRelationship(id, otherId, { type = 'known', trust = 50, affinity = 50, notes = '' } = {}) {
    const c = this.#require(id); if (id === otherId) throw new Error('A character cannot relate to itself');
    c.relationships[otherId] = { type, trust: clamp(trust), affinity: clamp(affinity), notes, updatedAt: this.clock() };
    c.updatedAt = this.clock(); c.version++; return clone(c.relationships[otherId]);
  }
  evolve(id, { change, cause, stage } = {}) {
    if (!change?.trim() || !cause?.trim()) throw new Error('Growth change and cause are required'); const c = this.#require(id);
    const entry = { id: this.idFactory(), change: change.trim(), cause: cause.trim(), stage: stage || null, createdAt: this.clock() };
    c.growth.push(entry); c.updatedAt = this.clock(); c.version++; return clone(entry);
  }
  validate(id) {
    const c = this.#require(id); const issues = [];
    if (!c.name) issues.push({ code:'missing-name', message:'Character has no name' });
    if (!c.personality.traits.length) issues.push({ code:'missing-traits', message:'Personality traits are empty' });
    for (const [otherId, rel] of Object.entries(c.relationships)) {
      if (!this.store.has(otherId)) issues.push({ code:'dangling-relationship', otherId, message:`Relationship references unknown character ${otherId}` });
      if (rel.trust < 0 || rel.trust > 100 || rel.affinity < 0 || rel.affinity > 100) issues.push({ code:'relationship-range', otherId, message:'Relationship scores must be 0–100' });
    }
    const memoryIds = new Set(); for (const m of c.memories) { if (memoryIds.has(m.id)) issues.push({code:'duplicate-memory-id', message:'Duplicate memory ID'}); memoryIds.add(m.id); }
    return { characterId:id, valid:issues.length===0, issues };
  }
  exportCharacter(id) { return JSON.stringify(this.#require(id), null, 2); }
  importCharacter(json, { replace = false } = {}) {
    const c = typeof json === 'string' ? JSON.parse(json) : clone(json);
    if (!c?.id || !c?.name) throw new Error('Imported character must include id and name');
    if (this.store.has(c.id) && !replace) throw new Error(`Character ID already exists: ${c.id}`);
    this.store.set(c.id, c); return clone(c);
  }
  #require(id) { const c = this.store.get(id); if (!c) throw new Error(`Unknown character: ${id}`); return c; }
}
