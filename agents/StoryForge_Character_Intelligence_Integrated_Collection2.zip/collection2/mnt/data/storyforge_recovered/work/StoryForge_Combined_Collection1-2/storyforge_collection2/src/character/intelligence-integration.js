import { CharacterIntelligenceAgent } from './character-agent-core.js';

/** Connects the Character Library and Intelligence Agent to story scenes and the production bridge. */
export class CharacterIntelligenceIntegration {
  constructor({ project, agent = new CharacterIntelligenceAgent() } = {}) {
    if (!project) throw new Error('StoryForge project is required');
    this.project = project; this.agent = agent; this.libraryToAgent = new Map();
    this.syncLibrary();
  }
  syncLibrary() {
    const records = this.project.characterLibrary?.list?.() ?? this.project.characters?.list?.() ?? (this.project.cast instanceof Map ? [...this.project.cast.values()] : []);
    for (const record of records) {
      const existingId = this.libraryToAgent.get(record.id);
      if (existingId && this.agent.getCharacter(existingId)) {
        this.agent.updateCharacter(existingId, { name: record.name, role: record.role, appearance: record.appearance, dialogue: record.dialogue ?? { style: record.voice ?? '', mannerisms: [] }, personality: { traits: record.personality ?? [], strengths: record.strengths ?? [], weaknesses: record.weaknesses ?? [], motivation: record.motivation ?? '', fear: record.fear ?? '', values: record.values ?? [] } });
      } else {
        const c = this.agent.createCharacter({ id: record.id, name: record.name, role: record.role, appearance: record.appearance, dialogue: { style: record.voice ?? '', mannerisms: [] }, personality: { traits: record.personality ?? [], strengths: record.strengths ?? [], weaknesses: record.weaknesses ?? [], motivation: record.motivation ?? '', fear: record.fear ?? '', values: record.values ?? [] } });
        this.libraryToAgent.set(record.id, c.id);
      }
    }
    return this.agent.listCharacters();
  }
  resolveCharacter(identifier) {
    const all = this.agent.listCharacters();
    return all.find(c => c.id === identifier || c.name.toLowerCase() === String(identifier).toLowerCase()) ?? null;
  }
  enrichScene(scene, { event = scene.event ?? scene.description ?? scene.action ?? '', sceneIndex = 0 } = {}) {
    this.syncLibrary();
    const identifiers = Array.isArray(scene.characters) ? scene.characters : String(scene.characters ?? '').split(',').map(s => s.trim()).filter(Boolean);
    const cast = identifiers.map(i => this.resolveCharacter(i)).filter(Boolean);
    const eventText = String(event);
    for (const c of cast) {
      const lower = eventText.toLowerCase();
      if (eventText.trim() && !c.memories.some(m => m.text === `Scene ${sceneIndex + 1}: ${eventText}`)) this.agent.addMemory(c.id, `Scene ${sceneIndex + 1}: ${eventText}`, { importance: 45, tags: ['scene', 'story-event'] });
      const emotion = /danger|attack|threat|fight|chase/i.test(lower) ? 'alert' : /sad|loss|cry|grief/i.test(lower) ? 'sad' : /joy|celebrat|happy|win/i.test(lower) ? 'happy' : 'neutral';
      if (emotion !== 'neutral') this.agent.setEmotion(c.id, emotion, 55, `Scene ${sceneIndex + 1} context`);
    }
    return { ...scene, characterIntelligence: cast.map(c => { const latest = this.agent.getCharacter(c.id) ?? c; return { id: latest.id, name: latest.name, role: latest.role, appearance: latest.appearance, personality: latest.personality, dialogue: latest.dialogue, emotions: latest.emotions, relationships: latest.relationships, memories: latest.memories.slice(-5), growth: latest.growth }; }) };
  }
  enrichScenes(scenes = []) { return scenes.map((scene, i) => this.enrichScene(scene, { sceneIndex: i })); }
  snapshot() { return { characters: this.agent.listCharacters(), libraryToAgent: Object.fromEntries(this.libraryToAgent) }; }
}
