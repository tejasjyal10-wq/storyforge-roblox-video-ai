import test from 'node:test'; import assert from 'node:assert/strict';
import { StoryProject, CharacterIntelligenceIntegration } from '../index.js';
test('Character intelligence syncs stable library identity and enriches scene', () => { const project = new StoryProject({ id:'p1', title:'Integration test' }); project.addCharacter({ id:'char-arin', name:'Arin', role:'hero', appearance:{ outfit:'blue' }, personality:['curious','brave'], voice:'quick' });
  const integration = new CharacterIntelligenceIntegration({ project }); const enriched = integration.enrichScene({ id:'s1', characters:['Arin'], description:'Arin discovers a danger in the forest.' });
  assert.equal(enriched.characterIntelligence.length,1); assert.equal(enriched.characterIntelligence[0].id,'char-arin'); assert.ok(enriched.characterIntelligence[0].memories.length); assert.equal(enriched.characterIntelligence[0].emotions.current,'alert');
});
test('integration snapshot includes character agent records', () => { const project = new StoryProject({ id:'p1', title:'Integration test' }); project.addCharacter({id:'char-x',name:'X',role:'extra',personality:['calm']}); const bridge=new CharacterIntelligenceIntegration({project}); assert.equal(bridge.snapshot().characters.length,1); });
